import os
import uuid
import json
import logging
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, session
import werkzeug.utils
from video_processor import process_videos, get_video_info, create_preview
from audio_analyzer import detect_silence
from content_analyzer import (
    detect_faces, detect_objects, detect_scene_changes, 
    analyze_audio_levels, generate_thumbnails, detect_highlights
)
from smart_editor import (
    generate_subtitles, sync_video_to_beats, apply_jump_cuts,
    create_highlight_reel, reduce_background_noise
)

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Create Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET")

# Constants
UPLOAD_FOLDER = 'temp_uploads'
RESULTS_FOLDER = 'processed_videos'
ALLOWED_EXTENSIONS = {'mp4', 'avi', 'mov', 'mkv', 'wmv'}

# Create necessary directories
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(RESULTS_FOLDER, exist_ok=True)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/')
def index():
    """Render the main page"""
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    """Handle file uploads"""
    if 'files[]' not in request.files:
        flash('No file part', 'danger')
        return redirect(request.url)
    
    files = request.files.getlist('files[]')
    if not files or files[0].filename == '':
        flash('No selected file', 'danger')
        return redirect(request.url)
    
    # Create a unique session ID for this batch of uploads
    batch_id = str(uuid.uuid4())
    session['batch_id'] = batch_id
    
    # Create a directory for this batch
    batch_dir = os.path.join(UPLOAD_FOLDER, batch_id)
    os.makedirs(batch_dir, exist_ok=True)
    
    uploaded_files = []
    
    for file in files:
        if file and allowed_file(file.filename):
            filename = werkzeug.utils.secure_filename(file.filename)
            file_path = os.path.join(batch_dir, filename)
            file.save(file_path)
            
            # Get basic video information
            video_info = get_video_info(file_path)
            uploaded_files.append({
                'filename': filename,
                'path': file_path,
                'info': video_info
            })
        else:
            flash(f'File {file.filename} has an unsupported format. Skipping.', 'warning')
    
    if not uploaded_files:
        flash('No valid files were uploaded', 'danger')
        return redirect(url_for('index'))
    
    # Store uploaded files info in session
    session['uploaded_files'] = uploaded_files
    
    return redirect(url_for('processing_options'))

@app.route('/processing-options')
def processing_options():
    """Display processing options for uploaded videos"""
    if 'uploaded_files' not in session:
        flash('No files uploaded. Please upload files first.', 'warning')
        return redirect(url_for('index'))
    
    return render_template('processing.html', videos=session['uploaded_files'])

@app.route('/preview/<filename>')
def preview_video(filename):
    """Generate a preview of the video with selected effects"""
    batch_id = session.get('batch_id')
    if not batch_id:
        return jsonify({'error': 'No active session'}), 400
    
    file_path = os.path.join(UPLOAD_FOLDER, batch_id, filename)
    if not os.path.exists(file_path):
        return jsonify({'error': 'File not found'}), 404
    
    # Get processing parameters from query string
    trim = request.args.get('trim', 'false') == 'true'
    stabilize = request.args.get('stabilize', 'false') == 'true'
    brightness = float(request.args.get('brightness', 0))
    contrast = float(request.args.get('contrast', 0))
    
    # Create a preview with selected options
    preview_path = create_preview(
        file_path, 
        trim=trim, 
        stabilize=stabilize, 
        brightness_adjustment=brightness,
        contrast_adjustment=contrast
    )
    
    return jsonify({'preview_path': preview_path})

@app.route('/detect-silence/<filename>')
def silence_detection(filename):
    """Detect silent parts in the video for auto-trimming"""
    batch_id = session.get('batch_id')
    if not batch_id:
        return jsonify({'error': 'No active session'}), 400
    
    file_path = os.path.join(UPLOAD_FOLDER, batch_id, filename)
    if not os.path.exists(file_path):
        return jsonify({'error': 'File not found'}), 404
    
    # Detect silent segments
    silence_intervals = detect_silence(file_path)
    
    return jsonify({'silence_intervals': silence_intervals})

@app.route('/process', methods=['POST'])
def process():
    """Process videos with selected options"""
    if 'uploaded_files' not in session:
        flash('No files uploaded. Please upload files first.', 'warning')
        return redirect(url_for('index'))
    
    # Get processing options from form
    options = {
        'resolution': request.form.get('resolution', '1080p'),
        'auto_trim': request.form.get('auto_trim') == 'on',
        'auto_crop': request.form.get('auto_crop') == 'on',
        'stabilize': request.form.get('stabilize') == 'on',
        'color_correction': request.form.get('color_correction') == 'on',
        'brightness': float(request.form.get('brightness', 0)),
        'contrast': float(request.form.get('contrast', 0)),
        'output_format': request.form.get('output_format', 'mp4'),
        'quality': request.form.get('quality', 'high')
    }
    
    batch_id = session.get('batch_id')
    if not batch_id:
        flash('Session expired. Please upload files again.', 'danger')
        return redirect(url_for('index'))
    
    # Process all videos in the batch
    batch_dir = os.path.join(UPLOAD_FOLDER, batch_id)
    output_dir = os.path.join(RESULTS_FOLDER, batch_id)
    os.makedirs(output_dir, exist_ok=True)
    
    try:
        processed_files = process_videos(
            [video['path'] for video in session['uploaded_files']], 
            output_dir, 
            options
        )
        
        # Store processed files info in session
        session['processed_files'] = processed_files
        
        return redirect(url_for('results'))
    except Exception as e:
        logger.exception("Error processing videos")
        flash(f'Error processing videos: {str(e)}', 'danger')
        return redirect(url_for('processing_options'))

@app.route('/results')
def results():
    """Display processing results"""
    if 'processed_files' not in session:
        flash('No processed files. Please process files first.', 'warning')
        return redirect(url_for('index'))
    
    return render_template('results.html', videos=session['processed_files'])

@app.route('/clear-session')
def clear_session():
    """Clear the session and start over"""
    # Clean up temporary files
    batch_id = session.get('batch_id')
    if batch_id:
        batch_dir = os.path.join(UPLOAD_FOLDER, batch_id)
        if os.path.exists(batch_dir):
            import shutil
            shutil.rmtree(batch_dir)
    
    # Clear session
    session.clear()
    
    flash('Session cleared. You can start a new batch.', 'info')
    return redirect(url_for('index'))

@app.route('/ai-features')
def ai_features():
    """Display AI features page"""
    if 'uploaded_files' not in session:
        flash('No files uploaded. Please upload files first.', 'warning')
        return redirect(url_for('index'))
    
    return render_template('ai_features.html', videos=session['uploaded_files'])

@app.route('/template-system')
def template_system():
    """Display template system and social media optimization page"""
    if 'uploaded_files' not in session:
        flash('No files uploaded. Please upload files first.', 'warning')
        return redirect(url_for('index'))
    
    return render_template('template_system.html', videos=session['uploaded_files'])

@app.route('/advanced-features')
def advanced_features():
    """Display advanced audio processing and effects page"""
    if 'uploaded_files' not in session:
        flash('No files uploaded. Please upload files first.', 'warning')
        return redirect(url_for('index'))
    
    return render_template('advanced_features.html', videos=session['uploaded_files'])

@app.route('/project-management')
def project_management():
    """Display project management page"""
    return render_template('project_management.html')

@app.route('/motion-tracking')
def motion_tracking():
    """Display motion tracking and graphics page"""
    if 'uploaded_files' not in session:
        flash('No files uploaded. Please upload files first.', 'warning')
        return redirect(url_for('index'))
    
    return render_template('motion_tracking.html', videos=session['uploaded_files'])

@app.route('/analyze_video', methods=['POST'])
def analyze_video():
    """Analyze a video using AI content analysis"""
    if 'video_path' not in request.form:
        return jsonify({'error': 'No video selected'}), 400
    
    video_path = request.form.get('video_path')
    if not os.path.exists(video_path):
        return jsonify({'error': 'Video file not found'}), 404
    
    # Get selected features
    features = []
    if 'features' in request.form:
        try:
            features = json.loads(request.form.get('features'))
        except:
            return jsonify({'error': 'Invalid features format'}), 400
    
    if not features:
        return jsonify({'error': 'No features selected'}), 400
    
    results = {}
    
    try:
        # Process each selected feature
        for feature in features:
            if feature == 'face_detection':
                # Detect faces
                face_data = detect_faces(video_path)
                results['face_detection'] = face_data
            
            elif feature == 'object_recognition':
                # Detect objects
                object_data = detect_objects(video_path)
                results['object_recognition'] = object_data
            
            elif feature == 'scene_detection':
                # Detect scene changes
                scene_data = detect_scene_changes(video_path)
                results['scene_detection'] = scene_data
            
            elif feature == 'audio_analysis':
                # Analyze audio levels
                audio_data = analyze_audio_levels(video_path)
                results['audio_analysis'] = audio_data
        
        return jsonify(results)
    
    except Exception as e:
        logger.exception(f"Error analyzing video: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/process_video_ai', methods=['POST'])
def process_video_ai():
    """Process a video with AI-powered smart editing features"""
    if 'video_path' not in request.form:
        return jsonify({'error': 'No video selected'}), 400
    
    video_path = request.form.get('video_path')
    if not os.path.exists(video_path):
        return jsonify({'error': 'Video file not found'}), 404
    
    # Get selected features
    features = []
    if 'features' in request.form:
        try:
            features = json.loads(request.form.get('features'))
        except:
            return jsonify({'error': 'Invalid features format'}), 400
    
    if not features:
        return jsonify({'error': 'No features selected'}), 400
    
    # Get API key if provided
    api_key = request.form.get('api_key', None)
    
    # Create a directory for processed files
    batch_id = session.get('batch_id')
    if not batch_id:
        batch_id = str(uuid.uuid4())
        session['batch_id'] = batch_id
    
    output_dir = os.path.join(RESULTS_FOLDER, batch_id)
    os.makedirs(output_dir, exist_ok=True)
    
    results = {}
    
    try:
        # Process each selected feature
        for feature in features:
            if feature == 'subtitle_generation':
                # Generate subtitles
                subtitle_data = generate_subtitles(video_path, api_key=api_key)
                results['subtitle_generation'] = subtitle_data
            
            elif feature == 'highlight_detection':
                # Generate highlight reel
                base_name = os.path.splitext(os.path.basename(video_path))[0]
                output_path = os.path.join(output_dir, f"{base_name}_highlights.mp4")
                highlight_data = create_highlight_reel(video_path, output_path=output_path)
                results['highlight_detection'] = highlight_data
            
            elif feature == 'jump_cut':
                # Apply jump cuts
                base_name = os.path.splitext(os.path.basename(video_path))[0]
                output_path = os.path.join(output_dir, f"{base_name}_jumpcut.mp4")
                jumpcut_data = apply_jump_cuts(video_path, output_path=output_path)
                results['jump_cut'] = jumpcut_data
            
            elif feature == 'beat_detection':
                # Sync video to beats
                base_name = os.path.splitext(os.path.basename(video_path))[0]
                output_path = os.path.join(output_dir, f"{base_name}_beat_sync.mp4")
                beat_data = sync_video_to_beats(video_path, output_path=output_path)
                results['beat_detection'] = beat_data
            
            elif feature == 'thumbnail_generation':
                # Generate thumbnails
                thumbnail_data = generate_thumbnails(video_path, output_dir=output_dir)
                results['thumbnail_generation'] = thumbnail_data
            
            elif feature == 'noise_reduction':
                # Extract audio
                from smart_editor import extract_audio
                audio_path = extract_audio(video_path)
                
                if audio_path:
                    base_name = os.path.splitext(os.path.basename(video_path))[0]
                    output_path = os.path.join(output_dir, f"{base_name}_reduced.wav")
                    noise_data = reduce_background_noise(audio_path, output_path=output_path)
                    # Remove temporary audio file
                    os.remove(audio_path)
                    results['noise_reduction'] = noise_data
                else:
                    results['noise_reduction'] = {'error': 'No audio track found in video'}
        
        return jsonify(results)
    
    except Exception as e:
        logger.exception(f"Error processing video with AI features: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/process_advanced', methods=['POST'])
def process_advanced():
    """Process a video with advanced audio and effects features"""
    if 'video_path' not in request.form:
        return jsonify({'error': 'No video selected'}), 400
    
    video_path = request.form.get('video_path')
    if not os.path.exists(video_path):
        return jsonify({'error': 'Video file not found'}), 404
    
    # Parse audio processing options
    audio_options = {
        'voice_enhancement': request.form.get('voice_enhancement') == 'true',
        'voice_enhancement_intensity': float(request.form.get('voice_enhancement_intensity', 0.5)),
        'noise_cancellation': request.form.get('noise_cancellation') == 'true',
        'noise_reduction_strength': float(request.form.get('noise_reduction_strength', 0.5)),
        'eq_preset': request.form.get('voice_eq', 'none'),
        'audio_ducking': request.form.get('audio_ducking') == 'true',
    }
    
    # Parse music options
    if request.form.get('music_track_id'):
        # In a real implementation, we would retrieve the actual music file path based on the track ID
        # For demo purposes, we'll use a placeholder
        audio_options['music_path'] = f"static/music/{request.form.get('music_track_id')}.mp3"
        audio_options['music_volume'] = float(request.form.get('music_volume', 50))
    
    # Parse audio mixer settings
    audio_options['audio_mixer'] = {
        'original': float(request.form.get('original_volume', 100)),
        'music': float(request.form.get('music_mix_volume', 50)),
        'effects': float(request.form.get('effects_volume', 75)),
        'preset': request.form.get('audio_mix_preset', 'custom')
    }
    
    # Parse effects and transitions options
    effects_options = {
        'transition': request.form.get('transition', 'cut'),
        'transition_duration': float(request.form.get('transition_duration', 0.5)),
        'auto_transition': request.form.get('auto_transition') == 'true',
        'visual_effects': True,  # Flag indicating whether to apply visual effects
        'filter_preset': request.form.get('filter_preset', 'none'),
        'brightness': int(request.form.get('brightness', 0)),
        'contrast': int(request.form.get('contrast', 0)),
        'saturation': int(request.form.get('saturation', 0)),
        'sharpness': int(request.form.get('sharpness', 50)),
        'chroma_key': request.form.get('chroma_key') == 'true'
    }
    
    # Parse chroma key settings if enabled
    if effects_options['chroma_key']:
        effects_options['key_color'] = request.form.get('key_color', '#00ff00')
        effects_options['key_tolerance'] = int(request.form.get('key_tolerance', 40))
    
    # Parse text overlays
    if 'text_overlays' in request.form:
        try:
            text_overlays = json.loads(request.form.get('text_overlays'))
            effects_options['text_overlays'] = text_overlays
        except:
            # If parsing fails, don't add text overlays
            pass
    
    # Create a directory for processed files
    batch_id = session.get('batch_id')
    if not batch_id:
        batch_id = str(uuid.uuid4())
        session['batch_id'] = batch_id
    
    output_dir = os.path.join(RESULTS_FOLDER, batch_id)
    os.makedirs(output_dir, exist_ok=True)
    
    try:
        # For demonstration purposes, we'll simulate processing
        # In a real implementation, you would use the imported modules
        # from audio_processor import process_audio_features
        # from effects_processor import process_effects_features
        
        # Simulate processing delay
        import time
        time.sleep(2)
        
        # Create output path
        base_name = os.path.splitext(os.path.basename(video_path))[0]
        final_output_path = os.path.join(output_dir, f"{base_name}_advanced.mp4")
        
        # In a real implementation, you would process the video with audio and effects features
        # audio_processed_path = process_audio_features(video_path, audio_options)
        # final_output_path = process_effects_features(audio_processed_path, effects_options)
        
        # For demo, copy the original video to the output path
        import shutil
        shutil.copy2(video_path, final_output_path)
        
        # Generate a relative path for client-side usage
        relative_path = final_output_path.replace(os.path.join(os.getcwd(), ''), '').lstrip('/')
        
        # Update the session to include this processed file
        if 'processed_files' not in session:
            session['processed_files'] = []
            
        session['processed_files'].append({
            'path': relative_path,
            'filename': os.path.basename(relative_path)
        })
        
        results = {
            'success': True,
            'message': 'Video processed successfully with advanced features',
            'output_path': relative_path
        }
        
        return jsonify(results)
    except Exception as e:
        logger.exception(f"Error processing video with advanced features: {str(e)}")
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
