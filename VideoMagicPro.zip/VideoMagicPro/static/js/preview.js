document.addEventListener('DOMContentLoaded', function() {
    // Initialize video.js player
    const player = videojs('videoPreview', {
        controls: true,
        autoplay: false,
        preload: 'auto',
        fluid: true,
        responsive: true
    });
    
    // DOM elements
    const previewVideoSelect = document.getElementById('previewVideo');
    const generatePreviewBtn = document.getElementById('generatePreview');
    const detectSilenceBtn = document.getElementById('detectSilence');
    const previewInfo = document.getElementById('previewInfo');
    const silenceInfo = document.getElementById('silenceInfo');
    const silenceVisualizer = document.getElementById('silenceVisualizer');
    const silenceList = document.getElementById('silenceList');
    const colorCorrectionCheckbox = document.getElementById('color_correction');
    const brightnessSlider = document.getElementById('brightness');
    const contrastSlider = document.getElementById('contrast');
    const brightnessValue = document.getElementById('brightnessValue');
    const contrastValue = document.getElementById('contrastValue');
    
    // Track current processing options
    let currentOptions = {
        trim: false,
        stabilize: false,
        brightness: 0,
        contrast: 0
    };
    
    // Enable buttons when a video is selected
    previewVideoSelect.addEventListener('change', function() {
        const selectedVideo = previewVideoSelect.value;
        generatePreviewBtn.disabled = !selectedVideo;
        detectSilenceBtn.disabled = !selectedVideo;
        
        if (selectedVideo) {
            // Reset video player
            player.src({
                src: `/upload/${selectedVideo}`,
                type: 'video/mp4'
            });
            player.load();
            
            // Hide previous results
            previewInfo.classList.add('d-none');
            silenceInfo.classList.add('d-none');
        }
    });
    
    // Generate preview with current settings
    generatePreviewBtn.addEventListener('click', function() {
        const selectedVideo = previewVideoSelect.value;
        if (!selectedVideo) return;
        
        // Show processing message
        previewInfo.classList.remove('d-none');
        previewInfo.textContent = 'Generating preview with selected effects. This may take a moment...';
        
        // Build preview URL with options
        const autoTrim = document.getElementById('auto_trim').checked;
        const stabilize = document.getElementById('stabilize').checked;
        const brightness = parseInt(document.getElementById('brightness').value);
        const contrast = parseInt(document.getElementById('contrast').value);
        
        // Update current options
        currentOptions = {
            trim: autoTrim,
            stabilize: stabilize,
            brightness: brightness,
            contrast: contrast
        };
        
        const previewUrl = `/preview/${selectedVideo}?trim=${autoTrim}&stabilize=${stabilize}&brightness=${brightness}&contrast=${contrast}`;
        
        // Request preview generation
        fetch(previewUrl)
            .then(response => response.json())
            .then(data => {
                if (data.error) {
                    previewInfo.textContent = `Error: ${data.error}`;
                    previewInfo.classList.remove('alert-info');
                    previewInfo.classList.add('alert-danger');
                } else {
                    // Load the preview video
                    player.src({
                        src: data.preview_path,
                        type: 'video/mp4'
                    });
                    player.load();
                    player.play();
                    
                    // Update info message
                    previewInfo.textContent = 'Preview generated with your selected settings. This is a short clip of the full video.';
                    previewInfo.classList.remove('alert-danger');
                    previewInfo.classList.add('alert-info');
                }
            })
            .catch(error => {
                console.error('Error generating preview:', error);
                previewInfo.textContent = `Error generating preview: ${error.message}`;
                previewInfo.classList.remove('alert-info');
                previewInfo.classList.add('alert-danger');
            });
    });
    
    // Detect silence in the selected video
    detectSilenceBtn.addEventListener('click', function() {
        const selectedVideo = previewVideoSelect.value;
        if (!selectedVideo) return;
        
        // Show processing message
        previewInfo.classList.remove('d-none');
        previewInfo.textContent = 'Detecting silent parts in the video. This may take a moment...';
        silenceInfo.classList.add('d-none');
        
        // Request silence detection
        fetch(`/detect-silence/${selectedVideo}`)
            .then(response => response.json())
            .then(data => {
                if (data.error) {
                    previewInfo.textContent = `Error: ${data.error}`;
                    previewInfo.classList.remove('alert-info');
                    previewInfo.classList.add('alert-danger');
                } else {
                    // Get silence intervals
                    const silenceIntervals = data.silence_intervals;
                    
                    if (silenceIntervals && silenceIntervals.length > 0) {
                        // Show silence visualization
                        silenceInfo.classList.remove('d-none');
                        previewInfo.textContent = `Found ${silenceIntervals.length} silent segments in the video.`;
                        
                        // Clear previous visualizer
                        silenceVisualizer.innerHTML = '';
                        silenceList.innerHTML = '';
                        
                        // Get video duration from player
                        const duration = player.duration();
                        
                        // Create visualization of silence intervals
                        silenceIntervals.forEach((interval, index) => {
                            const [start, end] = interval;
                            const startPercent = (start / duration) * 100;
                            const widthPercent = ((end - start) / duration) * 100;
                            
                            // Create a block representing the silent part
                            const silenceBlock = document.createElement('div');
                            silenceBlock.className = 'silence-block position-absolute bg-danger';
                            silenceBlock.style.left = `${startPercent}%`;
                            silenceBlock.style.width = `${widthPercent}%`;
                            silenceBlock.style.height = '100%';
                            silenceBlock.title = `Silent part from ${start.toFixed(2)}s to ${end.toFixed(2)}s`;
                            silenceVisualizer.appendChild(silenceBlock);
                            
                            // Add to the text list
                            silenceList.innerHTML += `<div>Silent part ${index + 1}: ${start.toFixed(2)}s - ${end.toFixed(2)}s (duration: ${(end - start).toFixed(2)}s)</div>`;
                        });
                        
                        // Add a timeline
                        const timeline = document.createElement('div');
                        timeline.className = 'timeline position-absolute bg-secondary';
                        timeline.style.bottom = '0';
                        timeline.style.left = '0';
                        timeline.style.width = '100%';
                        timeline.style.height = '2px';
                        silenceVisualizer.appendChild(timeline);
                        
                        // Add timeline markers (every 10% of duration)
                        for (let i = 0; i <= 10; i++) {
                            const marker = document.createElement('div');
                            marker.className = 'marker position-absolute bg-light';
                            marker.style.bottom = '0';
                            marker.style.left = `${i * 10}%`;
                            marker.style.width = '1px';
                            marker.style.height = '6px';
                            silenceVisualizer.appendChild(marker);
                            
                            if (i % 2 === 0) {  // Add labels every 20%
                                const label = document.createElement('div');
                                label.className = 'marker-label position-absolute text-light small';
                                label.style.bottom = '8px';
                                label.style.left = `${i * 10}%`;
                                label.style.transform = 'translateX(-50%)';
                                label.textContent = `${((i / 10) * duration).toFixed(1)}s`;
                                silenceVisualizer.appendChild(label);
                            }
                        }
                    } else {
                        previewInfo.textContent = 'No silent segments detected in this video.';
                        silenceInfo.classList.add('d-none');
                    }
                }
            })
            .catch(error => {
                console.error('Error detecting silence:', error);
                previewInfo.textContent = `Error detecting silence: ${error.message}`;
                previewInfo.classList.remove('alert-info');
                previewInfo.classList.add('alert-danger');
            });
    });
    
    // Toggle color correction sliders
    colorCorrectionCheckbox.addEventListener('change', function() {
        brightnessSlider.disabled = !this.checked;
        contrastSlider.disabled = !this.checked;
    });
    
    // Update brightness value display
    brightnessSlider.addEventListener('input', function() {
        brightnessValue.textContent = `${this.value}%`;
    });
    
    // Update contrast value display
    contrastSlider.addEventListener('input', function() {
        contrastValue.textContent = `${this.value}%`;
    });
});
