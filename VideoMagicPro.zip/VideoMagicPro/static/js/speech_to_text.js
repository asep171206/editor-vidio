document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const mediaSelect = document.getElementById('mediaSelect');
    const mediaUpload = document.getElementById('mediaUpload');
    const uploadMediaBtn = document.getElementById('uploadMediaBtn');
    const videoPreview = document.getElementById('videoPreview');
    const audioPreview = document.getElementById('audioPreview');
    const transcribeBtn = document.getElementById('transcribeBtn');
    
    // Transcript elements
    const transcriptionInitialState = document.getElementById('transcriptionInitialState');
    const transcriptionLoadingState = document.getElementById('transcriptionLoadingState');
    const transcriptionResults = document.getElementById('transcriptionResults');
    const transcriptionProgressBar = document.getElementById('transcriptionProgressBar');
    const transcriptionStatusText = document.getElementById('transcriptionStatusText');
    const transcriptViewer = document.getElementById('transcriptViewer');
    const transcriptWordCount = document.getElementById('transcriptWordCount');
    const transcriptDuration = document.getElementById('transcriptDuration');
    
    // Settings elements
    const languageSelect = document.getElementById('languageSelect');
    const modelSelect = document.getElementById('modelSelect');
    const detectSpeakers = document.getElementById('detectSpeakers');
    const filterProfanity = document.getElementById('filterProfanity');
    const includePunctuation = document.getElementById('includePunctuation');
    const textFormatting = document.getElementById('textFormatting');
    
    // Output format elements
    const outputFormatRadios = document.getElementsByName('outputFormat');
    const subtitleSettings = document.getElementById('subtitleSettings');
    const maxLineLength = document.getElementById('maxLineLength');
    const maxLineLengthValue = document.getElementById('maxLineLengthValue');
    const maxLinesPerSubtitle = document.getElementById('maxLinesPerSubtitle');
    
    // Buttons
    const syncMediaBtn = document.getElementById('syncMediaBtn');
    const copyTranscriptBtn = document.getElementById('copyTranscriptBtn');
    const downloadTranscriptBtn = document.getElementById('downloadTranscriptBtn');
    const editTranscriptBtn = document.getElementById('editTranscriptBtn');
    const translateTranscriptBtn = document.getElementById('translateTranscriptBtn');
    const createSubtitlesBtn = document.getElementById('createSubtitlesBtn');
    const summarizeBtn = document.getElementById('summarizeBtn');
    const newTranscriptionBtn = document.getElementById('newTranscriptionBtn');
    
    // Modals
    const editTranscriptModal = new bootstrap.Modal(document.getElementById('editTranscriptModal'));
    const translateTranscriptModal = new bootstrap.Modal(document.getElementById('translateTranscriptModal'));
    const summaryModal = new bootstrap.Modal(document.getElementById('summaryModal'));
    const createSubtitlesModal = new bootstrap.Modal(document.getElementById('createSubtitlesModal'));
    
    // Modal elements
    const editTranscriptText = document.getElementById('editTranscriptText');
    const saveTranscriptBtn = document.getElementById('saveTranscriptBtn');
    const confirmTranslateBtn = document.getElementById('confirmTranslateBtn');
    const generateSummaryBtn = document.getElementById('generateSummaryBtn');
    const summaryContent = document.getElementById('summaryContent');
    const summaryLoading = document.getElementById('summaryLoading');
    const copySummaryBtn = document.getElementById('copySummaryBtn');
    const confirmCreateSubtitlesBtn = document.getElementById('confirmCreateSubtitlesBtn');
    
    // State variables
    let currentMedia = null;
    let mediaType = null; // 'video' or 'audio'
    let transcript = null;
    let isProcessing = false;
    
    // Event Listeners
    
    // Media Select
    mediaSelect.addEventListener('change', function() {
        const selectedMedia = this.value;
        if (selectedMedia) {
            loadMedia(selectedMedia);
        }
    });
    
    // Media Upload
    uploadMediaBtn.addEventListener('click', function() {
        if (mediaUpload.files.length > 0) {
            handleMediaUpload(mediaUpload.files[0]);
        } else {
            mediaUpload.click();
        }
    });
    
    mediaUpload.addEventListener('change', function() {
        if (this.files.length > 0) {
            handleMediaUpload(this.files[0]);
        }
    });
    
    // Output Format Radio Buttons
    outputFormatRadios.forEach(radio => {
        radio.addEventListener('change', function() {
            if (this.value === 'srt' || this.value === 'vtt') {
                subtitleSettings.style.display = 'block';
            } else {
                subtitleSettings.style.display = 'none';
            }
        });
    });
    
    // Max Line Length Range
    maxLineLength.addEventListener('input', function() {
        maxLineLengthValue.textContent = this.value;
    });
    
    // Transcribe Button
    transcribeBtn.addEventListener('click', function() {
        if (!currentMedia) {
            alert('Please select or upload a file first');
            return;
        }
        
        if (isProcessing) {
            return;
        }
        
        startTranscription();
    });
    
    // Sync Media Button
    syncMediaBtn.addEventListener('click', function() {
        // In a real implementation, this would sync the transcript with the media playback
        alert('This would sync the transcript with the media playback. Clicking on transcript segments would seek to that position in the media.');
    });
    
    // Copy Transcript Button
    copyTranscriptBtn.addEventListener('click', function() {
        if (!transcript) return;
        
        // Create a temporary textarea element to copy the text
        const tempTextarea = document.createElement('textarea');
        tempTextarea.value = transcript.text;
        document.body.appendChild(tempTextarea);
        tempTextarea.select();
        document.execCommand('copy');
        document.body.removeChild(tempTextarea);
        
        alert('Transcript copied to clipboard');
    });
    
    // Download Transcript Button
    downloadTranscriptBtn.addEventListener('click', function() {
        if (!transcript) return;
        
        let format = 'txt';
        outputFormatRadios.forEach(radio => {
            if (radio.checked) {
                format = radio.value;
            }
        });
        
        let content = transcript.text;
        let filename = `transcript.${format}`;
        let mimeType = 'text/plain';
        
        // In a real implementation, the content would be formatted according to the selected format
        if (format === 'srt' || format === 'vtt') {
            // Convert to subtitle format
            content = generateSubtitles(transcript, format);
            mimeType = format === 'srt' ? 'application/x-subrip' : 'text/vtt';
        } else if (format === 'json') {
            content = JSON.stringify(transcript, null, 2);
            mimeType = 'application/json';
        }
        
        // Create a download link
        const blob = new Blob([content], { type: mimeType });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    });
    
    // Edit Transcript Button
    editTranscriptBtn.addEventListener('click', function() {
        if (!transcript) return;
        
        editTranscriptText.value = transcript.text;
        editTranscriptModal.show();
    });
    
    // Save Transcript Button
    saveTranscriptBtn.addEventListener('click', function() {
        const newText = editTranscriptText.value;
        if (newText.trim() === '') {
            alert('Transcript cannot be empty');
            return;
        }
        
        transcript.text = newText;
        updateTranscriptDisplay();
        editTranscriptModal.hide();
    });
    
    // Translate Transcript Button
    translateTranscriptBtn.addEventListener('click', function() {
        if (!transcript) return;
        
        translateTranscriptModal.show();
    });
    
    // Confirm Translate Button
    confirmTranslateBtn.addEventListener('click', function() {
        const sourceLanguage = document.getElementById('sourceLanguage').value;
        const targetLanguage = document.getElementById('targetLanguage').value;
        const preserveFormatting = document.getElementById('preserveFormatting').checked;
        
        if (sourceLanguage === targetLanguage && sourceLanguage !== 'auto') {
            alert('Source and target languages cannot be the same');
            return;
        }
        
        // Show loading state
        this.disabled = true;
        this.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Translating...';
        
        // Simulate translation delay
        setTimeout(() => {
            // Reset button state
            this.disabled = false;
            this.innerHTML = 'Translate';
            
            // In a real implementation, this would call a translation API
            // For demo purposes, we'll just add a prefix to the transcript
            transcript.text = `[Translated to ${getLanguageName(targetLanguage)}]\n\n${transcript.text}`;
            updateTranscriptDisplay();
            
            translateTranscriptModal.hide();
        }, 2000);
    });
    
    // Summarize Button
    summarizeBtn.addEventListener('click', function() {
        if (!transcript) return;
        
        // Reset the summary modal
        summaryContent.innerHTML = '<p class="mb-0 text-muted text-center">Summary will appear here after generation</p>';
        copySummaryBtn.style.display = 'none';
        
        summaryModal.show();
    });
    
    // Generate Summary Button
    generateSummaryBtn.addEventListener('click', function() {
        if (!transcript) return;
        
        const summaryLength = document.querySelector('input[name="summaryLength"]:checked').value;
        const summaryFormat = document.getElementById('summaryFormat').value;
        
        // Show loading state
        this.disabled = true;
        summaryLoading.style.display = 'block';
        summaryContent.style.display = 'none';
        
        // Simulate summary generation delay
        setTimeout(() => {
            // Reset button state
            this.disabled = false;
            summaryLoading.style.display = 'none';
            summaryContent.style.display = 'block';
            
            // In a real implementation, this would call an AI service to generate the summary
            // For demo purposes, we'll just show a sample summary
            let summary = '';
            
            if (summaryFormat === 'paragraph') {
                summary = `<p>This is a sample summary of the transcript. It would be generated using natural language processing to identify the key points and main topics discussed in the audio/video. The length of this summary is based on the selected option (${summaryLength}).</p>
                <p>In a real implementation, the summary would accurately reflect the content of the transcript, highlighting important information and omitting unnecessary details.</p>`;
            } else if (summaryFormat === 'bullet') {
                summary = `<ul>
                    <li>First key point from the transcript would be summarized here.</li>
                    <li>Second important topic or discussion point from the audio/video.</li>
                    <li>Any significant information, facts, or findings mentioned.</li>
                    <li>Conclusions or action items discussed in the content.</li>
                </ul>`;
            } else if (summaryFormat === 'outline') {
                summary = `<div>
                    <h6>1. Introduction</h6>
                    <p class="ms-3 mb-2">Brief overview of the topics discussed in the audio/video.</p>
                    
                    <h6>2. Main Points</h6>
                    <p class="ms-3 mb-1">2.1. First major topic covered.</p>
                    <p class="ms-3 mb-1">2.2. Second major topic or discussion point.</p>
                    <p class="ms-3 mb-2">2.3. Third significant area of discussion.</p>
                    
                    <h6>3. Conclusion</h6>
                    <p class="ms-3 mb-0">Summary of the final points or action items.</p>
                </div>`;
            }
            
            summaryContent.innerHTML = summary;
            copySummaryBtn.style.display = 'inline-block';
        }, 3000);
    });
    
    // Copy Summary Button
    copySummaryBtn.addEventListener('click', function() {
        const summaryText = summaryContent.innerText;
        
        // Create a temporary textarea element to copy the text
        const tempTextarea = document.createElement('textarea');
        tempTextarea.value = summaryText;
        document.body.appendChild(tempTextarea);
        tempTextarea.select();
        document.execCommand('copy');
        document.body.removeChild(tempTextarea);
        
        // Show feedback
        const originalText = this.innerHTML;
        this.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check me-1" viewBox="0 0 16 16"><path d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425a.267.267 0 0 1 .02-.022z"/></svg> Copied!';
        
        setTimeout(() => {
            this.innerHTML = originalText;
        }, 2000);
    });
    
    // Create Subtitles Button
    createSubtitlesBtn.addEventListener('click', function() {
        if (!transcript) return;
        
        createSubtitlesModal.show();
    });
    
    // Confirm Create Subtitles Button
    confirmCreateSubtitlesBtn.addEventListener('click', function() {
        const subtitleFormat = document.getElementById('subtitleFormat').value;
        const subtitleStyle = document.getElementById('subtitleStyle').value;
        const subtitlePosition = document.getElementById('subtitlePosition').value;
        const includeSpeakerNames = document.getElementById('includeSpeakerNames').checked;
        const burnInSubtitles = document.getElementById('burnInSubtitles').checked;
        
        // Show loading state
        this.disabled = true;
        this.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Creating...';
        
        // Simulate processing delay
        setTimeout(() => {
            // Reset button state
            this.disabled = false;
            this.innerHTML = 'Create';
            
            // In a real implementation, this would generate subtitles based on the options
            // For demo purposes, we'll just show an alert
            if (burnInSubtitles) {
                alert(`This would create a new video with ${subtitleFormat.toUpperCase()} subtitles burned in using the ${subtitleStyle} style positioned at the ${subtitlePosition}. Speaker names ${includeSpeakerNames ? 'would' : 'would not'} be included.`);
            } else {
                alert(`This would create a ${subtitleFormat.toUpperCase()} subtitle file with the ${subtitleStyle} style. Speaker names ${includeSpeakerNames ? 'would' : 'would not'} be included.`);
            }
            
            createSubtitlesModal.hide();
        }, 2000);
    });
    
    // New Transcription Button
    newTranscriptionBtn.addEventListener('click', function() {
        resetUI();
    });
    
    // Helper Functions
    
    // Load Media
    function loadMedia(src) {
        currentMedia = src;
        
        // Determine media type based on file extension
        const fileExtension = src.split('.').pop().toLowerCase();
        const videoExtensions = ['mp4', 'webm', 'ogg', 'mov', 'avi', 'wmv', 'flv', 'mkv'];
        const audioExtensions = ['mp3', 'wav', 'ogg', 'aac', 'flac', 'm4a'];
        
        if (videoExtensions.includes(fileExtension)) {
            mediaType = 'video';
            videoPreview.src = src;
            videoPreview.load();
            videoPreview.style.display = 'block';
            audioPreview.style.display = 'none';
        } else if (audioExtensions.includes(fileExtension)) {
            mediaType = 'audio';
            audioPreview.src = src;
            audioPreview.load();
            videoPreview.style.display = 'none';
            audioPreview.style.display = 'block';
        } else {
            alert('Unsupported file format');
            currentMedia = null;
            return;
        }
        
        // Enable the transcribe button
        transcribeBtn.disabled = false;
    }
    
    // Handle Media Upload
    function handleMediaUpload(file) {
        // Check file type
        if (!file.type.startsWith('video/') && !file.type.startsWith('audio/')) {
            alert('Please upload a video or audio file');
            return;
        }
        
        // Create object URL for the file
        const objectURL = URL.createObjectURL(file);
        
        // Update media select to show the uploaded file
        const option = document.createElement('option');
        option.value = objectURL;
        option.textContent = file.name;
        option.selected = true;
        mediaSelect.appendChild(option);
        
        // Load the media
        loadMedia(objectURL);
    }
    
    // Start Transcription
    function startTranscription() {
        if (!currentMedia || isProcessing) return;
        
        isProcessing = true;
        
        // Show loading state
        transcriptionInitialState.style.display = 'none';
        transcriptionLoadingState.style.display = 'block';
        transcriptionResults.style.display = 'none';
        
        // Reset progress
        transcriptionProgressBar.style.width = '0%';
        transcriptionStatusText.textContent = 'Initializing transcription...';
        
        // Get settings
        const language = languageSelect.value;
        const model = modelSelect.value;
        const detectSpeakersEnabled = detectSpeakers.checked;
        const filterProfanityEnabled = filterProfanity.checked;
        const includePunctuationEnabled = includePunctuation.checked;
        const textFormattingEnabled = textFormatting.checked;
        
        // Simulate transcription process
        simulateTranscription(language, model);
    }
    
    // Simulate Transcription
    function simulateTranscription(language, model) {
        let progress = 0;
        const interval = setInterval(() => {
            progress += 5;
            transcriptionProgressBar.style.width = `${progress}%`;
            
            // Update status text at different stages
            if (progress === 10) {
                transcriptionStatusText.textContent = 'Analyzing audio...';
            } else if (progress === 30) {
                transcriptionStatusText.textContent = 'Processing speech...';
            } else if (progress === 50) {
                transcriptionStatusText.textContent = 'Transcribing content...';
            } else if (progress === 70) {
                transcriptionStatusText.textContent = 'Applying formatting...';
            } else if (progress === 90) {
                transcriptionStatusText.textContent = 'Finalizing transcript...';
            }
            
            if (progress >= 100) {
                clearInterval(interval);
                
                // Generate a sample transcript
                generateSampleTranscript();
                
                // Show the results after a short delay
                setTimeout(() => {
                    transcriptionLoadingState.style.display = 'none';
                    transcriptionResults.style.display = 'block';
                    
                    // Show topics and analysis
                    document.getElementById('topicsPlaceholder').style.display = 'none';
                    document.getElementById('topicsRow').style.display = 'flex';
                    
                    isProcessing = false;
                }, 500);
            }
        }, 200);
    }
    
    // Generate Sample Transcript
    function generateSampleTranscript() {
        // In a real implementation, this would be the actual transcription result
        // For demo purposes, we'll create a sample transcript
        transcript = {
            text: `[Speaker 1]: Hello everyone, and welcome to our weekly team meeting. Today, we're going to discuss the progress of our current project and set goals for the upcoming week.

[Speaker 2]: Thanks for organizing this. I have some updates on the development front that I'd like to share.

[Speaker 1]: Great, let's start with that. How is the implementation of the new features coming along?

[Speaker 2]: We've completed about 70% of the planned features for this sprint. The user authentication system is now working properly, and we've implemented the dashboard with real-time data visualization.

[Speaker 1]: That sounds promising. What about the remaining features?

[Speaker 2]: We're still working on the export functionality and the notification system. There were some unexpected challenges with the API integration, but we're making good progress.

[Speaker 3]: I've been testing the dashboard, and I've noticed some performance issues when loading large datasets. Should we prioritize optimization for the next sprint?

[Speaker 2]: Good point. Let's add that to our backlog and discuss it during the planning meeting on Friday.

[Speaker 1]: I agree. User experience is crucial for this project. Let's make sure we address any performance concerns before the release.

[Speaker 3]: I'll prepare a detailed report of the performance issues by tomorrow.

[Speaker 1]: Perfect. Any other updates or concerns that we should discuss?

[Speaker 2]: Yes, one more thing. We need to decide on the deployment strategy. Are we still planning to use a phased rollout?

[Speaker 1]: Yes, that's the plan. We'll start with a small group of beta users next month, gather feedback, and then proceed with the full launch in Q3.

[Speaker 3]: Sounds good to me. I'll coordinate with the marketing team to prepare the communication materials.

[Speaker 1]: Excellent. If there are no other topics, let's wrap up the meeting. Thank you all for your contributions.`,
            duration: 183, // in seconds
            wordCount: 266,
            speakers: ['Speaker 1', 'Speaker 2', 'Speaker 3'],
            confidence: 0.98,
            segments: [
                { speaker: 'Speaker 1', start: 0, end: 12, text: 'Hello everyone, and welcome to our weekly team meeting. Today, we\'re going to discuss the progress of our current project and set goals for the upcoming week.' },
                { speaker: 'Speaker 2', start: 13, end: 20, text: 'Thanks for organizing this. I have some updates on the development front that I\'d like to share.' },
                // Additional segments would be included in a real implementation
            ]
        };
        
        // Update the transcript display
        updateTranscriptDisplay();
    }
    
    // Update Transcript Display
    function updateTranscriptDisplay() {
        if (!transcript) return;
        
        // Format the transcript for display
        let formattedTranscript = '';
        const lines = transcript.text.split('\n');
        
        lines.forEach(line => {
            if (line.trim() === '') {
                formattedTranscript += '<br>';
            } else {
                // Check if the line starts with a speaker label
                if (line.startsWith('[Speaker')) {
                    const speakerEndIndex = line.indexOf(']:');
                    if (speakerEndIndex !== -1) {
                        const speaker = line.substring(0, speakerEndIndex + 1);
                        const text = line.substring(speakerEndIndex + 2);
                        formattedTranscript += `<p><strong class="text-info">${speaker}</strong>${text}</p>`;
                    } else {
                        formattedTranscript += `<p>${line}</p>`;
                    }
                } else {
                    formattedTranscript += `<p>${line}</p>`;
                }
            }
        });
        
        // Update the transcript viewer
        transcriptViewer.innerHTML = formattedTranscript;
        
        // Update word count and duration
        transcriptWordCount.textContent = transcript.wordCount;
        transcriptDuration.textContent = formatTime(transcript.duration);
    }
    
    // Reset UI
    function resetUI() {
        // Reset state variables
        currentMedia = null;
        mediaType = null;
        transcript = null;
        isProcessing = false;
        
        // Reset UI elements
        transcriptionInitialState.style.display = 'block';
        transcriptionLoadingState.style.display = 'none';
        transcriptionResults.style.display = 'none';
        
        // Reset media elements
        videoPreview.src = '';
        audioPreview.src = '';
        videoPreview.style.display = 'block';
        audioPreview.style.display = 'none';
        
        // Reset media select
        mediaSelect.selectedIndex = 0;
        
        // Reset file input
        mediaUpload.value = '';
        
        // Reset topics placeholder
        document.getElementById('topicsPlaceholder').style.display = 'block';
        document.getElementById('topicsRow').style.display = 'none';
    }
    
    // Generate Subtitles
    function generateSubtitles(transcript, format) {
        // In a real implementation, this would parse the transcript and create properly formatted subtitles
        // For demo purposes, we'll just return a simple example
        
        if (format === 'srt') {
            return `1
00:00:00,000 --> 00:00:12,000
[Speaker 1]: Hello everyone, and welcome to our weekly team meeting.

2
00:00:13,000 --> 00:00:20,000
[Speaker 2]: Thanks for organizing this. I have some updates on the development front.

3
00:00:21,000 --> 00:00:25,000
[Speaker 1]: Great, let's start with that. How is the implementation coming along?`;
        } else if (format === 'vtt') {
            return `WEBVTT

00:00:00.000 --> 00:00:12.000
[Speaker 1]: Hello everyone, and welcome to our weekly team meeting.

00:00:13.000 --> 00:00:20.000
[Speaker 2]: Thanks for organizing this. I have some updates on the development front.

00:00:21.000 --> 00:00:25.000
[Speaker 1]: Great, let's start with that. How is the implementation coming along?`;
        }
        
        return transcript.text;
    }
    
    // Format Time
    function formatTime(seconds) {
        const minutes = Math.floor(seconds / 60);
        const remainingSeconds = Math.floor(seconds % 60);
        return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
    }
    
    // Get Language Name
    function getLanguageName(code) {
        const languages = {
            'en': 'English',
            'es': 'Spanish',
            'fr': 'French',
            'de': 'German',
            'it': 'Italian',
            'pt': 'Portuguese',
            'zh': 'Chinese',
            'ja': 'Japanese',
            'ko': 'Korean',
            'ru': 'Russian',
            'ar': 'Arabic',
            'hi': 'Hindi'
        };
        
        return languages[code] || code;
    }
});