document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const videoSelect = document.getElementById('videoSelect');
    const videoPreview = document.getElementById('videoPreview');
    const analyzeVideoBtn = document.getElementById('analyzeVideoBtn');
    const analysisInitialState = document.getElementById('analysisInitialState');
    const analysisLoadingState = document.getElementById('analysisLoadingState');
    const analysisResults = document.getElementById('analysisResults');
    const analysisProgressBar = document.getElementById('analysisProgressBar');
    const analysisStatusText = document.getElementById('analysisStatusText');
    
    // Results elements
    const engagementScore = document.getElementById('engagementScore');
    const optimalDuration = document.getElementById('optimalDuration');
    const currentDuration = document.getElementById('currentDuration');
    
    // Buttons
    const applyRecommendationsBtn = document.getElementById('applyRecommendationsBtn');
    const customizeRecommendationsBtn = document.getElementById('customizeRecommendationsBtn');
    const downloadReportBtn = document.getElementById('downloadReportBtn');
    const editOptimizedBtn = document.getElementById('editOptimizedBtn');
    const applySelectedRecommendationsBtn = document.getElementById('applySelectedRecommendationsBtn');
    
    // Modals
    const customizeRecommendationsModal = new bootstrap.Modal(document.getElementById('customizeRecommendationsModal'));
    
    // Charts
    let videoStructureChart;
    let audienceRetentionChart;
    
    // Video Selection
    videoSelect.addEventListener('change', function() {
        const selectedVideo = this.value;
        if (selectedVideo) {
            videoPreview.src = selectedVideo;
            videoPreview.load();
        }
    });
    
    // Analyze Video Button
    analyzeVideoBtn.addEventListener('click', function() {
        if (!videoSelect.value) {
            alert('Please select a video to analyze');
            return;
        }
        
        // Show loading state
        analysisInitialState.style.display = 'none';
        analysisLoadingState.style.display = 'block';
        analysisResults.style.display = 'none';
        
        // Reset progress
        analysisProgressBar.style.width = '0%';
        analysisStatusText.textContent = 'Initializing analysis...';
        
        // Start the analysis process (simulated)
        simulateAnalysisProcess();
    });
    
    // Customize Recommendations Button
    customizeRecommendationsBtn.addEventListener('click', function() {
        customizeRecommendationsModal.show();
    });
    
    // Apply Recommendations Button
    applyRecommendationsBtn.addEventListener('click', function() {
        alert('This would apply all recommended optimizations to your video. In a real implementation, this would create a new optimized version of your video based on the recommendations.');
    });
    
    // Apply Selected Recommendations Button
    applySelectedRecommendationsBtn.addEventListener('click', function() {
        const selectedRecommendations = [
            ...document.querySelectorAll('#customizeRecommendationsModal input[type="checkbox"]:checked')
        ].map(checkbox => checkbox.id);
        
        alert(`Applying selected recommendations: ${selectedRecommendations.length} items selected. This would apply only the selected optimizations to your video.`);
        
        customizeRecommendationsModal.hide();
    });
    
    // Download Report Button
    downloadReportBtn.addEventListener('click', function() {
        alert('This would generate and download a detailed PDF report with all analytics and recommendations.');
    });
    
    // Edit Optimized Version Button
    editOptimizedBtn.addEventListener('click', function() {
        alert('This would open the optimized version of your video in the editor, allowing you to make further customizations.');
    });
    
    // Simulate the analysis process with progress updates
    function simulateAnalysisProcess() {
        let progress = 0;
        const interval = setInterval(() => {
            progress += 5;
            analysisProgressBar.style.width = `${progress}%`;
            
            // Update status text at different stages
            if (progress === 10) {
                analysisStatusText.textContent = 'Extracting video features...';
            } else if (progress === 30) {
                analysisStatusText.textContent = 'Analyzing content structure...';
            } else if (progress === 50) {
                analysisStatusText.textContent = 'Evaluating engagement factors...';
            } else if (progress === 70) {
                analysisStatusText.textContent = 'Generating recommendations...';
            } else if (progress === 90) {
                analysisStatusText.textContent = 'Finalizing analysis results...';
            }
            
            if (progress >= 100) {
                clearInterval(interval);
                
                // Display results after a short delay
                setTimeout(() => {
                    analysisLoadingState.style.display = 'none';
                    analysisResults.style.display = 'block';
                    
                    // Initialize charts
                    initVideoStructureChart();
                    initAudienceRetentionChart();
                }, 500);
            }
        }, 200);
    }
    
    // Initialize Video Structure Chart
    function initVideoStructureChart() {
        const ctx = document.getElementById('videoStructureChart').getContext('2d');
        
        // Sample data - would be real analysis data in production
        const labels = Array.from({length: 24}, (_, i) => formatTimestamp(i * 15));
        const data = [
            85, 82, 78, 65, 60, 62, 68, 70, 75, 78, 
            80, 65, 60, 55, 57, 62, 65, 70, 68, 72, 
            75, 78, 82, 85
        ];
        
        // Color coding based on engagement levels
        const backgroundColors = data.map(value => {
            if (value >= 75) return 'rgba(40, 167, 69, 0.6)'; // Strong (green)
            if (value >= 65) return 'rgba(255, 193, 7, 0.6)'; // Moderate (yellow)
            return 'rgba(220, 53, 69, 0.6)'; // Low (red)
        });
        
        videoStructureChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Engagement Level',
                    data: data,
                    backgroundColor: backgroundColors,
                    borderColor: backgroundColors.map(color => color.replace('0.6', '1')),
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100,
                        title: {
                            display: true,
                            text: 'Engagement Score'
                        }
                    },
                    x: {
                        title: {
                            display: true,
                            text: 'Video Timeline'
                        }
                    }
                },
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return `Engagement: ${context.raw}/100`;
                            },
                            title: function(context) {
                                return `Timestamp: ${context[0].label}`;
                            }
                        }
                    }
                }
            }
        });
    }
    
    // Initialize Audience Retention Chart
    function initAudienceRetentionChart() {
        const ctx = document.getElementById('audienceRetentionChart').getContext('2d');
        
        // Sample data - would be real analysis data in production
        const labels = Array.from({length: 12}, (_, i) => formatTimestamp(i * 30));
        const data = [100, 95, 85, 80, 78, 75, 70, 65, 60, 55, 52, 50];
        
        audienceRetentionChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Audience Retention',
                    data: data,
                    backgroundColor: 'rgba(13, 110, 253, 0.2)',
                    borderColor: 'rgba(13, 110, 253, 1)',
                    borderWidth: 2,
                    tension: 0.3,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100,
                        title: {
                            display: true,
                            text: 'Retention Percentage'
                        }
                    },
                    x: {
                        title: {
                            display: true,
                            text: 'Video Timeline'
                        }
                    }
                },
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return `Retention: ${context.raw}%`;
                            }
                        }
                    }
                }
            }
        });
    }
    
    // Helper function to format timestamps
    function formatTimestamp(seconds) {
        const minutes = Math.floor(seconds / 60);
        const remainingSeconds = Math.floor(seconds % 60);
        return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
    }
});