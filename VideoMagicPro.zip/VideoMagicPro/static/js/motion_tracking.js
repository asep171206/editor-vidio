document.addEventListener('DOMContentLoaded', function() {
    // Initialize video.js player
    const player = videojs('videoPreview', {
        controls: true,
        autoplay: false,
        preload: 'auto',
        fluid: true,
        responsive: true
    });
    
    // DOM elements
    const videoSelect = document.getElementById('videoSelect');
    const frameCounter = document.getElementById('frameCounter');
    const timeCounter = document.getElementById('timeCounter');
    const prevFrameBtn = document.getElementById('prevFrameBtn');
    const playPauseBtn = document.getElementById('playPauseBtn');
    const nextFrameBtn = document.getElementById('nextFrameBtn');
    const initTrackingBtn = document.getElementById('initTrackingBtn');
    const startTrackingBtn = document.getElementById('startTrackingBtn');
    const cancelTrackingBtn = document.getElementById('cancelTrackingBtn');
    const processTrackingBtn = document.getElementById('processTrackingBtn');
    const trackingProgress = document.getElementById('trackingProgress');
    const trackingProgressBar = trackingProgress.querySelector('.progress-bar');
    const trackedObjectsList = document.getElementById('trackedObjectsList');
    const trackingResultsSection = document.getElementById('trackingResultsSection');
    
    // Modal elements
    const trackObjectModal = new bootstrap.Modal(document.getElementById('trackObjectModal'));
    const attachGraphicModal = new bootstrap.Modal(document.getElementById('attachGraphicModal'));
    const confirmTrackingBtn = document.getElementById('confirmTrackingBtn');
    const confirmAttachGraphicBtn = document.getElementById('confirmAttachGraphicBtn');
    const graphicTypeSelect = document.getElementById('graphicTypeSelect');
    const graphicStyleSelect = document.getElementById('graphicStyleSelect');
    
    // State
    let currentFrame = 0;
    let totalFrames = 0;
    let fps = 30; // Default FPS
    let isTracking = false;
    let trackingMethod = 'auto';
    let selectedTrackId = null;
    let trackedObjects = []; // Array to store tracked objects
    let appliedGraphics = []; // Array to store applied graphics
    
    // Canvas and drawing state
    let selectionCanvas = document.getElementById('objectSelectionCanvas');
    let selectionContext = selectionCanvas.getContext('2d');
    let isDrawing = false;
    let startX, startY, endX, endY;
    
    // Initialize state
    updateTrackingControls();
    
    // Event listeners
    videoSelect.addEventListener('change', function() {
        const selectedVideo = videoSelect.value;
        if (selectedVideo) {
            // Load video preview
            player.src({
                src: selectedVideo,
                type: 'video/mp4'
            });
            player.load();
            
            // Reset state
            currentFrame = 0;
            trackedObjects = [];
            appliedGraphics = [];
            updateTrackingControls();
            updateTrackedObjectsList();
            updateAppliedGraphicsList();
            
            // Update player stats when metadata is loaded
            player.on('loadedmetadata', function() {
                totalFrames = Math.floor(player.duration() * fps);
                updateFrameCounter();
                processTrackingBtn.disabled = false;
            });
            
            // Update time counter as video plays
            player.on('timeupdate', function() {
                currentFrame = Math.floor(player.currentTime() * fps);
                updateFrameCounter();
            });
        }
    });
    
    // Initialize tracking button
    initTrackingBtn.addEventListener('click', function() {
        if (!player.src()) {
            alert('Please select a video first');
            return;
        }
        
        // Pause the video
        player.pause();
        
        // Set up the selection canvas
        const videoElement = player.el().querySelector('video');
        selectionCanvas.width = videoElement.videoWidth;
        selectionCanvas.height = videoElement.videoHeight;
        
        // Clear any previous selection
        selectionContext.clearRect(0, 0, selectionCanvas.width, selectionCanvas.height);
        
        // Reset the tracking object name
        document.getElementById('trackingObjectName').value = 'Object ' + (trackedObjects.length + 1);
        
        // Show the tracking modal
        trackObjectModal.show();
    });
    
    // Canvas drawing events
    selectionCanvas.addEventListener('mousedown', function(e) {
        isDrawing = true;
        const rect = selectionCanvas.getBoundingClientRect();
        startX = (e.clientX - rect.left) * (selectionCanvas.width / rect.width);
        startY = (e.clientY - rect.top) * (selectionCanvas.height / rect.height);
        endX = startX;
        endY = startY;
    });
    
    selectionCanvas.addEventListener('mousemove', function(e) {
        if (!isDrawing) return;
        
        const rect = selectionCanvas.getBoundingClientRect();
        endX = (e.clientX - rect.left) * (selectionCanvas.width / rect.width);
        endY = (e.clientY - rect.top) * (selectionCanvas.height / rect.height);
        
        // Redraw the selection rectangle
        selectionContext.clearRect(0, 0, selectionCanvas.width, selectionCanvas.height);
        selectionContext.strokeStyle = '#0dcaf0';
        selectionContext.lineWidth = 2;
        selectionContext.strokeRect(
            startX, 
            startY, 
            endX - startX, 
            endY - startY
        );
    });
    
    selectionCanvas.addEventListener('mouseup', function() {
        isDrawing = false;
    });
    
    // Confirm tracking button
    confirmTrackingBtn.addEventListener('click', function() {
        if (startX === undefined || endX === undefined) {
            alert('Please select an area to track');
            return;
        }
        
        // Get tracking parameters
        const objectType = document.getElementById('trackingObjectType').value;
        const objectName = document.getElementById('trackingObjectName').value || 'Tracked Object ' + (trackedObjects.length + 1);
        
        // Create a new tracked object
        const newTrackedObject = {
            id: trackedObjects.length + 1,
            name: objectName,
            type: objectType,
            bounds: {
                x: Math.min(startX, endX),
                y: Math.min(startY, endY),
                width: Math.abs(endX - startX),
                height: Math.abs(endY - startY)
            },
            keyframes: {
                [currentFrame]: {
                    x: Math.min(startX, endX),
                    y: Math.min(startY, endY),
                    width: Math.abs(endX - startX),
                    height: Math.abs(endY - startY)
                }
            },
            quality: 98, // Placeholder quality percentage
            visible: true
        };
        
        // Add to tracked objects array
        trackedObjects.push(newTrackedObject);
        
        // Update UI
        updateTrackedObjectsList();
        document.getElementById('trackedObjectsCount').textContent = trackedObjects.length;
        
        // Close modal
        trackObjectModal.hide();
        
        // Update controls
        updateTrackingControls();
        
        // If using auto tracking, simulate the tracking process
        if (trackingMethod === 'auto') {
            simulateAutoTracking(newTrackedObject.id);
        }
    });
    
    // Start tracking button
    startTrackingBtn.addEventListener('click', function() {
        if (trackedObjects.length === 0) {
            alert('No objects to track. Please initialize tracking first.');
            return;
        }
        
        // Set tracking state
        isTracking = true;
        trackingMethod = document.querySelector('input[name="trackingMethod"]:checked').value;
        
        // Show progress for auto tracking
        if (trackingMethod === 'auto') {
            trackingProgress.classList.remove('d-none');
            trackingProgressBar.style.width = '0%';
            
            // Simulate auto tracking for all objects
            trackedObjects.forEach(obj => {
                simulateAutoTracking(obj.id);
            });
        }
        
        // Update controls
        updateTrackingControls();
    });
    
    // Cancel tracking button
    cancelTrackingBtn.addEventListener('click', function() {
        isTracking = false;
        trackingProgress.classList.add('d-none');
        updateTrackingControls();
    });
    
    // Process tracking button
    processTrackingBtn.addEventListener('click', function() {
        if (trackedObjects.length === 0 && appliedGraphics.length === 0) {
            alert('No tracked objects or graphics to process. Please add at least one tracked object or graphic.');
            return;
        }
        
        // Show processing UI
        processTrackingBtn.disabled = true;
        processTrackingBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Processing...';
        
        // Simulate processing delay
        setTimeout(function() {
            // Show results section
            trackingResultsSection.classList.remove('d-none');
            
            // Reset button
            processTrackingBtn.disabled = false;
            processTrackingBtn.textContent = 'Process with Motion Tracking';
            
            // Scroll to results
            trackingResultsSection.scrollIntoView({behavior: 'smooth'});
            
            // Add event listeners to results buttons
            document.querySelector('.preview-btn').addEventListener('click', function() {
                alert('This would preview the processed video with motion tracking');
            });
            
            document.querySelector('.download-btn').addEventListener('click', function() {
                alert('This would download the processed video');
            });
        }, 3000);
    });
    
    // Add event listeners to transport controls
    prevFrameBtn.addEventListener('click', function() {
        if (currentFrame > 0) {
            currentFrame--;
            player.currentTime(currentFrame / fps);
        }
    });
    
    playPauseBtn.addEventListener('click', function() {
        if (player.paused()) {
            player.play();
            playPauseBtn.innerHTML = `
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pause-fill" viewBox="0 0 16 16">
                    <path d="M5.5 3.5A1.5 1.5 0 0 1 7 5v6a1.5 1.5 0 0 1-3 0V5a1.5 1.5 0 0 1 1.5-1.5zm5 0A1.5 1.5 0 0 1 12 5v6a1.5 1.5 0 0 1-3 0V5a1.5 1.5 0 0 1 1.5-1.5z"/>
                </svg>
            `;
        } else {
            player.pause();
            playPauseBtn.innerHTML = `
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-play-fill" viewBox="0 0 16 16">
                    <path d="m11.596 8.697-6.363 3.692c-.54.313-1.233-.066-1.233-.697V4.308c0-.63.692-1.01 1.233-.696l6.363 3.692a.802.802 0 0 1 0 1.393z"/>
                </svg>
            `;
        }
    });
    
    nextFrameBtn.addEventListener('click', function() {
        if (currentFrame < totalFrames - 1) {
            currentFrame++;
            player.currentTime(currentFrame / fps);
        }
    });
    
    // Add event listener to tracking method radio buttons
    document.querySelectorAll('input[name="trackingMethod"]').forEach(radio => {
        radio.addEventListener('change', function() {
            trackingMethod = this.value;
        });
    });
    
    // Tab change event listeners
    document.getElementById('motion-graphics-tab').addEventListener('click', function() {
        // Show tracking analytics if there are tracked objects
        if (trackedObjects.length > 0) {
            document.getElementById('trackingAnalytics').classList.remove('d-none');
        }
    });
    
    // Add event listeners for graphics type select
    graphicTypeSelect.addEventListener('change', function() {
        updateGraphicStyleOptions();
    });
    
    // Add event listener to applied graphics (using event delegation)
    document.getElementById('appliedGraphicsList').addEventListener('click', function(e) {
        if (e.target.classList.contains('graphic-edit') || e.target.closest('.graphic-edit')) {
            const graphicItem = e.target.closest('.applied-graphic-item');
            const graphicId = parseInt(graphicItem.querySelector('.graphic-id').textContent);
            editGraphic(graphicId);
        } else if (e.target.classList.contains('graphic-remove') || e.target.closest('.graphic-remove')) {
            const graphicItem = e.target.closest('.applied-graphic-item');
            const graphicId = parseInt(graphicItem.querySelector('.graphic-id').textContent);
            removeGraphic(graphicId);
        }
    });
    
    // Add event listener to tracked objects (using event delegation)
    trackedObjectsList.addEventListener('click', function(e) {
        if (e.target.classList.contains('track-edit') || e.target.closest('.track-edit')) {
            const trackItem = e.target.closest('.tracked-object-item');
            const trackId = parseInt(trackItem.querySelector('.track-id').textContent);
            editTrack(trackId);
        } else if (e.target.classList.contains('track-delete') || e.target.closest('.track-delete')) {
            const trackItem = e.target.closest('.tracked-object-item');
            const trackId = parseInt(trackItem.querySelector('.track-id').textContent);
            deleteTrack(trackId);
        } else if (e.target.classList.contains('track-attach') || e.target.closest('.track-attach')) {
            const trackItem = e.target.closest('.tracked-object-item');
            const trackId = parseInt(trackItem.querySelector('.track-id').textContent);
            showAttachGraphicModal(trackId);
        }
    });
    
    // Add event listener to confirm attach graphic button
    confirmAttachGraphicBtn.addEventListener('click', function() {
        if (selectedTrackId === null) {
            alert('No track selected');
            return;
        }
        
        const trackObject = trackedObjects.find(obj => obj.id === selectedTrackId);
        if (!trackObject) {
            alert('Track not found');
            return;
        }
        
        // Get graphic details
        const graphicType = graphicTypeSelect.value;
        const graphicStyle = graphicStyleSelect.value;
        const graphicText = document.getElementById('graphicText').value;
        const graphicFontSize = document.getElementById('graphicFontSize').value;
        const graphicColor = document.getElementById('graphicColor').value;
        const graphicOffsetX = parseInt(document.getElementById('graphicOffsetX').value);
        const graphicOffsetY = parseInt(document.getElementById('graphicOffsetY').value);
        const graphicFollowMotion = document.getElementById('graphicFollowMotion').checked;
        const graphicAnimation = document.getElementById('graphicAnimationSelect').value;
        
        // Create a new graphic object
        const newGraphic = {
            id: appliedGraphics.length + 1,
            trackId: selectedTrackId,
            type: graphicType,
            style: graphicStyle,
            content: graphicText,
            fontSize: graphicFontSize,
            color: graphicColor,
            offsetX: graphicOffsetX,
            offsetY: graphicOffsetY,
            followMotion: graphicFollowMotion,
            animation: graphicAnimation,
            visible: true
        };
        
        // Add to applied graphics array
        appliedGraphics.push(newGraphic);
        
        // Update UI
        updateAppliedGraphicsList();
        document.getElementById('appliedGraphicsCount').textContent = appliedGraphics.length;
        
        // Close modal
        attachGraphicModal.hide();
    });
    
    // Attach event listeners to add graphic buttons
    document.querySelectorAll('.add-graphic-btn').forEach(button => {
        button.addEventListener('click', function() {
            const graphicType = this.getAttribute('data-type');
            const graphicName = this.getAttribute('data-name');
            
            if (trackedObjects.length === 0) {
                alert('Please track an object first before adding graphics');
                return;
            }
            
            // Show the attach graphic modal
            showAttachGraphicModal(trackedObjects[0].id, graphicType, graphicName);
        });
    });
    
    // Functions
    function updateFrameCounter() {
        frameCounter.textContent = `Frame: ${currentFrame} / ${totalFrames}`;
        
        // Format time as MM:SS
        const currentTime = formatTime(player.currentTime());
        const totalTime = formatTime(player.duration());
        timeCounter.textContent = `Time: ${currentTime} / ${totalTime}`;
    }
    
    function formatTime(seconds) {
        const minutes = Math.floor(seconds / 60);
        const remainingSeconds = Math.floor(seconds % 60);
        return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
    }
    
    function updateTrackingControls() {
        startTrackingBtn.disabled = trackedObjects.length === 0 || isTracking;
        cancelTrackingBtn.disabled = !isTracking;
        initTrackingBtn.disabled = isTracking;
    }
    
    function updateTrackedObjectsList() {
        // Clear the list
        trackedObjectsList.innerHTML = '';
        
        if (trackedObjects.length === 0) {
            trackedObjectsList.innerHTML = `
                <div class="alert alert-info">
                    <p class="mb-0">No tracked objects yet. Use the tracking controls to create tracking points.</p>
                </div>
            `;
            return;
        }
        
        // Add each tracked object to the list
        trackedObjects.forEach(obj => {
            const objectItem = document.createElement('div');
            objectItem.className = 'tracked-object-item';
            objectItem.innerHTML = `
                <div class="card mb-2">
                    <div class="card-header d-flex justify-content-between align-items-center py-2">
                        <div class="d-flex align-items-center">
                            <span class="badge bg-info me-2 track-id">${obj.id}</span>
                            <h6 class="mb-0 track-name">${obj.name}</h6>
                        </div>
                        <div class="form-check form-switch">
                            <input class="form-check-input track-visibility" type="checkbox" ${obj.visible ? 'checked' : ''}>
                        </div>
                    </div>
                    <div class="card-body p-2">
                        <div class="mb-2">
                            <div class="d-flex justify-content-between align-items-center mb-1">
                                <small>Track Quality</small>
                                <span class="badge bg-success track-quality">${obj.quality}%</span>
                            </div>
                            <div class="progress" style="height: 5px;">
                                <div class="progress-bar bg-success" role="progressbar" style="width: ${obj.quality}%"></div>
                            </div>
                        </div>
                        <div class="d-flex gap-1 mb-2">
                            <div class="form-floating flex-grow-1">
                                <input type="text" class="form-control form-control-sm track-rename" value="${obj.name}">
                                <label>Name</label>
                            </div>
                            <div>
                                <button class="btn btn-outline-danger btn-sm track-delete">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16">
                                        <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z"/>
                                        <path fill-rule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"/>
                                    </svg>
                                </button>
                            </div>
                        </div>
                        <div class="row g-1">
                            <div class="col">
                                <button class="btn btn-sm btn-outline-primary w-100 track-edit">Edit Track</button>
                            </div>
                            <div class="col">
                                <button class="btn btn-sm btn-outline-info w-100 track-keyframes">Keyframes</button>
                            </div>
                            <div class="col">
                                <button class="btn btn-sm btn-outline-success w-100 track-attach">Attach Graphics</button>
                            </div>
                        </div>
                    </div>
                </div>
            `;
            
            trackedObjectsList.appendChild(objectItem);
            
            // Add event listener to visibility toggle
            const visibilityToggle = objectItem.querySelector('.track-visibility');
            visibilityToggle.addEventListener('change', function() {
                obj.visible = this.checked;
            });
            
            // Add event listener to rename input
            const renameInput = objectItem.querySelector('.track-rename');
            renameInput.addEventListener('change', function() {
                obj.name = this.value;
                objectItem.querySelector('.track-name').textContent = this.value;
            });
        });
    }
    
    function updateAppliedGraphicsList() {
        // Get the applied graphics list element
        const appliedGraphicsList = document.getElementById('appliedGraphicsList');
        
        // Clear the list
        appliedGraphicsList.innerHTML = '';
        
        if (appliedGraphics.length === 0) {
            appliedGraphicsList.innerHTML = `
                <div class="alert alert-info">
                    <p class="mb-0">No graphics applied yet. Select a tracked object and attach graphics to it.</p>
                </div>
            `;
            return;
        }
        
        // Add each applied graphic to the list
        appliedGraphics.forEach(graphic => {
            const trackObject = trackedObjects.find(obj => obj.id === graphic.trackId);
            if (!trackObject) return;
            
            const graphicItem = document.createElement('div');
            graphicItem.className = 'applied-graphic-item';
            graphicItem.innerHTML = `
                <div class="card mb-2">
                    <div class="card-header d-flex justify-content-between align-items-center py-2">
                        <div class="d-flex align-items-center">
                            <span class="badge bg-info me-2 graphic-id">${graphic.id}</span>
                            <h6 class="mb-0 graphic-name">${getGraphicDisplayName(graphic)}</h6>
                        </div>
                        <div class="form-check form-switch">
                            <input class="form-check-input graphic-visibility" type="checkbox" ${graphic.visible ? 'checked' : ''}>
                        </div>
                    </div>
                    <div class="card-body p-2">
                        <div class="mb-2">
                            <small class="text-muted">Attached to: <span class="text-light graphic-track">${trackObject.name} (Track #${trackObject.id})</span></small>
                        </div>
                        <div class="mb-2">
                            <div class="input-group input-group-sm">
                                <span class="input-group-text">Content</span>
                                <input type="text" class="form-control graphic-content" value="${graphic.content || ''}">
                            </div>
                        </div>
                        <div class="row g-2 mb-2">
                            <div class="col-6">
                                <div class="input-group input-group-sm">
                                    <span class="input-group-text">Offset X</span>
                                    <input type="number" class="form-control graphic-offset-x" value="${graphic.offsetX}">
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="input-group input-group-sm">
                                    <span class="input-group-text">Offset Y</span>
                                    <input type="number" class="form-control graphic-offset-y" value="${graphic.offsetY}">
                                </div>
                            </div>
                        </div>
                        <div class="row g-1">
                            <div class="col">
                                <button class="btn btn-sm btn-outline-primary w-100 graphic-edit">Edit</button>
                            </div>
                            <div class="col">
                                <button class="btn btn-sm btn-outline-info w-100 graphic-customize">Style</button>
                            </div>
                            <div class="col">
                                <button class="btn btn-sm btn-outline-danger w-100 graphic-remove">Remove</button>
                            </div>
                        </div>
                    </div>
                </div>
            `;
            
            appliedGraphicsList.appendChild(graphicItem);
            
            // Add event listener to visibility toggle
            const visibilityToggle = graphicItem.querySelector('.graphic-visibility');
            visibilityToggle.addEventListener('change', function() {
                graphic.visible = this.checked;
            });
            
            // Add event listener to content input
            const contentInput = graphicItem.querySelector('.graphic-content');
            contentInput.addEventListener('change', function() {
                graphic.content = this.value;
            });
            
            // Add event listeners to offset inputs
            const offsetXInput = graphicItem.querySelector('.graphic-offset-x');
            offsetXInput.addEventListener('change', function() {
                graphic.offsetX = parseInt(this.value);
            });
            
            const offsetYInput = graphicItem.querySelector('.graphic-offset-y');
            offsetYInput.addEventListener('change', function() {
                graphic.offsetY = parseInt(this.value);
            });
        });
    }
    
    function getGraphicDisplayName(graphic) {
        let displayName = '';
        
        switch (graphic.style) {
            case 'basic-text':
                displayName = 'Basic Text';
                break;
            case 'glow-text':
                displayName = 'Glow Text';
                break;
            case 'label-text':
                displayName = 'Label Text';
                break;
            case 'outline-text':
                displayName = 'Outline Text';
                break;
            case 'circle':
                displayName = 'Circle Shape';
                break;
            case 'square':
                displayName = 'Square Shape';
                break;
            case 'triangle':
                displayName = 'Triangle Shape';
                break;
            case 'bounding-box':
                displayName = 'Bounding Box';
                break;
            default:
                displayName = 'Custom Graphic';
        }
        
        return displayName;
    }
    
    function simulateAutoTracking(trackId) {
        // Find the track object
        const trackObject = trackedObjects.find(obj => obj.id === trackId);
        if (!trackObject) return;
        
        // Simulate a tracking progress of 100 frames
        let progress = 0;
        const interval = setInterval(() => {
            progress += 1;
            trackingProgressBar.style.width = `${progress}%`;
            
            if (progress >= 100) {
                clearInterval(interval);
                isTracking = false;
                trackingProgress.classList.add('d-none');
                updateTrackingControls();
                
                // Simulate generating keyframes for the entire video
                for (let frame = 0; frame < totalFrames; frame += 10) {
                    // Create slightly varying bounding box positions for realistic tracking
                    const randomOffsetX = Math.sin(frame * 0.05) * 5;
                    const randomOffsetY = Math.cos(frame * 0.05) * 3;
                    
                    trackObject.keyframes[frame] = {
                        x: trackObject.bounds.x + randomOffsetX,
                        y: trackObject.bounds.y + randomOffsetY,
                        width: trackObject.bounds.width,
                        height: trackObject.bounds.height
                    };
                }
                
                // Show an alert when tracking is complete
                alert(`Auto-tracking complete for "${trackObject.name}". Generated ${Object.keys(trackObject.keyframes).length} keyframes.`);
            }
        }, 30);
    }
    
    function editTrack(trackId) {
        const trackObject = trackedObjects.find(obj => obj.id === trackId);
        if (!trackObject) return;
        
        // For demo purposes, we'll just show an alert
        alert(`Editing track "${trackObject.name}" (ID: ${trackId})\n\nIn a real implementation, this would open a track editor interface.`);
    }
    
    function deleteTrack(trackId) {
        if (!confirm('Are you sure you want to delete this track?')) return;
        
        // Find the track index
        const trackIndex = trackedObjects.findIndex(obj => obj.id === trackId);
        if (trackIndex === -1) return;
        
        // Remove the track
        trackedObjects.splice(trackIndex, 1);
        
        // Remove any associated graphics
        appliedGraphics = appliedGraphics.filter(graphic => graphic.trackId !== trackId);
        
        // Update UI
        updateTrackedObjectsList();
        updateAppliedGraphicsList();
        document.getElementById('trackedObjectsCount').textContent = trackedObjects.length;
        document.getElementById('appliedGraphicsCount').textContent = appliedGraphics.length;
    }
    
    function showAttachGraphicModal(trackId, graphicType = 'text', graphicStyle = 'basic-text') {
        selectedTrackId = trackId;
        
        // Set the selected graphic type and style
        graphicTypeSelect.value = graphicType;
        updateGraphicStyleOptions();
        graphicStyleSelect.value = graphicStyle;
        
        // Set default text if it's a text graphic
        if (graphicType === 'text') {
            const trackObject = trackedObjects.find(obj => obj.id === trackId);
            document.getElementById('graphicText').value = trackObject ? trackObject.name : 'Text';
        }
        
        // Show the modal
        attachGraphicModal.show();
    }
    
    function updateGraphicStyleOptions() {
        const graphicType = graphicTypeSelect.value;
        
        // Clear existing options
        graphicStyleSelect.innerHTML = '';
        
        // Add options based on graphic type
        switch (graphicType) {
            case 'text':
                graphicStyleSelect.innerHTML = `
                    <option value="basic-text">Basic Text</option>
                    <option value="glow-text">Glow Text</option>
                    <option value="label-text">Label Text</option>
                    <option value="outline-text">Outline Text</option>
                `;
                document.getElementById('textGraphicOptions').style.display = 'block';
                break;
            case 'shape':
                graphicStyleSelect.innerHTML = `
                    <option value="circle">Circle</option>
                    <option value="square">Square</option>
                    <option value="triangle">Triangle</option>
                    <option value="bounding-box">Bounding Box</option>
                `;
                document.getElementById('textGraphicOptions').style.display = 'none';
                break;
            case 'mask':
                graphicStyleSelect.innerHTML = `
                    <option value="circular-mask">Circular Mask</option>
                    <option value="rounded-mask">Rounded Mask</option>
                    <option value="blur-mask">Blur Mask</option>
                    <option value="pixelate-mask">Pixelate Mask</option>
                `;
                document.getElementById('textGraphicOptions').style.display = 'none';
                break;
            case 'animated':
                graphicStyleSelect.innerHTML = `
                    <option value="spinner">Spinner</option>
                    <option value="pulse">Pulse</option>
                    <option value="call-out">Call-out Text</option>
                    <option value="target">Target</option>
                `;
                document.getElementById('textGraphicOptions').style.display = 'none';
                break;
        }
    }
    
    function editGraphic(graphicId) {
        const graphic = appliedGraphics.find(g => g.id === graphicId);
        if (!graphic) return;
        
        // For demo purposes, we'll just show an alert
        alert(`Editing graphic "${getGraphicDisplayName(graphic)}" (ID: ${graphicId})\n\nIn a real implementation, this would open a graphic editor interface.`);
    }
    
    function removeGraphic(graphicId) {
        if (!confirm('Are you sure you want to remove this graphic?')) return;
        
        // Find the graphic index
        const graphicIndex = appliedGraphics.findIndex(g => g.id === graphicId);
        if (graphicIndex === -1) return;
        
        // Remove the graphic
        appliedGraphics.splice(graphicIndex, 1);
        
        // Update UI
        updateAppliedGraphicsList();
        document.getElementById('appliedGraphicsCount').textContent = appliedGraphics.length;
    }
});