document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const mediaSearch = document.getElementById('mediaSearch');
    const mediaSearchBtn = document.getElementById('mediaSearchBtn');
    const uploadMediaBtn = document.getElementById('uploadMediaBtn');
    const createCollectionBtn = document.getElementById('createCollectionBtn');
    const manageUploadsBtn = document.getElementById('manageUploadsBtn');
    const mediaPreviewModal = new bootstrap.Modal(document.getElementById('mediaPreviewModal'));
    const uploadMediaModal = new bootstrap.Modal(document.getElementById('uploadMediaModal'));
    const createCollectionModal = new bootstrap.Modal(document.getElementById('createCollectionModal'));
    
    // Media preview elements
    const previewVideo = document.getElementById('previewVideo');
    const previewAudio = document.getElementById('previewAudio');
    const previewImage = document.getElementById('previewImage');
    const videoPreviewContainer = document.getElementById('videoPreviewContainer');
    const audioPreviewContainer = document.getElementById('audioPreviewContainer');
    const imagePreviewContainer = document.getElementById('imagePreviewContainer');
    const mediaPreviewModalLabel = document.getElementById('mediaPreviewModalLabel');
    const addMediaFromPreviewBtn = document.getElementById('addMediaFromPreviewBtn');
    
    // Upload modal elements
    const mediaFiles = document.getElementById('mediaFiles');
    const mediaCollection = document.getElementById('mediaCollection');
    const mediaTags = document.getElementById('mediaTags');
    const uploadProgress = document.getElementById('uploadProgress');
    const uploadProgressBar = uploadProgress.querySelector('.progress-bar');
    const confirmUploadBtn = document.getElementById('confirmUploadBtn');
    
    // Create collection modal elements
    const collectionName = document.getElementById('collectionName');
    const collectionDescription = document.getElementById('collectionDescription');
    const confirmCreateCollectionBtn = document.getElementById('confirmCreateCollectionBtn');
    
    // Audio player for music and sound effects
    const audioPlayer = document.getElementById('audioPlayer');
    
    // Current media being previewed
    let currentPreviewMedia = null;
    
    // Initialize video hover previews
    initVideoHoverPreviews();
    
    // Event Listeners
    
    // Search functionality
    mediaSearchBtn.addEventListener('click', function() {
        const searchTerm = mediaSearch.value.trim().toLowerCase();
        if (searchTerm) {
            // Perform search
            searchMedia(searchTerm);
        }
    });
    
    mediaSearch.addEventListener('keyup', function(e) {
        if (e.key === 'Enter') {
            const searchTerm = mediaSearch.value.trim().toLowerCase();
            if (searchTerm) {
                searchMedia(searchTerm);
            }
        }
    });
    
    // Media filter functionality
    document.querySelectorAll('.media-filter').forEach(filter => {
        filter.addEventListener('click', function(e) {
            e.preventDefault();
            const filterType = this.getAttribute('data-filter');
            filterMedia(filterType);
        });
    });
    
    // Preview media buttons
    document.querySelectorAll('.preview-media-btn').forEach(button => {
        button.addEventListener('click', function() {
            const mediaType = this.getAttribute('data-type');
            const mediaSrc = this.getAttribute('data-src');
            
            if (mediaType && mediaSrc) {
                showMediaPreview(mediaType, mediaSrc);
            }
        });
    });
    
    // Add to project buttons
    document.querySelectorAll('.add-to-project-btn').forEach(button => {
        button.addEventListener('click', function() {
            const mediaType = this.getAttribute('data-type');
            const mediaId = this.getAttribute('data-id');
            
            if (mediaType && mediaId) {
                addMediaToProject(mediaType, mediaId);
            }
        });
    });
    
    // Play audio buttons (for music and sound effects)
    document.querySelectorAll('.play-audio-btn').forEach(button => {
        button.addEventListener('click', function() {
            const audioId = this.getAttribute('data-audio-id');
            toggleAudioPlayback(audioId, this);
        });
    });
    
    // Upload media button
    uploadMediaBtn.addEventListener('click', function() {
        // Reset the upload form
        mediaFiles.value = '';
        mediaCollection.value = '';
        mediaTags.value = '';
        uploadProgress.style.display = 'none';
        uploadProgressBar.style.width = '0%';
        
        // Show the upload modal
        uploadMediaModal.show();
    });
    
    // Confirm upload button
    confirmUploadBtn.addEventListener('click', function() {
        const files = mediaFiles.files;
        
        if (files.length === 0) {
            alert('Please select at least one file to upload');
            return;
        }
        
        // Simulate upload process
        uploadProgress.style.display = 'block';
        confirmUploadBtn.disabled = true;
        
        let progress = 0;
        const interval = setInterval(() => {
            progress += 5;
            uploadProgressBar.style.width = `${progress}%`;
            
            if (progress >= 100) {
                clearInterval(interval);
                
                // Show success message
                setTimeout(() => {
                    alert('Files uploaded successfully!');
                    uploadMediaModal.hide();
                    confirmUploadBtn.disabled = false;
                }, 500);
            }
        }, 200);
        
        // In a real implementation:
        // - Create a FormData object
        // - Append files and metadata (collection, tags)
        // - Send AJAX request to server
        // - Update progress based on upload progress
        // - Show success/error message
    });
    
    // Create collection button
    createCollectionBtn.addEventListener('click', function() {
        // Reset the form
        collectionName.value = '';
        collectionDescription.value = '';
        
        // Show the create collection modal
        createCollectionModal.show();
    });
    
    // Confirm create collection button
    confirmCreateCollectionBtn.addEventListener('click', function() {
        const name = collectionName.value.trim();
        
        if (!name) {
            alert('Please enter a collection name');
            return;
        }
        
        // Show success message
        alert(`Collection "${name}" created successfully!`);
        createCollectionModal.hide();
        
        // In a real implementation:
        // - Send collection data to server
        // - Update UI with new collection
    });
    
    // Manage uploads button
    manageUploadsBtn.addEventListener('click', function() {
        // In a real implementation, this would open a page or modal for managing uploads
        alert('This would open the uploads management interface');
    });
    
    // Add media from preview button
    addMediaFromPreviewBtn.addEventListener('click', function() {
        if (currentPreviewMedia) {
            addMediaToProject(currentPreviewMedia.type, currentPreviewMedia.id);
            mediaPreviewModal.hide();
        }
    });
    
    // Functions
    
    function searchMedia(term) {
        // In a real implementation, this would send a search request to the server
        // For demo purposes, we'll just show an alert
        alert(`Searching for: ${term}`);
        
        // Simulate search results by showing a subset of items
        // This would be replaced with actual filtered results from the server
        document.querySelectorAll('.card').forEach(card => {
            const title = card.querySelector('.card-title');
            if (title && title.textContent.toLowerCase().includes(term)) {
                card.closest('.col-md-3, .col-md-4').style.display = 'block';
            } else {
                card.closest('.col-md-3, .col-md-4').style.display = 'none';
            }
        });
    }
    
    function filterMedia(type) {
        // In a real implementation, this would filter media by type
        // For demo purposes, we'll just show an alert
        alert(`Filtering by: ${type}`);
        
        // Simulate filter by showing only certain tabs
        if (type === 'all') {
            // Show all tabs
            document.getElementById('stock-videos-tab').click();
        } else if (type === 'video') {
            document.getElementById('stock-videos-tab').click();
        } else if (type === 'music') {
            document.getElementById('music-tab').click();
        } else if (type === 'sound') {
            document.getElementById('sound-effects-tab').click();
        } else if (type === 'image') {
            document.getElementById('images-tab').click();
        }
    }
    
    function showMediaPreview(type, src) {
        // Reset preview containers
        videoPreviewContainer.style.display = 'none';
        audioPreviewContainer.style.display = 'none';
        imagePreviewContainer.style.display = 'none';
        
        // Set the current preview media
        currentPreviewMedia = {
            type: type,
            src: src,
            id: extractIdFromSrc(src)
        };
        
        // Update modal title
        mediaPreviewModalLabel.textContent = `${type.charAt(0).toUpperCase() + type.slice(1)} Preview`;
        
        // Show the appropriate preview based on media type
        if (type === 'video') {
            previewVideo.src = src;
            videoPreviewContainer.style.display = 'block';
            previewVideo.load();
        } else if (type === 'audio' || type === 'music' || type === 'sound') {
            previewAudio.src = src;
            audioPreviewContainer.style.display = 'block';
            previewAudio.load();
        } else if (type === 'image') {
            previewImage.src = src;
            imagePreviewContainer.style.display = 'block';
        }
        
        // Show the preview modal
        mediaPreviewModal.show();
    }
    
    function addMediaToProject(type, id) {
        // In a real implementation, this would add the media to the current project
        // For demo purposes, we'll just show an alert
        alert(`Added ${type} (ID: ${id}) to your project`);
    }
    
    function toggleAudioPlayback(audioId, button) {
        // Check if this is the current playing audio
        if (audioPlayer.getAttribute('data-playing-id') === audioId) {
            // Toggle pause/play
            if (audioPlayer.paused) {
                audioPlayer.play();
                updatePlayButton(button, true);
            } else {
                audioPlayer.pause();
                updatePlayButton(button, false);
            }
        } else {
            // Reset all play buttons
            document.querySelectorAll('.play-audio-btn').forEach(btn => {
                updatePlayButton(btn, false);
            });
            
            // Start playing new audio
            // In a real implementation, this would fetch the audio file URL
            // For demo, we'll use a placeholder
            audioPlayer.src = `https://example.com/audio/${audioId}.mp3`;
            audioPlayer.setAttribute('data-playing-id', audioId);
            
            // In a real implementation, this would play the audio
            // For demo, we'll just show an alert
            alert(`Playing audio: ${audioId}`);
            
            // Update the button state
            updatePlayButton(button, true);
        }
    }
    
    function updatePlayButton(button, isPlaying) {
        if (isPlaying) {
            button.innerHTML = `
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pause-fill" viewBox="0 0 16 16">
                    <path d="M5.5 3.5A1.5 1.5 0 0 1 7 5v6a1.5 1.5 0 0 1-3 0V5a1.5 1.5 0 0 1 1.5-1.5zm5 0A1.5 1.5 0 0 1 12 5v6a1.5 1.5 0 0 1-3 0V5a1.5 1.5 0 0 1 1.5-1.5z"/>
                </svg>
            `;
        } else {
            button.innerHTML = `
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-play-fill" viewBox="0 0 16 16">
                    <path d="m11.596 8.697-6.363 3.692c-.54.313-1.233-.066-1.233-.697V4.308c0-.63.692-1.01 1.233-.696l6.363 3.692a.802.802 0 0 1 0 1.393z"/>
                </svg>
            `;
        }
    }
    
    function extractIdFromSrc(src) {
        // Extract the ID from the source URL or path
        // This is a simplified implementation
        const parts = src.split('/');
        const filename = parts[parts.length - 1];
        const id = filename.split('.')[0];
        return id;
    }
    
    function initVideoHoverPreviews() {
        // Add hover event listeners to video thumbnails
        document.querySelectorAll('.ratio.ratio-16x9 video').forEach(video => {
            const parentCard = video.closest('.card');
            
            if (parentCard) {
                parentCard.addEventListener('mouseenter', function() {
                    video.play().catch(e => {
                        // Ignore autoplay errors
                        console.log('Autoplay not allowed:', e);
                    });
                });
                
                parentCard.addEventListener('mouseleave', function() {
                    video.pause();
                    video.currentTime = 0;
                });
            }
        });
    }
});