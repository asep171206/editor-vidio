document.addEventListener('DOMContentLoaded', function() {
    // Initialize video.js player
    const player = videojs('videoPreview', {
        controls: true,
        autoplay: false,
        preload: 'auto',
        fluid: true,
        responsive: true
    });
    
    // DOM elements
    const videoSelect = document.getElementById('videoSelect');
    const apiKeyInput = document.getElementById('apiKey');
    const analyzeBtn = document.getElementById('analyzeBtn');
    const processBtn = document.getElementById('processBtn');
    const resultsSection = document.getElementById('resultsSection');
    const analysisResults = document.getElementById('analysisResults');
    const processedFilesTable = document.getElementById('processedFilesTable');
    const thumbnailsSection = document.getElementById('thumbnailsSection');
    const thumbnailGallery = document.getElementById('thumbnailGallery');
    
    // Enable buttons when a video is selected
    videoSelect.addEventListener('change', function() {
        const selectedVideo = videoSelect.value;
        analyzeBtn.disabled = !selectedVideo;
        processBtn.disabled = !selectedVideo;
        
        if (selectedVideo) {
            // Load video preview
            player.src({
                src: selectedVideo,
                type: 'video/mp4'
            });
            player.load();
            
            // Hide results from previous analysis
            resultsSection.classList.add('d-none');
        }
    });
    
    // Handle AI feature checkboxes
    const aiFeatures = document.querySelectorAll('.ai-feature');
    aiFeatures.forEach(checkbox => {
        checkbox.addEventListener('change', function() {
            // At least one feature must be selected for analysis
            analyzeBtn.disabled = !videoSelect.value || 
                ![...aiFeatures].some(cb => cb.checked);
        });
    });
    
    // Handle smart feature checkboxes
    const smartFeatures = document.querySelectorAll('.smart-feature');
    smartFeatures.forEach(checkbox => {
        checkbox.addEventListener('change', function() {
            // Check if subtitle generation is selected but no API key
            const subtitleChecked = document.getElementById('subtitleGeneration').checked;
            const apiKeyNeeded = subtitleChecked && !apiKeyInput.value.trim();
            
            // At least one feature must be selected for processing
            processBtn.disabled = !videoSelect.value || 
                ![...smartFeatures].some(cb => cb.checked) ||
                apiKeyNeeded;
            
            // Show API key warning if needed
            if (this.id === 'subtitleGeneration') {
                if (this.checked && !apiKeyInput.value.trim()) {
                    alert('Subtitle generation requires an OpenAI API key. Please enter your API key.');
                }
            }
        });
    });
    
    // Handle API key input
    apiKeyInput.addEventListener('input', function() {
        // If subtitle generation is checked, enable/disable process button based on API key
        if (document.getElementById('subtitleGeneration').checked) {
            processBtn.disabled = !this.value.trim() || !videoSelect.value;
        }
    });
    
    // Handle analyze button click
    analyzeBtn.addEventListener('click', function() {
        const selectedVideo = videoSelect.value;
        const selectedFeatures = [];
        
        aiFeatures.forEach(checkbox => {
            if (checkbox.checked) {
                selectedFeatures.push(checkbox.dataset.feature);
            }
        });
        
        if (!selectedVideo || selectedFeatures.length === 0) {
            return;
        }
        
        // Show loading state
        analyzeBtn.disabled = true;
        analyzeBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Analyzing...';
        
        // Send analysis request
        const formData = new FormData();
        formData.append('video_path', selectedVideo);
        formData.append('features', JSON.stringify(selectedFeatures));
        
        fetch('/analyze_video', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            // Reset button
            analyzeBtn.disabled = false;
            analyzeBtn.textContent = 'Analyze Content';
            
            // Show results section
            resultsSection.classList.remove('d-none');
            
            // Display analysis results
            displayAnalysisResults(data);
        })
        .catch(error => {
            console.error('Error analyzing video:', error);
            analyzeBtn.disabled = false;
            analyzeBtn.textContent = 'Analyze Content';
            
            analysisResults.innerHTML = `
                <div class="alert alert-danger">
                    Error analyzing video: ${error.message || 'Unknown error'}
                </div>
            `;
            resultsSection.classList.remove('d-none');
        });
    });
    
    // Handle process button click
    processBtn.addEventListener('click', function() {
        const selectedVideo = videoSelect.value;
        const apiKey = apiKeyInput.value.trim();
        const selectedFeatures = [];
        
        smartFeatures.forEach(checkbox => {
            if (checkbox.checked) {
                selectedFeatures.push(checkbox.dataset.feature);
            }
        });
        
        if (!selectedVideo || selectedFeatures.length === 0) {
            return;
        }
        
        // Check if API key is needed but not provided
        if (document.getElementById('subtitleGeneration').checked && !apiKey) {
            alert('Subtitle generation requires an OpenAI API key. Please enter your API key.');
            return;
        }
        
        // Show loading state
        processBtn.disabled = true;
        processBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Processing...';
        
        // Send processing request
        const formData = new FormData();
        formData.append('video_path', selectedVideo);
        formData.append('features', JSON.stringify(selectedFeatures));
        if (apiKey) {
            formData.append('api_key', apiKey);
        }
        
        fetch('/process_video_ai', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            // Reset button
            processBtn.disabled = false;
            processBtn.textContent = 'Process Video';
            
            // Show results section
            resultsSection.classList.remove('d-none');
            
            // Display processed results
            displayProcessedResults(data);
        })
        .catch(error => {
            console.error('Error processing video:', error);
            processBtn.disabled = false;
            processBtn.textContent = 'Process Video';
            
            const errorMessage = document.createElement('div');
            errorMessage.className = 'alert alert-danger';
            errorMessage.textContent = `Error processing video: ${error.message || 'Unknown error'}`;
            
            processedFilesTable.innerHTML = '';
            const row = document.createElement('tr');
            const cell = document.createElement('td');
            cell.colSpan = 3;
            cell.appendChild(errorMessage);
            row.appendChild(cell);
            processedFilesTable.appendChild(row);
            
            resultsSection.classList.remove('d-none');
        });
    });
    
    // Function to display analysis results
    function displayAnalysisResults(data) {
        analysisResults.innerHTML = '';
        
        if (data.error) {
            const errorDiv = document.createElement('div');
            errorDiv.className = 'alert alert-danger';
            errorDiv.textContent = `Error: ${data.error}`;
            analysisResults.appendChild(errorDiv);
            return;
        }
        
        // Create result sections for each feature
        if (data.face_detection) {
            const faceSection = createAnalysisSection('Face Detection', data.face_detection);
            analysisResults.appendChild(faceSection);
        }
        
        if (data.object_recognition) {
            const objectSection = createAnalysisSection('Object Recognition', data.object_recognition);
            analysisResults.appendChild(objectSection);
        }
        
        if (data.scene_detection) {
            const sceneSection = createAnalysisSection('Scene Detection', data.scene_detection);
            analysisResults.appendChild(sceneSection);
        }
        
        if (data.audio_analysis) {
            const audioSection = createAnalysisSection('Audio Analysis', data.audio_analysis);
            analysisResults.appendChild(audioSection);
        }
        
        // If no results
        if (analysisResults.children.length === 0) {
            const noResults = document.createElement('div');
            noResults.className = 'alert alert-info';
            noResults.textContent = 'No analysis results available.';
            analysisResults.appendChild(noResults);
        }
    }
    
    // Function to create an analysis section
    function createAnalysisSection(title, data) {
        const section = document.createElement('div');
        section.className = 'mb-4';
        
        // Section title
        const sectionTitle = document.createElement('h6');
        sectionTitle.className = 'border-bottom pb-2 mb-3';
        sectionTitle.textContent = title;
        section.appendChild(sectionTitle);
        
        // Section content
        if (data.summary) {
            const summaryDiv = document.createElement('div');
            summaryDiv.className = 'mb-3';
            
            // Format the summary as bullet points
            const summaryList = document.createElement('ul');
            summaryList.className = 'list-unstyled';
            
            for (const [key, value] of Object.entries(data.summary)) {
                // Skip complex nested objects
                if (typeof value === 'object' && value !== null) {
                    continue;
                }
                
                const listItem = document.createElement('li');
                const formattedKey = key.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
                
                // Format value based on type
                let formattedValue = value;
                if (typeof value === 'number') {
                    if (key.includes('percentage')) {
                        formattedValue = value.toFixed(1) + '%';
                    } else if (value > 1000) {
                        formattedValue = value.toLocaleString();
                    } else {
                        formattedValue = value.toFixed(2);
                    }
                }
                
                listItem.innerHTML = `<strong>${formattedKey}:</strong> ${formattedValue}`;
                summaryList.appendChild(listItem);
            }
            
            summaryDiv.appendChild(summaryList);
            section.appendChild(summaryDiv);
        }
        
        return section;
    }
    
    // Function to display processed results
    function displayProcessedResults(data) {
        processedFilesTable.innerHTML = '';
        thumbnailGallery.innerHTML = '';
        thumbnailsSection.classList.add('d-none');
        
        if (data.error) {
            const row = document.createElement('tr');
            const cell = document.createElement('td');
            cell.colSpan = 3;
            
            const errorDiv = document.createElement('div');
            errorDiv.className = 'alert alert-danger';
            errorDiv.textContent = `Error: ${data.error}`;
            
            cell.appendChild(errorDiv);
            row.appendChild(cell);
            processedFilesTable.appendChild(row);
            return;
        }
        
        // Add rows for each processed file
        let hasResults = false;
        
        if (data.subtitle_generation && !data.subtitle_generation.error) {
            addProcessedRow('Subtitle Generation', data.subtitle_generation);
            hasResults = true;
        }
        
        if (data.highlight_detection && !data.highlight_detection.error) {
            addProcessedRow('Highlight Detection', data.highlight_detection);
            hasResults = true;
        }
        
        if (data.jump_cut && !data.jump_cut.error) {
            addProcessedRow('Automatic Jump Cut', data.jump_cut);
            hasResults = true;
        }
        
        if (data.beat_detection && !data.beat_detection.error) {
            addProcessedRow('Beat Detection & Sync', data.beat_detection);
            hasResults = true;
        }
        
        if (data.noise_reduction && !data.noise_reduction.error) {
            addProcessedRow('Audio Noise Reduction', data.noise_reduction);
            hasResults = true;
        }
        
        // Handle thumbnails separately
        if (data.thumbnail_generation && !data.thumbnail_generation.error && 
            data.thumbnail_generation.thumbnails && 
            data.thumbnail_generation.thumbnails.length > 0) {
            
            addProcessedRow('Thumbnail Generation', data.thumbnail_generation);
            displayThumbnails(data.thumbnail_generation.thumbnails);
            hasResults = true;
        }
        
        // If no results
        if (!hasResults) {
            const row = document.createElement('tr');
            const cell = document.createElement('td');
            cell.colSpan = 3;
            cell.textContent = 'No processed files available.';
            row.appendChild(cell);
            processedFilesTable.appendChild(row);
        }
    }
    
    // Function to add a processed file row
    function addProcessedRow(featureName, data) {
        const row = document.createElement('tr');
        
        // Feature name cell
        const featureCell = document.createElement('td');
        featureCell.textContent = featureName;
        row.appendChild(featureCell);
        
        // Output file cell
        const fileCell = document.createElement('td');
        if (data.output_path) {
            const fileName = data.output_path.split('/').pop();
            fileCell.textContent = fileName;
        } else if (data.subtitle_path) {
            const fileName = data.subtitle_path.split('/').pop();
            fileCell.textContent = fileName;
        } else {
            fileCell.textContent = 'N/A';
        }
        row.appendChild(fileCell);
        
        // Actions cell
        const actionsCell = document.createElement('td');
        
        // Preview button (for video files)
        if ((data.output_path && data.output_path.match(/\.(mp4|avi|mov|mkv)$/i)) ||
            (data.subtitle_path && data.subtitle_path.match(/\.(mp4|avi|mov|mkv)$/i))) {
            
            const previewBtn = document.createElement('button');
            previewBtn.className = 'btn btn-sm btn-outline-primary me-2';
            previewBtn.textContent = 'Preview';
            previewBtn.addEventListener('click', function() {
                const videoPath = data.output_path || data.subtitle_path;
                player.src({
                    src: videoPath,
                    type: 'video/mp4'
                });
                player.load();
                player.play();
                
                // Scroll to video preview
                videoSelect.scrollIntoView({
                    behavior: 'smooth'
                });
            });
            actionsCell.appendChild(previewBtn);
        }
        
        // Download button
        const downloadBtn = document.createElement('a');
        downloadBtn.className = 'btn btn-sm btn-outline-success';
        downloadBtn.textContent = 'Download';
        downloadBtn.href = data.output_path || data.subtitle_path || '#';
        downloadBtn.download = '';
        if (!data.output_path && !data.subtitle_path) {
            downloadBtn.disabled = true;
        }
        actionsCell.appendChild(downloadBtn);
        
        row.appendChild(actionsCell);
        processedFilesTable.appendChild(row);
    }
    
    // Function to display thumbnails
    function displayThumbnails(thumbnails) {
        thumbnailsSection.classList.remove('d-none');
        thumbnailGallery.innerHTML = '';
        
        thumbnails.forEach(thumbnail => {
            const col = document.createElement('div');
            col.className = 'col-md-4 col-sm-6 mb-3';
            
            const card = document.createElement('div');
            card.className = 'card h-100';
            
            const img = document.createElement('img');
            img.className = 'card-img-top';
            img.src = thumbnail.path;
            img.alt = `Thumbnail ${thumbnail.rank}`;
            
            const cardBody = document.createElement('div');
            cardBody.className = 'card-body';
            
            const cardTitle = document.createElement('h6');
            cardTitle.className = 'card-title';
            cardTitle.textContent = `Thumbnail ${thumbnail.rank}`;
            
            const scoreText = document.createElement('p');
            scoreText.className = 'card-text small';
            scoreText.innerHTML = `<strong>Score:</strong> ${(thumbnail.score * 100).toFixed(1)}%<br>
                                 <strong>Time:</strong> ${thumbnail.time.toFixed(2)}s`;
            
            const downloadLink = document.createElement('a');
            downloadLink.href = thumbnail.path;
            downloadLink.className = 'btn btn-sm btn-outline-primary';
            downloadLink.textContent = 'Download';
            downloadLink.download = '';
            
            cardBody.appendChild(cardTitle);
            cardBody.appendChild(scoreText);
            cardBody.appendChild(downloadLink);
            
            card.appendChild(img);
            card.appendChild(cardBody);
            
            col.appendChild(card);
            thumbnailGallery.appendChild(col);
        });
    }
});