document.addEventListener('DOMContentLoaded', function() {
    // DOM elements
    const projectsList = document.getElementById('projectsList');
    const projectSearchInput = document.getElementById('projectSearchInput');
    const projectSearchBtn = document.getElementById('projectSearchBtn');
    const newProjectBtn = document.getElementById('newProjectBtn');
    const createProjectBtn = document.getElementById('createProjectBtn');
    const sortOptions = document.querySelectorAll('.sort-option');
    
    // Modals
    const newProjectModal = new bootstrap.Modal(document.getElementById('newProjectModal'));
    const projectDetailsModal = new bootstrap.Modal(document.getElementById('projectDetailsModal'));
    
    // Sample projects data (would be loaded from server in a real implementation)
    let projects = [
        {
            id: 1,
            name: "Summer Vacation Video",
            description: "Compilation of summer vacation memories",
            createdDate: "2025-05-10",
            editedDate: "2025-05-20",
            resolution: "1080p",
            ratio: "16:9",
            template: "Vlog",
            thumbnail: null,
            files: [
                { name: "beach.mp4", type: "Video", size: "45.7 MB", duration: "1:30" },
                { name: "mountains.mp4", type: "Video", size: "62.3 MB", duration: "2:15" },
                { name: "summer_vibes.mp3", type: "Audio", size: "5.8 MB", duration: "3:45" }
            ],
            settings: {
                colorCorrection: true,
                autoTrim: true,
                stabilization: false,
                voiceEnhancement: true,
                backgroundMusic: true,
                transitions: "fade"
            }
        },
        {
            id: 2,
            name: "Product Demo",
            description: "Demonstration of our new product features",
            createdDate: "2025-05-05",
            editedDate: "2025-05-15",
            resolution: "4K",
            ratio: "16:9",
            template: "Corporate",
            thumbnail: null,
            files: [
                { name: "intro.mp4", type: "Video", size: "25.3 MB", duration: "0:45" },
                { name: "features.mp4", type: "Video", size: "78.1 MB", duration: "3:20" },
                { name: "outro.mp4", type: "Video", size: "18.5 MB", duration: "0:30" },
                { name: "corporate_theme.mp3", type: "Audio", size: "4.2 MB", duration: "2:50" }
            ],
            settings: {
                colorCorrection: true,
                autoTrim: false,
                stabilization: true,
                voiceEnhancement: true,
                backgroundMusic: true,
                transitions: "slide"
            }
        },
        {
            id: 3,
            name: "Tutorial Series",
            description: "Step-by-step tutorial on programming basics",
            createdDate: "2025-05-01",
            editedDate: "2025-05-10",
            resolution: "720p",
            ratio: "16:9",
            template: "Tutorial",
            thumbnail: null,
            files: [
                { name: "intro_tutorial.mp4", type: "Video", size: "15.8 MB", duration: "0:30" },
                { name: "lesson1.mp4", type: "Video", size: "105.2 MB", duration: "8:45" },
                { name: "lesson2.mp4", type: "Video", size: "98.7 MB", duration: "7:20" },
                { name: "gentle_music.mp3", type: "Audio", size: "6.5 MB", duration: "5:10" }
            ],
            settings: {
                colorCorrection: true,
                autoTrim: true,
                stabilization: false,
                voiceEnhancement: true,
                backgroundMusic: false,
                transitions: "cut"
            }
        }
    ];
    
    // Initialize the page
    renderProjects(projects);
    
    // Event listeners
    projectSearchBtn.addEventListener('click', searchProjects);
    projectSearchInput.addEventListener('keyup', function(e) {
        if (e.key === 'Enter') {
            searchProjects();
        }
    });
    
    newProjectBtn.addEventListener('click', function() {
        // Reset form
        document.getElementById('newProjectForm').reset();
        newProjectModal.show();
    });
    
    createProjectBtn.addEventListener('click', createNewProject);
    
    sortOptions.forEach(option => {
        option.addEventListener('click', function(e) {
            e.preventDefault();
            const sortBy = this.getAttribute('data-sort');
            sortProjects(sortBy);
        });
    });
    
    // Add event listeners to project cards (using event delegation)
    projectsList.addEventListener('click', function(e) {
        // Handle edit button click
        if (e.target.closest('.btn-outline-primary')) {
            const projectCard = e.target.closest('.project-card');
            const projectId = projectCard.getAttribute('data-project-id');
            // In a real implementation, you would open the project in the editor
            alert(`Opening project ${projectId} in editor`);
        }
        
        // Handle export button click
        if (e.target.closest('.btn-outline-info')) {
            const projectCard = e.target.closest('.project-card');
            const projectId = projectCard.getAttribute('data-project-id');
            // In a real implementation, you would show export options
            alert(`Exporting project ${projectId}`);
        }
        
        // Handle delete button click
        if (e.target.closest('.btn-outline-danger')) {
            const projectCard = e.target.closest('.project-card');
            const projectId = projectCard.getAttribute('data-project-id');
            if (confirm('Are you sure you want to delete this project?')) {
                deleteProject(projectId);
            }
        }
        
        // Handle project card click (show details)
        if (e.target.closest('.project-card') && 
            !e.target.closest('button')) {
            const projectCard = e.target.closest('.project-card');
            const projectId = projectCard.getAttribute('data-project-id');
            showProjectDetails(projectId);
        }
    });
    
    // Functions
    function renderProjects(projectsToRender) {
        projectsList.innerHTML = '';
        
        if (projectsToRender.length === 0) {
            projectsList.innerHTML = `
                <div class="col-12 text-center py-5">
                    <p class="text-muted">No projects found. Create a new project to get started.</p>
                </div>
            `;
            return;
        }
        
        projectsToRender.forEach(project => {
            const projectCard = document.createElement('div');
            projectCard.className = 'col-md-4 mb-4';
            projectCard.innerHTML = `
                <div class="card h-100 project-card" data-project-id="${project.id}">
                    <div class="card-img-top bg-dark d-flex align-items-center justify-content-center" style="height: 120px;">
                        <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" fill="currentColor" class="bi bi-film text-info" viewBox="0 0 16 16">
                            <path d="M0 1a1 1 0 0 1 1-1h14a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1H1a1 1 0 0 1-1-1V1zm4 0v6h8V1H4zm8 8H4v6h8V9zM1 1v2h2V1H1zm2 3H1v2h2V4zM1 7v2h2V7H1zm2 3H1v2h2v-2zm-2 3v2h2v-2H1zM15 1h-2v2h2V1zm-2 3v2h2V4h-2zm2 3h-2v2h2V7zm-2 3v2h2v-2h-2zm2 3h-2v2h2v-2z"/>
                        </svg>
                    </div>
                    <div class="card-body">
                        <h5 class="card-title">${project.name}</h5>
                        <p class="card-text text-muted small">Last edited: ${formatDate(project.editedDate)}</p>
                        <div class="d-flex align-items-center">
                            <span class="badge bg-info me-2">Video</span>
                            <span class="badge bg-secondary me-2">${project.resolution}</span>
                        </div>
                    </div>
                    <div class="card-footer bg-dark-subtle border-top-0">
                        <div class="btn-group btn-group-sm w-100">
                            <button type="button" class="btn btn-outline-primary">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pencil" viewBox="0 0 16 16">
                                    <path d="M12.146.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1 0 .708l-10 10a.5.5 0 0 1-.168.11l-5 2a.5.5 0 0 1-.65-.65l2-5a.5.5 0 0 1 .11-.168l10-10zM11.207 2.5 13.5 4.793 14.793 3.5 12.5 1.207 11.207 2.5zm1.586 3L10.5 3.207 4 9.707V10h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.293l6.5-6.5zm-9.761 5.175-.106.106-1.528 3.821 3.821-1.528.106-.106A.5.5 0 0 1 5 12.5V12h-.5a.5.5 0 0 1-.5-.5V11h-.5a.5.5 0 0 1-.468-.325z"/>
                                </svg>
                                Edit
                            </button>
                            <button type="button" class="btn btn-outline-info">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-box-arrow-up-right" viewBox="0 0 16 16">
                                    <path fill-rule="evenodd" d="M8.636 3.5a.5.5 0 0 0-.5-.5H1.5A1.5 1.5 0 0 0 0 4.5v10A1.5 1.5 0 0 0 1.5 16h10a1.5 1.5 0 0 0 1.5-1.5V7.864a.5.5 0 0 0-1 0V14.5a.5.5 0 0 1-.5.5h-10a.5.5 0 0 1-.5-.5v-10a.5.5 0 0 1 .5-.5h6.636a.5.5 0 0 0 .5-.5z"/>
                                    <path fill-rule="evenodd" d="M16 .5a.5.5 0 0 0-.5-.5h-5a.5.5 0 0 0 0 1h3.793L6.146 9.146a.5.5 0 1 0 .708.708L15 1.707V5.5a.5.5 0 0 0 1 0v-5z"/>
                                </svg>
                                Export
                            </button>
                            <button type="button" class="btn btn-outline-danger">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16">
                                    <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z"/>
                                    <path fill-rule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"/>
                                </svg>
                            </button>
                        </div>
                    </div>
                </div>
            `;
            
            projectsList.appendChild(projectCard);
        });
    }
    
    function searchProjects() {
        const searchTerm = projectSearchInput.value.trim().toLowerCase();
        
        if (searchTerm === '') {
            renderProjects(projects);
            return;
        }
        
        const filteredProjects = projects.filter(project => 
            project.name.toLowerCase().includes(searchTerm) || 
            (project.description && project.description.toLowerCase().includes(searchTerm))
        );
        
        renderProjects(filteredProjects);
    }
    
    function sortProjects(sortBy) {
        let sortedProjects = [...projects];
        
        switch (sortBy) {
            case 'name-asc':
                sortedProjects.sort((a, b) => a.name.localeCompare(b.name));
                break;
            case 'name-desc':
                sortedProjects.sort((a, b) => b.name.localeCompare(a.name));
                break;
            case 'date-asc':
                sortedProjects.sort((a, b) => new Date(a.editedDate) - new Date(b.editedDate));
                break;
            case 'date-desc':
                sortedProjects.sort((a, b) => new Date(b.editedDate) - new Date(a.editedDate));
                break;
        }
        
        renderProjects(sortedProjects);
    }
    
    function createNewProject() {
        const projectName = document.getElementById('projectName').value.trim();
        const projectDescription = document.getElementById('projectDescription').value.trim();
        const projectResolution = document.getElementById('projectResolution').value;
        const projectRatio = document.getElementById('projectRatio').value;
        const projectTemplate = document.getElementById('projectTemplate').value;
        
        if (!projectName) {
            alert('Please enter a project name');
            return;
        }
        
        // Create new project
        const newProject = {
            id: projects.length + 1,
            name: projectName,
            description: projectDescription,
            createdDate: new Date().toISOString().split('T')[0],
            editedDate: new Date().toISOString().split('T')[0],
            resolution: projectResolution,
            ratio: projectRatio,
            template: projectTemplate || 'None',
            thumbnail: null,
            files: [],
            settings: {
                colorCorrection: true,
                autoTrim: false,
                stabilization: false,
                voiceEnhancement: false,
                backgroundMusic: false,
                transitions: 'cut'
            }
        };
        
        // Add to projects array
        projects.push(newProject);
        
        // Close modal and update UI
        newProjectModal.hide();
        renderProjects(projects);
        
        // In a real implementation, you would send this data to the server
        console.log('New project created:', newProject);
    }
    
    function deleteProject(projectId) {
        // Find the project index
        const projectIndex = projects.findIndex(p => p.id == projectId);
        
        if (projectIndex === -1) {
            return;
        }
        
        // Remove from array
        projects.splice(projectIndex, 1);
        
        // Update UI
        renderProjects(projects);
        
        // In a real implementation, you would send a delete request to the server
        console.log('Project deleted:', projectId);
    }
    
    function showProjectDetails(projectId) {
        // Find the project
        const project = projects.find(p => p.id == projectId);
        
        if (!project) {
            return;
        }
        
        // Update modal content
        document.getElementById('detailsProjectName').textContent = project.name;
        document.getElementById('detailsProjectDescription').textContent = project.description || 'No description available';
        document.getElementById('detailsCreatedDate').textContent = formatDate(project.createdDate);
        document.getElementById('detailsEditedDate').textContent = formatDate(project.editedDate);
        document.getElementById('detailsResolution').textContent = project.resolution;
        document.getElementById('detailsRatio').textContent = project.ratio;
        document.getElementById('detailsTemplate').textContent = project.template;
        
        // Update files list
        const filesList = document.getElementById('detailsFilesList');
        filesList.innerHTML = '';
        
        if (project.files.length === 0) {
            filesList.innerHTML = '<tr><td colspan="5" class="text-center">No files in this project</td></tr>';
        } else {
            project.files.forEach(file => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${file.name}</td>
                    <td>${file.type}</td>
                    <td>${file.size}</td>
                    <td>${file.duration}</td>
                    <td>
                        <button class="btn btn-sm btn-outline-info">${file.type === 'Video' ? 'Preview' : 'Play'}</button>
                    </td>
                `;
                filesList.appendChild(row);
            });
        }
        
        // Show modal
        projectDetailsModal.show();
    }
    
    // Helper function to format dates
    function formatDate(dateString) {
        const options = { year: 'numeric', month: 'short', day: 'numeric' };
        return new Date(dateString).toLocaleDateString(undefined, options);
    }
});