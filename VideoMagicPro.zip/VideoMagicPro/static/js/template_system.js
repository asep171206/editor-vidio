document.addEventListener('DOMContentLoaded', function() {
    // Initialize video.js player
    const player = videojs('videoPreview', {
        controls: true,
        autoplay: false,
        preload: 'auto',
        fluid: true,
        responsive: true
    });
    
    // DOM elements
    const videoSelect = document.getElementById('videoSelect');
    const processTemplateBtn = document.getElementById('processTemplateBtn');
    const captionInput = document.getElementById('captionInput');
    const captionCount = document.getElementById('captionCount');
    const hashtagInput = document.getElementById('hashtagInput');
    const templateResultsSection = document.getElementById('templateResultsSection');
    const templateResults = document.getElementById('templateResults');
    
    // Template selection
    const templateRadios = document.querySelectorAll('.template-select');
    const introRadios = document.querySelectorAll('.intro-select');
    const outroRadios = document.querySelectorAll('.outro-select');
    const aspectRadios = document.querySelectorAll('.aspect-select');
    const platformChecks = document.querySelectorAll('.platform-check');
    
    // Brand Kit elements
    const logoUpload = document.getElementById('logoUpload');
    const primaryColor = document.getElementById('primaryColor');
    const secondaryColor = document.getElementById('secondaryColor');
    const fontSelect = document.getElementById('fontSelect');
    const saveBrandKit = document.getElementById('saveBrandKit');
    
    // State
    let brandKit = {
        logo: null,
        primaryColor: '#0dcaf0',
        secondaryColor: '#6c757d',
        font: 'sans-serif'
    };
    
    // Enable process button when video is selected
    videoSelect.addEventListener('change', function() {
        const selectedVideo = videoSelect.value;
        updateProcessButton();
        
        if (selectedVideo) {
            // Load video preview
            player.src({
                src: selectedVideo,
                type: 'video/mp4'
            });
            player.load();
            
            // Hide results from previous processing
            templateResultsSection.classList.add('d-none');
        }
    });
    
    // Handle template selection
    templateRadios.forEach(radio => {
        radio.addEventListener('change', updateProcessButton);
    });
    
    // Handle aspect ratio selection
    aspectRadios.forEach(radio => {
        radio.addEventListener('change', function() {
            updatePlatformRecommendations();
            updateProcessButton();
        });
    });
    
    // Handle platform selection
    platformChecks.forEach(checkbox => {
        checkbox.addEventListener('change', function() {
            updatePlatformRecommendations();
            
            // Suggest aspect ratio based on platforms
            suggestAspectRatio();
        });
    });
    
    // Handle caption input
    captionInput.addEventListener('input', function() {
        const length = this.value.length;
        captionCount.textContent = `${length}/2200`;
        
        // Change color if approaching limit
        if (length > 2000) {
            captionCount.classList.add('text-danger');
        } else {
            captionCount.classList.remove('text-danger');
        }
    });
    
    // Handle logo upload
    logoUpload.addEventListener('change', function(e) {
        if (e.target.files && e.target.files[0]) {
            const reader = new FileReader();
            
            reader.onload = function(e) {
                brandKit.logo = e.target.result;
            };
            
            reader.readAsDataURL(e.target.files[0]);
        }
    });
    
    // Handle color pickers
    primaryColor.addEventListener('change', function() {
        brandKit.primaryColor = this.value;
    });
    
    secondaryColor.addEventListener('change', function() {
        brandKit.secondaryColor = this.value;
    });
    
    // Handle font selection
    fontSelect.addEventListener('change', function() {
        brandKit.font = this.value;
    });
    
    // Save brand kit
    saveBrandKit.addEventListener('click', function() {
        // Normally this would be saved to a server/database
        // For now, just show a confirmation
        alert('Brand kit saved successfully!');
    });
    
    // Process template button
    processTemplateBtn.addEventListener('click', function() {
        const selectedVideo = videoSelect.value;
        if (!selectedVideo) return;
        
        // Get selected template options
        const templateData = getSelectedTemplateData();
        
        // Show loading state
        processTemplateBtn.disabled = true;
        processTemplateBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Processing...';
        
        // In a real implementation, this would send the data to the server
        // For now, simulate processing with a timeout
        setTimeout(function() {
            displayTemplateResults(templateData);
            
            // Reset button
            processTemplateBtn.disabled = false;
            processTemplateBtn.textContent = 'Apply Template & Process Video';
        }, 2000);
    });
    
    // Helper function to update the process button state
    function updateProcessButton() {
        const videoSelected = videoSelect.value !== '';
        const templateSelected = Array.from(templateRadios).some(radio => radio.checked);
        const aspectSelected = Array.from(aspectRadios).some(radio => radio.checked);
        
        processTemplateBtn.disabled = !(videoSelected && (templateSelected || aspectSelected));
    }
    
    // Helper function to update platform recommendations
    function updatePlatformRecommendations() {
        const recommendationsElement = document.getElementById('platformRecommendations');
        const selectedPlatforms = Array.from(platformChecks)
            .filter(checkbox => checkbox.checked)
            .map(checkbox => checkbox.value);
        
        // Get selected aspect ratio
        const selectedAspect = Array.from(aspectRadios)
            .find(radio => radio.checked)?.value || '16:9';
        
        let recommendations = '<h6>Platform Recommendations</h6><ul class="mb-0">';
        
        if (selectedPlatforms.includes('youtube')) {
            let recommendation = '<strong>YouTube:</strong> Optimal length 8-15 minutes';
            if (selectedAspect !== '16:9') {
                recommendation += ', <span class="text-warning">16:9 format recommended</span>';
            } else {
                recommendation += ', 16:9 format';
            }
            recommendations += `<li>${recommendation}</li>`;
        }
        
        if (selectedPlatforms.includes('instagram')) {
            let recommendation = '<strong>Instagram:</strong> Keep under 60 seconds for Reels';
            if (selectedAspect !== '9:16' && selectedAspect !== '1:1') {
                recommendation += ', <span class="text-warning">9:16 or 1:1 format recommended</span>';
            } else {
                recommendation += `, ${selectedAspect} format`;
            }
            recommendations += `<li>${recommendation}</li>`;
        }
        
        if (selectedPlatforms.includes('tiktok')) {
            let recommendation = '<strong>TikTok:</strong> 15-60 seconds';
            if (selectedAspect !== '9:16') {
                recommendation += ', <span class="text-warning">vertical 9:16 format recommended</span>';
            } else {
                recommendation += ', vertical 9:16 format';
            }
            recommendations += `<li>${recommendation}</li>`;
        }
        
        if (selectedPlatforms.includes('twitter')) {
            let recommendation = '<strong>Twitter:</strong> Keep under 2 minutes for better engagement';
            if (selectedAspect === '21:9') {
                recommendation += ', <span class="text-warning">16:9 format recommended</span>';
            }
            recommendations += `<li>${recommendation}</li>`;
        }
        
        recommendations += '</ul>';
        recommendationsElement.innerHTML = recommendations;
    }
    
    // Helper function to suggest aspect ratio based on selected platforms
    function suggestAspectRatio() {
        const selectedPlatforms = Array.from(platformChecks)
            .filter(checkbox => checkbox.checked)
            .map(checkbox => checkbox.value);
        
        // Don't make suggestions if the user has already selected an aspect ratio
        if (Array.from(aspectRadios).some(radio => radio.checked)) {
            return;
        }
        
        // Find the most appropriate aspect ratio based on selected platforms
        if (selectedPlatforms.includes('tiktok') || 
            (selectedPlatforms.includes('instagram') && !selectedPlatforms.includes('youtube'))) {
            // Select 9:16 for TikTok or Instagram-focused content
            document.getElementById('portrait916').checked = true;
        } else if (selectedPlatforms.includes('instagram') && selectedPlatforms.includes('youtube')) {
            // For both Instagram and YouTube, suggest square format as a compromise
            document.getElementById('square11').checked = true;
        } else if (selectedPlatforms.length === 0 || selectedPlatforms.includes('youtube')) {
            // Default to 16:9 for YouTube or no specific platform
            document.getElementById('landscape169').checked = true;
        }
        
        // Update recommendations after selecting
        updatePlatformRecommendations();
    }
    
    // Helper function to get all selected template data
    function getSelectedTemplateData() {
        // Get selected template
        const contentTemplate = Array.from(templateRadios)
            .find(radio => radio.checked)?.value || null;
            
        // Get selected intro/outro
        const introTemplate = Array.from(introRadios)
            .find(radio => radio.checked)?.value || null;
            
        const outroTemplate = Array.from(outroRadios)
            .find(radio => radio.checked)?.value || null;
            
        // Get selected aspect ratio
        const aspectRatio = Array.from(aspectRadios)
            .find(radio => radio.checked)?.value || '16:9';
            
        // Get selected platforms
        const platforms = Array.from(platformChecks)
            .filter(checkbox => checkbox.checked)
            .map(checkbox => checkbox.value);
            
        // Get caption and hashtags
        const caption = captionInput.value.trim();
        const hashtags = hashtagInput.value.trim();
        
        // Get watermark setting
        const useWatermark = document.getElementById('watermarkSwitch').checked;
        
        return {
            video: videoSelect.value,
            contentTemplate,
            introTemplate,
            outroTemplate,
            aspectRatio,
            platforms,
            caption,
            hashtags,
            useWatermark,
            brandKit
        };
    }
    
    // Helper function to display template processing results
    function displayTemplateResults(data) {
        templateResultsSection.classList.remove('d-none');
        
        // Construct result message
        let resultHtml = '<div class="alert alert-success mb-3">';
        resultHtml += '<h6 class="alert-heading">Processing Complete!</h6>';
        resultHtml += `<p>Your video has been processed with the following templates:</p>`;
        resultHtml += '<ul>';
        
        if (data.contentTemplate) {
            resultHtml += `<li><strong>Content Template:</strong> ${data.contentTemplate}</li>`;
        }
        
        if (data.introTemplate) {
            resultHtml += `<li><strong>Intro:</strong> ${data.introTemplate}</li>`;
        }
        
        if (data.outroTemplate) {
            resultHtml += `<li><strong>Outro:</strong> ${data.outroTemplate}</li>`;
        }
        
        resultHtml += `<li><strong>Aspect Ratio:</strong> ${data.aspectRatio}</li>`;
        
        if (data.platforms.length > 0) {
            resultHtml += `<li><strong>Optimized for:</strong> ${data.platforms.join(', ')}</li>`;
        }
        
        if (data.useWatermark) {
            resultHtml += `<li><strong>Watermark:</strong> Applied</li>`;
        }
        
        resultHtml += '</ul>';
        
        // Add platform-specific info
        if (data.platforms.length > 0) {
            resultHtml += '<hr>';
            resultHtml += '<h6>Platform-Specific Assets</h6>';
            resultHtml += '<div class="row g-2">';
            
            data.platforms.forEach(platform => {
                resultHtml += `
                <div class="col-md-6">
                    <div class="card mb-2">
                        <div class="card-body p-2">
                            <h6 class="card-title">${platform.charAt(0).toUpperCase() + platform.slice(1)}</h6>
                            <p class="card-text small mb-1">Video optimized for ${platform}</p>
                            <div class="d-flex gap-1">
                                <button class="btn btn-sm btn-outline-primary">Preview</button>
                                <button class="btn btn-sm btn-outline-success">Download</button>
                            </div>
                        </div>
                    </div>
                </div>`;
            });
            
            resultHtml += '</div>';
        }
        
        resultHtml += '</div>';
        
        // Display caption and hashtags preview if provided
        if (data.caption || data.hashtags) {
            resultHtml += '<div class="card mb-3"><div class="card-body">';
            resultHtml += '<h6 class="card-title">Caption Preview</h6>';
            
            if (data.caption) {
                resultHtml += `<p>${data.caption}</p>`;
            }
            
            if (data.hashtags) {
                const formattedHashtags = data.hashtags.split(' ')
                    .map(tag => tag.startsWith('#') ? tag : `#${tag}`)
                    .join(' ');
                resultHtml += `<p class="text-primary">${formattedHashtags}</p>`;
            }
            
            resultHtml += '<button class="btn btn-sm btn-outline-primary">Copy Caption</button>';
            resultHtml += '</div></div>';
        }
        
        templateResults.innerHTML = resultHtml;
        
        // Scroll to results
        templateResultsSection.scrollIntoView({behavior: 'smooth'});
    }
    
    // Initialize platform recommendations
    updatePlatformRecommendations();
});