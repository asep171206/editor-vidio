document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const videoSelect = document.getElementById('videoSelect');
    const videoPreview = document.getElementById('videoPreview');
    const voiceSelect = document.getElementById('voiceSelect');
    const voiceSpeed = document.getElementById('voiceSpeed');
    const voiceSpeedValue = document.getElementById('voiceSpeedValue');
    const voicePitch = document.getElementById('voicePitch');
    const voicePitchValue = document.getElementById('voicePitchValue');
    const previewVoiceBtn = document.getElementById('previewVoiceBtn');
    const voiceoverScript = document.getElementById('voiceoverScript');
    const scriptSegments = document.getElementById('scriptSegments');
    const splitScriptBtn = document.getElementById('splitScriptBtn');
    const clearScriptBtn = document.getElementById('clearScriptBtn');
    const generateVoiceoverBtn = document.getElementById('generateVoiceoverBtn');
    const voiceoverResultsCard = document.getElementById('voiceoverResultsCard');
    const voiceoverAudio = document.getElementById('voiceoverAudio');
    const previewWithVideoBtn = document.getElementById('previewWithVideoBtn');
    const downloadVoiceoverBtn = document.getElementById('downloadVoiceoverBtn');
    const applyToVideoBtn = document.getElementById('applyToVideoBtn');
    const generateScriptBtn = document.getElementById('generateScriptBtn');
    const translateScriptBtn = document.getElementById('translateScriptBtn');
    
    // Modals
    const generateScriptModal = new bootstrap.Modal(document.getElementById('generateScriptModal'));
    const translateScriptModal = new bootstrap.Modal(document.getElementById('translateScriptModal'));
    
    // Sample script for demonstration
    const sampleScript = "Welcome to our product demonstration video. Today, we'll be showing you the amazing features of our latest software release. This innovative solution is designed to make your workflow more efficient and productive. Let's dive in and explore what makes this product special.";
    
    // State variables
    let currentVideo = null;
    let currentVoiceover = null;
    let scriptSegmentsList = [];
    
    // Event Listeners
    videoSelect.addEventListener('change', function() {
        const selectedVideo = this.value;
        if (selectedVideo) {
            currentVideo = selectedVideo;
            videoPreview.src = selectedVideo;
            videoPreview.load();
        }
    });
    
    // Voice Speed Slider
    voiceSpeed.addEventListener('input', function() {
        const value = parseFloat(this.value);
        if (value === 1) {
            voiceSpeedValue.textContent = 'Normal (1.0)';
        } else if (value < 1) {
            voiceSpeedValue.textContent = `Slower (${value.toFixed(1)})`;
        } else {
            voiceSpeedValue.textContent = `Faster (${value.toFixed(1)})`;
        }
    });
    
    // Voice Pitch Slider
    voicePitch.addEventListener('input', function() {
        const value = parseInt(this.value);
        if (value === 0) {
            voicePitchValue.textContent = 'Default (0)';
        } else if (value < 0) {
            voicePitchValue.textContent = `Lower (${value})`;
        } else {
            voicePitchValue.textContent = `Higher (+${value})`;
        }
    });
    
    // Preview Voice Button
    previewVoiceBtn.addEventListener('click', function() {
        const voice = voiceSelect.value;
        const speed = voiceSpeed.value;
        const pitch = voicePitch.value;
        
        // Create a short sample text
        const sampleText = "This is how your voiceover will sound. You can adjust the settings to get the perfect voice for your video.";
        
        // Show loading state
        previewVoiceBtn.disabled = true;
        previewVoiceBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Generating...';
        
        // Simulate API call delay (would be an actual API call in production)
        setTimeout(function() {
            // Reset button
            previewVoiceBtn.disabled = false;
            previewVoiceBtn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-play-circle me-1" viewBox="0 0 16 16"><path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/><path d="M6.271 5.055a.5.5 0 0 1 .52.038l3.5 2.5a.5.5 0 0 1 0 .814l-3.5 2.5A.5.5 0 0 1 6 10.5v-5a.5.5 0 0 1 .271-.445z"/></svg> Preview Voice';
            
            // Create a SpeechSynthesisUtterance object
            const speechSynthesis = window.speechSynthesis;
            const utterance = new SpeechSynthesisUtterance(sampleText);
            
            // Find the voice that matches our selection
            const voices = speechSynthesis.getVoices();
            // In a real implementation, we would match based on the voice ID
            // For demo, we'll just use the first available voice
            
            utterance.rate = parseFloat(speed);
            utterance.pitch = 1 + (parseInt(pitch) / 10); // Convert -10 to +10 range to 0 to 2 range
            
            // Speak the text
            speechSynthesis.speak(utterance);
            
            // In a real implementation with API:
            // - We would make an API call to a TTS service
            // - Play the returned audio file
            // - Provide options to save the preview
        }, 1500);
    });
    
    // Generate Script Button
    generateScriptBtn.addEventListener('click', function() {
        if (!currentVideo) {
            alert('Please select a video first');
            return;
        }
        
        // Show the generate script modal
        generateScriptModal.show();
    });
    
    // Confirm Generate Script Button
    document.getElementById('confirmGenerateScript').addEventListener('click', function() {
        const tone = document.getElementById('scriptTone').value;
        const length = document.getElementById('scriptLength').value;
        const keywords = document.getElementById('scriptKeywords').value;
        
        // Show loading state
        this.disabled = true;
        this.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Generating...';
        
        // Simulate API call delay (would be an actual API call in production)
        setTimeout(() => {
            // Reset button
            this.disabled = false;
            this.innerHTML = 'Generate';
            
            // Close modal
            generateScriptModal.hide();
            
            // Set the sample script in the textarea
            voiceoverScript.value = sampleScript;
            
            // Show success message
            alert('Script generated successfully!');
            
            // In a real implementation:
            // - We would send the video for analysis (OpenAI Vision API or similar)
            // - Generate a script based on the content and parameters
            // - Set the generated script in the textarea
        }, 2500);
    });
    
    // Translate Script Button
    translateScriptBtn.addEventListener('click', function() {
        if (!voiceoverScript.value.trim()) {
            alert('Please enter or generate a script first');
            return;
        }
        
        // Show the translate script modal
        translateScriptModal.show();
    });
    
    // Confirm Translate Button
    document.getElementById('confirmTranslate').addEventListener('click', function() {
        const sourceLanguage = document.getElementById('sourceLanguage').value;
        const targetLanguage = document.getElementById('targetLanguage').value;
        
        // Check if source and target languages are the same
        if (sourceLanguage !== 'auto' && sourceLanguage === targetLanguage) {
            alert('Source and target languages cannot be the same');
            return;
        }
        
        // Get the script text
        const scriptText = voiceoverScript.value;
        
        // Show loading state
        this.disabled = true;
        this.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Translating...';
        
        // Simulate API call delay (would be an actual API call in production)
        setTimeout(() => {
            // Reset button
            this.disabled = false;
            this.innerHTML = 'Translate';
            
            // Close modal
            translateScriptModal.hide();
            
            // Update the script with a "translated" version
            // For demo, we'll just add a prefix
            voiceoverScript.value = `[Translated to ${getLanguageName(targetLanguage)}] ${scriptText}`;
            
            // Show success message
            alert('Script translated successfully!');
            
            // In a real implementation:
            // - We would send the script to a translation API
            // - Update the textarea with the translated text
        }, 2000);
    });
    
    // Split Script Button
    splitScriptBtn.addEventListener('click', function() {
        const script = voiceoverScript.value.trim();
        if (!script) {
            alert('Please enter or generate a script first');
            return;
        }
        
        // Split the script into sentences
        const sentences = script.match(/[^\.!\?]+[\.!\?]+/g) || [script];
        
        // Clear previous segments
        scriptSegments.innerHTML = '';
        scriptSegmentsList = [];
        
        // Create a segment for each sentence
        sentences.forEach((sentence, index) => {
            const segment = {
                id: index + 1,
                text: sentence.trim(),
                startTime: formatTime(index * 5), // Placeholder timing
                duration: estimateDuration(sentence)
            };
            
            scriptSegmentsList.push(segment);
            
            const segmentElement = document.createElement('div');
            segmentElement.className = 'segment-item mb-2 p-2 border rounded';
            segmentElement.innerHTML = `
                <div class="d-flex justify-content-between align-items-center mb-1">
                    <span class="badge bg-info">Segment ${segment.id}</span>
                    <div>
                        <span class="badge bg-secondary me-1">Start: ${segment.startTime}</span>
                        <span class="badge bg-secondary">Duration: ${segment.duration}s</span>
                    </div>
                </div>
                <p class="mb-0">${segment.text}</p>
            `;
            
            scriptSegments.appendChild(segmentElement);
        });
    });
    
    // Clear Script Button
    clearScriptBtn.addEventListener('click', function() {
        if (confirm('Are you sure you want to clear the script?')) {
            voiceoverScript.value = '';
            scriptSegments.innerHTML = `
                <div class="alert alert-info">
                    Add your script above, then click "Split Script" to break it into timed segments.
                </div>
            `;
            scriptSegmentsList = [];
        }
    });
    
    // Generate Voiceover Button
    generateVoiceoverBtn.addEventListener('click', function() {
        const script = voiceoverScript.value.trim();
        if (!script) {
            alert('Please enter or generate a script first');
            return;
        }
        
        if (scriptSegmentsList.length === 0) {
            alert('Please split your script into segments first');
            return;
        }
        
        const voice = voiceSelect.value;
        const speed = voiceSpeed.value;
        const pitch = voicePitch.value;
        const syncTiming = document.getElementById('syncTimingSwitch').checked;
        const backgroundMusic = document.getElementById('backgroundMusicSwitch').checked;
        
        // Show loading state
        generateVoiceoverBtn.disabled = true;
        generateVoiceoverBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Generating Voiceover...';
        
        // Simulate API call delay (would be an actual API call in production)
        setTimeout(() => {
            // Reset button
            generateVoiceoverBtn.disabled = false;
            generateVoiceoverBtn.innerHTML = 'Generate Voiceover';
            
            // Show results card
            voiceoverResultsCard.style.display = 'block';
            
            // Set a sample audio URL (in a real implementation, this would be the generated audio)
            // For demo purposes, we'll just use a placeholder
            voiceoverAudio.src = 'data:audio/mpeg;base64,SUQzBAAAAAABEVRYWFgAAAAtAAADY29tbWVudABCaWdTb3VuZEJhbmsuY29tIC8gTGFTb25vdGhlcXVlLm9yZwBURU5DAAAAHQAAA1N3aXRjaCBQbHVzIMKpIE5DSCBTb2Z0d2FyZQBUSVQyAAAABgAAADIyMzUAVFNTRQAAAA8AAANMYXZmNTcuODMuMTAwAAAAAAAAAAAAAAD/80DEAAAAA0gAAAAATEFNRTMuMTAwVVVVVVVVVVVVVUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVf/zQsRbAAADSAAAAABVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVf/zQMSkAAADSAAAAABVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV';
            
            // Scroll to results
            voiceoverResultsCard.scrollIntoView({behavior: 'smooth'});
            
            // In a real implementation:
            // - We would send the script to a TTS API along with voice parameters
            // - Set the returned audio file as the source for the audio element
            // - Enable download and application to video
        }, 3000);
    });
    
    // Preview with Video Button
    previewWithVideoBtn.addEventListener('click', function() {
        if (!currentVideo) {
            alert('Please select a video first');
            return;
        }
        
        // In a real implementation, this would create a temporary video with the voiceover
        alert('This would show a preview of the video with the generated voiceover');
    });
    
    // Download Voiceover Button
    downloadVoiceoverBtn.addEventListener('click', function() {
        // In a real implementation, this would download the voiceover audio file
        alert('This would download the generated voiceover audio file');
    });
    
    // Apply to Video Button
    applyToVideoBtn.addEventListener('click', function() {
        if (!currentVideo) {
            alert('Please select a video first');
            return;
        }
        
        // Show loading state
        applyToVideoBtn.disabled = true;
        applyToVideoBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Applying...';
        
        // Simulate processing delay
        setTimeout(() => {
            // Reset button
            applyToVideoBtn.disabled = false;
            applyToVideoBtn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check2-circle" viewBox="0 0 16 16"><path d="M2.5 8a5.5 5.5 0 0 1 8.25-4.764.5.5 0 0 0 .5-.866A6.5 6.5 0 1 0 14.5 8a.5.5 0 0 0-1 0 5.5 5.5 0 1 1-11 0z"/><path d="M15.354 3.354a.5.5 0 0 0-.708-.708L8 9.293 5.354 6.646a.5.5 0 1 0-.708.708l3 3a.5.5 0 0 0 .708 0l7-7z"/></svg> Apply to Video';
            
            // Show success message
            alert('Voiceover applied to video successfully! The video has been saved to your project.');
            
            // In a real implementation:
            // - We would combine the video and the voiceover audio
            // - Save the result as a new video file
            // - Provide a link to the new video
        }, 2500);
    });
    
    // Helper Functions
    function estimateDuration(text) {
        // Estimate the duration of speech based on the text length
        // Average speaking rate is about 150 words per minute, or 2.5 words per second
        const words = text.split(/\s+/).length;
        const estimatedSeconds = Math.round(words / 2.5);
        return Math.max(1, estimatedSeconds); // Minimum 1 second
    }
    
    function formatTime(seconds) {
        const minutes = Math.floor(seconds / 60);
        const remainingSeconds = Math.floor(seconds % 60);
        return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
    }
    
    function getLanguageName(code) {
        const languages = {
            'en': 'English',
            'es': 'Spanish',
            'fr': 'French',
            'de': 'German',
            'ja': 'Japanese',
            'zh': 'Chinese'
        };
        return languages[code] || code;
    }
});