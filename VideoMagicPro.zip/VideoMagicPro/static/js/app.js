// Initialize Dropzone
Dropzone.autoDiscover = false;

document.addEventListener('DOMContentLoaded', function() {
    // Initialize the video dropzone
    const myDropzone = new Dropzone("#videoDropzone", {
        url: "/upload",
        paramName: "files[]",
        maxFilesize: 500, // MB
        acceptedFiles: ".mp4,.avi,.mov,.mkv,.wmv",
        addRemoveLinks: true,
        autoProcessQueue: false,
        uploadMultiple: true,
        parallelUploads: 100,
        maxFiles: 10,
        dictDefaultMessage: `
            <div class="dz-message-content">
                <svg width="64" height="64" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="mb-3">
                    <path d="M7 16.5v-9m0 0l3 3m-3-3l-3 3M13 7.5h3a3 3 0 013 3v6a3 3 0 01-3 3h-3" stroke="var(--bs-info)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                <h5>Drop video files here or click to upload</h5>
                <p class="text-muted">Supported formats: MP4, AVI, MOV, MKV, WMV</p>
            </div>
        `,
        dictFallbackMessage: "Your browser does not support drag'n'drop file uploads.",
        dictInvalidFileType: "Invalid file type. Only video files are allowed.",
        dictFileTooBig: "File is too big ({{filesize}}MB). Max filesize: {{maxFilesize}}MB.",
        dictResponseError: "Server error: {{statusCode}}",
        dictMaxFilesExceeded: "You can't upload any more files (max: {{maxFiles}}).",
        dictRemoveFile: "Remove",
        dictCancelUpload: "Cancel",
        dictCancelUploadConfirmation: "Are you sure you want to cancel this upload?",
    });

    // Upload button handler
    document.getElementById('uploadBtn').addEventListener('click', function() {
        if (myDropzone.files.length > 0) {
            myDropzone.processQueue();
        } else {
            alert("Please add at least one video file to process.");
        }
    });

    // Handle upload events
    myDropzone.on("sendingmultiple", function(files, xhr, formData) {
        // Show loading indication if needed
        document.getElementById('uploadBtn').disabled = true;
        document.getElementById('uploadBtn').innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Uploading...';
    });

    myDropzone.on("successmultiple", function(files, response) {
        // Redirect to processing page (handled by server-side)
        window.location.href = "/processing-options";
    });

    myDropzone.on("errormultiple", function(files, errorMessage) {
        console.error("Upload error:", errorMessage);
        alert("Error uploading files: " + errorMessage);
        document.getElementById('uploadBtn').disabled = false;
        document.getElementById('uploadBtn').textContent = "Start Processing";
    });
});
