document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const imageUpload = document.getElementById('imageUpload');
    const uploadImagesBtn = document.getElementById('uploadImagesBtn');
    const selectFromLibraryBtn = document.getElementById('selectFromLibraryBtn');
    const imageList = document.getElementById('imageList');
    const imageListEmpty = document.getElementById('imageListEmpty');
    const slideshowSummary = document.getElementById('slideshowSummary');
    const imageCount = document.getElementById('imageCount');
    const totalDuration = document.getElementById('totalDuration');
    const clearAllImagesBtn = document.getElementById('clearAllImagesBtn');
    const sortImagesBtn = document.getElementById('sortImagesBtn');
    const previewSlideshowBtn = document.getElementById('previewSlideshowBtn');
    const createSlideshowBtn = document.getElementById('createSlideshowBtn');
    
    // Settings elements
    const slideDuration = document.getElementById('slideDuration');
    const slideDurationValue = document.getElementById('slideDurationValue');
    const transitionType = document.getElementById('transitionType');
    const transitionDuration = document.getElementById('transitionDuration');
    const transitionDurationValue = document.getElementById('transitionDurationValue');
    const outputResolution = document.getElementById('outputResolution');
    const outputFormat = document.getElementById('outputFormat');
    const kenBurnsEffect = document.getElementById('kenBurnsEffect');
    const autoEnhanceImages = document.getElementById('autoEnhanceImages');
    
    // Audio settings
    const addBackgroundMusic = document.getElementById('addBackgroundMusic');
    const musicSettings = document.getElementById('musicSettings');
    const musicTrack = document.getElementById('musicTrack');
    const selectMusicFromLibraryBtn = document.getElementById('selectMusicFromLibraryBtn');
    const musicVolume = document.getElementById('musicVolume');
    const musicVolumeValue = document.getElementById('musicVolumeValue');
    const loopMusic = document.getElementById('loopMusic');
    const fadeAudio = document.getElementById('fadeAudio');
    
    // Voiceover settings
    const addVoiceover = document.getElementById('addVoiceover');
    const voiceoverSettings = document.getElementById('voiceoverSettings');
    const voiceoverText = document.getElementById('voiceoverText');
    const voiceSelect = document.getElementById('voiceSelect');
    const previewVoiceBtn = document.getElementById('previewVoiceBtn');
    
    // Titles & Captions
    const slideshowTitle = document.getElementById('slideshowTitle');
    const addIntroSlide = document.getElementById('addIntroSlide');
    const addOutroSlide = document.getElementById('addOutroSlide');
    const outroCreditsField = document.getElementById('outroCreditsField');
    const outroCredits = document.getElementById('outroCredits');
    const addImageCaptions = document.getElementById('addImageCaptions');
    const captionStyleOptions = document.getElementById('captionStyleOptions');
    
    // Modals
    const selectMediaModal = new bootstrap.Modal(document.getElementById('selectMediaModal'));
    const selectMusicModal = new bootstrap.Modal(document.getElementById('selectMusicModal'));
    const previewSlideshowModal = new bootstrap.Modal(document.getElementById('previewSlideshowModal'));
    const processingModal = new bootstrap.Modal(document.getElementById('processingModal'));
    const resultsModal = new bootstrap.Modal(document.getElementById('resultsModal'));
    
    // Modal elements
    const confirmMediaSelectionBtn = document.getElementById('confirmMediaSelectionBtn');
    const confirmMusicSelectionBtn = document.getElementById('confirmMusicSelectionBtn');
    const slideshowPreview = document.getElementById('slideshowPreview');
    const prevSlideBtn = document.getElementById('prevSlideBtn');
    const playPauseBtn = document.getElementById('playPauseBtn');
    const nextSlideBtn = document.getElementById('nextSlideBtn');
    const processingStatusText = document.getElementById('processingStatusText');
    const processingStepText = document.getElementById('processingStepText');
    const processingProgressBar = document.getElementById('processingProgressBar');
    
    // Results modal elements
    const resultVideo = document.getElementById('resultVideo');
    const resultDuration = document.getElementById('resultDuration');
    const resultResolution = document.getElementById('resultResolution');
    const resultFormat = document.getElementById('resultFormat');
    const resultSize = document.getElementById('resultSize');
    const shareLink = document.getElementById('shareLink');
    const copyLinkBtn = document.getElementById('copyLinkBtn');
    const downloadSlideshowBtn = document.getElementById('downloadSlideshowBtn');
    const editVideoBtn = document.getElementById('editVideoBtn');
    
    // Audio player for music preview
    const audioPlayer = document.getElementById('audioPlayer');
    
    // State variables
    let images = [];
    let selectedMusic = null;
    let previewActive = false;
    let currentPreviewSlide = 0;
    let previewInterval = null;
    
    // Make image list sortable
    if (imageList) {
        new Sortable(imageList, {
            animation: 150,
            ghostClass: 'sortable-ghost',
            onEnd: function() {
                // Update the images array based on the new order
                const items = imageList.querySelectorAll('.list-group-item');
                const newImages = [];
                
                items.forEach(item => {
                    const index = item.getAttribute('data-index');
                    if (index !== null && index !== undefined) {
                        newImages.push(images[parseInt(index)]);
                    }
                });
                
                images = newImages;
                updateImageListUI();
            }
        });
    }
    
    // Event Listeners
    
    // Image Upload
    uploadImagesBtn.addEventListener('click', function() {
        if (imageUpload.files.length > 0) {
            handleImageUpload(imageUpload.files);
        } else {
            imageUpload.click();
        }
    });
    
    imageUpload.addEventListener('change', function() {
        if (this.files.length > 0) {
            handleImageUpload(this.files);
        }
    });
    
    // Select from Media Library
    selectFromLibraryBtn.addEventListener('click', function() {
        selectMediaModal.show();
    });
    
    // Confirm Media Selection
    confirmMediaSelectionBtn.addEventListener('click', function() {
        const selectedImages = document.querySelectorAll('#selectMediaModal input[type="checkbox"]:checked');
        
        if (selectedImages.length === 0) {
            alert('Please select at least one image');
            return;
        }
        
        // In a real implementation, this would fetch the selected images
        // For demo purposes, we'll add placeholder images
        const mockImages = [];
        selectedImages.forEach((checkbox, index) => {
            const label = checkbox.nextElementSibling.textContent.trim();
            mockImages.push({
                id: `library_${Date.now()}_${index}`,
                name: label,
                src: 'https://via.placeholder.com/400x300',
                caption: ''
            });
        });
        
        addImagesToList(mockImages);
        selectMediaModal.hide();
        
        // Reset checkboxes
        selectedImages.forEach(checkbox => {
            checkbox.checked = false;
        });
    });
    
    // Clear All Images
    clearAllImagesBtn.addEventListener('click', function() {
        if (images.length > 0 && confirm('Are you sure you want to clear all images?')) {
            images = [];
            updateImageListUI();
        }
    });
    
    // Sort Images
    sortImagesBtn.addEventListener('click', function() {
        if (images.length > 0) {
            images.sort((a, b) => a.name.localeCompare(b.name));
            updateImageListUI();
        }
    });
    
    // Preview Slideshow
    previewSlideshowBtn.addEventListener('click', function() {
        if (images.length === 0) {
            alert('Please add at least one image to create a preview');
            return;
        }
        
        previewSlideshowModal.show();
        
        // Reset preview state
        currentPreviewSlide = 0;
        previewActive = false;
        clearInterval(previewInterval);
        
        // Update play/pause button
        playPauseBtn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-play-fill" viewBox="0 0 16 16"><path d="m11.596 8.697-6.363 3.692c-.54.313-1.233-.066-1.233-.697V4.308c0-.63.692-1.01 1.233-.696l6.363 3.692a.802.802 0 0 1 0 1.393z"/></svg> Play';
        
        // Generate simple preview
        generateSlideshowPreview();
    });
    
    // Preview Controls
    prevSlideBtn.addEventListener('click', function() {
        if (images.length === 0) return;
        
        currentPreviewSlide = (currentPreviewSlide - 1 + images.length) % images.length;
        updatePreviewSlide();
    });
    
    nextSlideBtn.addEventListener('click', function() {
        if (images.length === 0) return;
        
        currentPreviewSlide = (currentPreviewSlide + 1) % images.length;
        updatePreviewSlide();
    });
    
    playPauseBtn.addEventListener('click', function() {
        if (images.length === 0) return;
        
        previewActive = !previewActive;
        
        if (previewActive) {
            // Start slideshow
            playPauseBtn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pause-fill" viewBox="0 0 16 16"><path d="M5.5 3.5A1.5 1.5 0 0 1 7 5v6a1.5 1.5 0 0 1-3 0V5a1.5 1.5 0 0 1 1.5-1.5zm5 0A1.5 1.5 0 0 1 12 5v6a1.5 1.5 0 0 1-3 0V5a1.5 1.5 0 0 1 1.5-1.5z"/></svg> Pause';
            
            // Advance slides periodically
            previewInterval = setInterval(() => {
                currentPreviewSlide = (currentPreviewSlide + 1) % images.length;
                updatePreviewSlide();
            }, parseFloat(slideDuration.value) * 1000);
        } else {
            // Stop slideshow
            playPauseBtn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-play-fill" viewBox="0 0 16 16"><path d="m11.596 8.697-6.363 3.692c-.54.313-1.233-.066-1.233-.697V4.308c0-.63.692-1.01 1.233-.696l6.363 3.692a.802.802 0 0 1 0 1.393z"/></svg> Play';
            clearInterval(previewInterval);
        }
    });
    
    // Background Music Toggle
    addBackgroundMusic.addEventListener('change', function() {
        musicSettings.style.display = this.checked ? 'block' : 'none';
    });
    
    // Select Music from Library
    selectMusicFromLibraryBtn.addEventListener('click', function() {
        selectMusicModal.show();
    });
    
    // Confirm Music Selection
    confirmMusicSelectionBtn.addEventListener('click', function() {
        const selectedMusicItems = document.querySelectorAll('.music-item.active');
        
        if (selectedMusicItems.length === 0) {
            alert('Please select a music track');
            return;
        }
        
        const musicId = selectedMusicItems[0].getAttribute('data-music-id');
        const musicName = selectedMusicItems[0].querySelector('h6').textContent;
        
        // Update the music track select
        const option = Array.from(musicTrack.options).find(opt => opt.value === musicId);
        if (option) {
            option.selected = true;
        }
        
        selectMusicModal.hide();
    });
    
    // Music Track Items
    document.querySelectorAll('.music-item').forEach(item => {
        item.addEventListener('click', function(e) {
            if (e.target.classList.contains('preview-music-btn') || e.target.closest('.preview-music-btn')) {
                // Don't select when clicking the preview button
                e.preventDefault();
                return;
            }
            
            // Toggle active state
            document.querySelectorAll('.music-item').forEach(i => i.classList.remove('active'));
            this.classList.add('active');
        });
    });
    
    // Preview Music Buttons
    document.querySelectorAll('.preview-music-btn').forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            
            const musicId = this.closest('.music-item').getAttribute('data-music-id');
            
            // In a real implementation, this would play the actual music
            // For demo purposes, we'll just show an alert
            alert(`Playing music preview: ${musicId}`);
            
            // Toggle button state
            const isPlaying = this.classList.contains('playing');
            
            // Reset all buttons
            document.querySelectorAll('.preview-music-btn').forEach(btn => {
                btn.classList.remove('playing');
                btn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-play-fill" viewBox="0 0 16 16"><path d="m11.596 8.697-6.363 3.692c-.54.313-1.233-.066-1.233-.697V4.308c0-.63.692-1.01 1.233-.696l6.363 3.692a.802.802 0 0 1 0 1.393z"/></svg>';
            });
            
            if (!isPlaying) {
                this.classList.add('playing');
                this.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pause-fill" viewBox="0 0 16 16"><path d="M5.5 3.5A1.5 1.5 0 0 1 7 5v6a1.5 1.5 0 0 1-3 0V5a1.5 1.5 0 0 1 1.5-1.5zm5 0A1.5 1.5 0 0 1 12 5v6a1.5 1.5 0 0 1-3 0V5a1.5 1.5 0 0 1 1.5-1.5z"/></svg>';
            }
        });
    });
    
    // Voiceover Toggle
    addVoiceover.addEventListener('change', function() {
        voiceoverSettings.style.display = this.checked ? 'block' : 'none';
    });
    
    // Preview Voice Button
    previewVoiceBtn.addEventListener('click', function() {
        const text = voiceoverText.value.trim();
        const voice = voiceSelect.value;
        
        if (!text) {
            alert('Please enter some text for the voiceover');
            return;
        }
        
        // In a real implementation, this would call a TTS API
        // For demo purposes, we'll just show an alert
        alert(`Previewing voiceover: "${text}" with voice "${voice}"`);
    });
    
    // Image Captions Toggle
    addImageCaptions.addEventListener('change', function() {
        captionStyleOptions.style.display = this.checked ? 'block' : 'none';
        
        // Update the image list UI to show/hide caption inputs
        updateImageListUI();
    });
    
    // Outro Slide Toggle
    addOutroSlide.addEventListener('change', function() {
        outroCreditsField.style.display = this.checked ? 'block' : 'none';
    });
    
    // Slide Duration Range
    slideDuration.addEventListener('input', function() {
        slideDurationValue.textContent = `${this.value}s`;
        updateTotalDuration();
    });
    
    // Transition Duration Range
    transitionDuration.addEventListener('input', function() {
        transitionDurationValue.textContent = `${this.value}s`;
    });
    
    // Music Volume Range
    musicVolume.addEventListener('input', function() {
        musicVolumeValue.textContent = `${this.value}%`;
    });
    
    // Create Slideshow Button
    createSlideshowBtn.addEventListener('click', function() {
        if (images.length === 0) {
            alert('Please add at least one image to create a slideshow');
            return;
        }
        
        // Show processing modal
        processingModal.show();
        
        // Reset progress
        processingProgressBar.style.width = '0%';
        processingStepText.textContent = 'Initializing...';
        
        // Simulate processing
        simulateProcessing();
    });
    
    // Copy Link Button
    copyLinkBtn.addEventListener('click', function() {
        shareLink.select();
        document.execCommand('copy');
        
        // Show feedback
        const originalText = this.innerHTML;
        this.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check" viewBox="0 0 16 16"><path d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425a.267.267 0 0 1 .02-.022z"/></svg> Copied!';
        
        setTimeout(() => {
            this.innerHTML = originalText;
        }, 2000);
    });
    
    // Share Buttons
    document.getElementById('shareEmailBtn').addEventListener('click', function() {
        const subject = encodeURIComponent('Check out my slideshow!');
        const body = encodeURIComponent('I created a slideshow with AutoVideoEdit. Check it out: ' + shareLink.value);
        window.open(`mailto:?subject=${subject}&body=${body}`);
    });
    
    document.getElementById('shareFacebookBtn').addEventListener('click', function() {
        alert('This would share the slideshow on Facebook');
    });
    
    document.getElementById('shareTwitterBtn').addEventListener('click', function() {
        alert('This would share the slideshow on Twitter');
    });
    
    document.getElementById('shareInstagramBtn').addEventListener('click', function() {
        alert('This would share the slideshow on Instagram');
    });
    
    // Download Slideshow Button
    downloadSlideshowBtn.addEventListener('click', function() {
        alert('This would download the slideshow');
    });
    
    // Edit Video Button
    editVideoBtn.addEventListener('click', function() {
        alert('This would open the slideshow in the video editor');
        resultsModal.hide();
    });
    
    // Functions
    
    // Handle Image Upload
    function handleImageUpload(files) {
        if (files.length === 0) return;
        
        const newImages = [];
        
        for (let i = 0; i < files.length; i++) {
            const file = files[i];
            
            // Check if it's an image
            if (!file.type.startsWith('image/')) {
                continue;
            }
            
            // Create a new image object
            const image = {
                id: `upload_${Date.now()}_${i}`,
                name: file.name,
                file: file,
                src: URL.createObjectURL(file),
                caption: ''
            };
            
            newImages.push(image);
        }
        
        if (newImages.length > 0) {
            addImagesToList(newImages);
        }
        
        // Reset the file input
        imageUpload.value = '';
    }
    
    // Add Images to List
    function addImagesToList(newImages) {
        images = [...images, ...newImages];
        updateImageListUI();
    }
    
    // Update Image List UI
    function updateImageListUI() {
        if (images.length === 0) {
            imageList.style.display = 'none';
            imageListEmpty.style.display = 'block';
            slideshowSummary.style.display = 'none';
            return;
        }
        
        // Show the image list and summary
        imageList.style.display = 'block';
        imageListEmpty.style.display = 'none';
        slideshowSummary.style.display = 'block';
        
        // Update image count and duration
        imageCount.textContent = images.length;
        updateTotalDuration();
        
        // Clear the existing list
        imageList.innerHTML = '';
        
        // Add each image to the list
        images.forEach((image, index) => {
            const item = document.createElement('li');
            item.className = 'list-group-item bg-dark-subtle';
            item.setAttribute('data-index', index);
            
            const showCaptions = addImageCaptions.checked;
            
            item.innerHTML = `
                <div class="d-flex align-items-center">
                    <div class="me-3 d-flex flex-column align-items-center" style="width: 30px;">
                        <span class="badge bg-secondary mb-2">${index + 1}</span>
                        <div class="drag-handle">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-grip-vertical" viewBox="0 0 16 16">
                                <path d="M7 2a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zM7 5a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zM7 8a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm-3 3a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm-3 3a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"/>
                            </svg>
                        </div>
                    </div>
                    <div class="image-thumbnail me-3">
                        <img src="${image.src}" alt="${image.name}" style="width: 60px; height: 60px; object-fit: cover;" class="rounded">
                    </div>
                    <div class="flex-grow-1">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <h6 class="mb-0">${image.name}</h6>
                            <div>
                                <button type="button" class="btn btn-sm btn-outline-danger remove-image-btn" data-index="${index}">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16">
                                        <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z"/>
                                        <path fill-rule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"/>
                                    </svg>
                                </button>
                            </div>
                        </div>
                        ${showCaptions ? `
                        <div class="mb-0">
                            <input type="text" class="form-control form-control-sm image-caption" placeholder="Add caption..." value="${image.caption}" data-index="${index}">
                        </div>
                        ` : ''}
                    </div>
                </div>
            `;
            
            imageList.appendChild(item);
        });
        
        // Add event listeners to remove buttons
        document.querySelectorAll('.remove-image-btn').forEach(button => {
            button.addEventListener('click', function() {
                const index = parseInt(this.getAttribute('data-index'));
                removeImage(index);
            });
        });
        
        // Add event listeners to caption inputs
        document.querySelectorAll('.image-caption').forEach(input => {
            input.addEventListener('input', function() {
                const index = parseInt(this.getAttribute('data-index'));
                if (index >= 0 && index < images.length) {
                    images[index].caption = this.value;
                }
            });
        });
    }
    
    // Remove Image
    function removeImage(index) {
        if (index >= 0 && index < images.length) {
            // Release object URL if it exists
            if (images[index].src.startsWith('blob:')) {
                URL.revokeObjectURL(images[index].src);
            }
            
            // Remove the image from the array
            images.splice(index, 1);
            
            // Update the UI
            updateImageListUI();
        }
    }
    
    // Update Total Duration
    function updateTotalDuration() {
        const duration = images.length * parseFloat(slideDuration.value);
        const minutes = Math.floor(duration / 60);
        const seconds = Math.floor(duration % 60);
        totalDuration.textContent = `${minutes}:${seconds.toString().padStart(2, '0')}`;
    }
    
    // Generate Slideshow Preview
    function generateSlideshowPreview() {
        if (images.length === 0) return;
        
        // Reset preview container
        slideshowPreview.innerHTML = '';
        
        // Create image element
        const img = document.createElement('img');
        img.className = 'w-100 h-100 object-fit-contain';
        img.alt = 'Slideshow Preview';
        slideshowPreview.appendChild(img);
        
        // Show the first image
        updatePreviewSlide();
    }
    
    // Update Preview Slide
    function updatePreviewSlide() {
        if (images.length === 0) return;
        
        const img = slideshowPreview.querySelector('img');
        if (img) {
            img.src = images[currentPreviewSlide].src;
            
            // Add caption if enabled
            if (addImageCaptions.checked && images[currentPreviewSlide].caption) {
                let caption = slideshowPreview.querySelector('.caption');
                
                if (!caption) {
                    caption = document.createElement('div');
                    caption.className = 'caption position-absolute bottom-0 start-0 w-100 p-2 text-center bg-dark bg-opacity-75 text-white';
                    slideshowPreview.appendChild(caption);
                }
                
                caption.textContent = images[currentPreviewSlide].caption;
            } else {
                const caption = slideshowPreview.querySelector('.caption');
                if (caption) {
                    caption.remove();
                }
            }
        }
    }
    
    // Simulate Processing
    function simulateProcessing() {
        let progress = 0;
        const interval = setInterval(() => {
            progress += 5;
            processingProgressBar.style.width = `${progress}%`;
            
            // Update status text at different stages
            if (progress === 10) {
                processingStepText.textContent = 'Preparing images...';
            } else if (progress === 30) {
                processingStepText.textContent = 'Applying transitions...';
            } else if (progress === 50) {
                processingStepText.textContent = 'Adding audio...';
            } else if (progress === 70) {
                processingStepText.textContent = 'Applying effects...';
            } else if (progress === 90) {
                processingStepText.textContent = 'Finalizing slideshow...';
            }
            
            if (progress >= 100) {
                clearInterval(interval);
                
                // Hide processing modal and show results modal after a short delay
                setTimeout(() => {
                    processingModal.hide();
                    
                    // Prepare results data
                    resultDuration.textContent = totalDuration.textContent;
                    resultResolution.textContent = getResolutionText(outputResolution.value);
                    resultFormat.textContent = outputFormat.value.toUpperCase();
                    resultSize.textContent = '15.2 MB'; // Placeholder
                    
                    // Set a placeholder video URL
                    resultVideo.src = 'https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4';
                    
                    // Show the results modal
                    resultsModal.show();
                }, 500);
            }
        }, 200);
    }
    
    // Get Resolution Text
    function getResolutionText(value) {
        switch (value) {
            case '720p':
                return '1280x720';
            case '1080p':
                return '1920x1080';
            case '4k':
                return '3840x2160';
            default:
                return '1920x1080';
        }
    }
});