document.addEventListener('DOMContentLoaded', function() {
    // Initialize video.js player
    const player = videojs('videoPreview', {
        controls: true,
        autoplay: false,
        preload: 'auto',
        fluid: true,
        responsive: true
    });
    
    // DOM elements
    const videoSelect = document.getElementById('videoSelect');
    const processAdvancedBtn = document.getElementById('processAdvancedBtn');
    const advancedResultsSection = document.getElementById('advancedResultsSection');
    const timeline = document.getElementById('timeline');
    const timelineMarker = document.querySelector('.timeline-marker');
    const videoDuration = document.getElementById('videoDuration');
    
    // Audio processing elements
    const musicCategory = document.getElementById('musicCategory');
    const musicSelector = document.getElementById('musicSelector');
    const selectedMusic = document.getElementById('selectedMusic');
    const musicVolume = document.getElementById('musicVolume');
    const musicVolumeValue = document.getElementById('musicVolumeValue');
    const audioDuckingSwitch = document.getElementById('audioDuckingSwitch');
    const voiceEnhancementSwitch = document.getElementById('voiceEnhancementSwitch');
    const noiseCancellationSwitch = document.getElementById('noiseCancellationSwitch');
    const voiceEQ = document.getElementById('voiceEQ');
    
    // Audio mixer elements
    const originalAudioVolume = document.getElementById('originalAudioVolume');
    const originalVolumeValue = document.getElementById('originalVolumeValue');
    const musicMixVolume = document.getElementById('musicMixVolume');
    const musicMixVolumeValue = document.getElementById('musicMixVolumeValue');
    const effectsVolume = document.getElementById('effectsVolume');
    const effectsVolumeValue = document.getElementById('effectsVolumeValue');
    const audioMixPreset = document.getElementById('audioMixPreset');
    
    // Effects and transitions elements
    const transitionDuration = document.getElementById('transitionDuration');
    const transitionDurationValue = document.getElementById('transitionDurationValue');
    const autoTransitionSwitch = document.getElementById('autoTransitionSwitch');
    const chromaKeySwitch = document.getElementById('chromaKeySwitch');
    const chromaKeySettings = document.getElementById('chromaKeySettings');
    const addTextOverlayBtn = document.getElementById('addTextOverlayBtn');
    const textOverlaysList = document.getElementById('textOverlaysList');
    
    // Music preview player
    const musicPreviewPlayer = document.getElementById('musicPreviewPlayer');
    
    // Initialize state
    let selectedMusicTrack = null;
    let textOverlays = []; // Will hold text overlay data
    let timelineSegments = []; // Will hold timeline segments (scenes, audio segments, etc.)
    
    // Sample music tracks by category
    const musicLibrary = {
        upbeat: [
            { id: 'upbeat1', title: 'Energetic Groove', artist: 'Studio Beats', file: 'energetic_groove.mp3' },
            { id: 'upbeat2', title: 'Happy Day', artist: 'Sunshine Audio', file: 'happy_day.mp3' },
            { id: 'upbeat3', title: 'Positive Vibes', artist: 'Feel Good Music', file: 'positive_vibes.mp3' }
        ],
        ambient: [
            { id: 'ambient1', title: 'Calm Waters', artist: 'Ocean Sounds', file: 'calm_waters.mp3' },
            { id: 'ambient2', title: 'Peaceful Mind', artist: 'Meditation Music', file: 'peaceful_mind.mp3' },
            { id: 'ambient3', title: 'Gentle Breeze', artist: 'Nature Tones', file: 'gentle_breeze.mp3' }
        ],
        cinematic: [
            { id: 'cinematic1', title: 'Epic Journey', artist: 'Film Scores', file: 'epic_journey.mp3' },
            { id: 'cinematic2', title: 'Dramatic Moment', artist: 'Movie Magic', file: 'dramatic_moment.mp3' },
            { id: 'cinematic3', title: 'Inspiring Theme', artist: 'Soundtrack Masters', file: 'inspiring_theme.mp3' }
        ],
        acoustic: [
            { id: 'acoustic1', title: 'Acoustic Guitar', artist: 'String Sessions', file: 'acoustic_guitar.mp3' },
            { id: 'acoustic2', title: 'Folk Ensemble', artist: 'Rootsy Tunes', file: 'folk_ensemble.mp3' },
            { id: 'acoustic3', title: 'Campfire Song', artist: 'Outdoor Music', file: 'campfire_song.mp3' }
        ],
        electronic: [
            { id: 'electronic1', title: 'EDM Beat', artist: 'Club Mix', file: 'edm_beat.mp3' },
            { id: 'electronic2', title: 'Techno Pulse', artist: 'Digital Sounds', file: 'techno_pulse.mp3' },
            { id: 'electronic3', title: 'Synth Wave', artist: 'Retro Future', file: 'synth_wave.mp3' }
        ]
    };
    
    // Enable process button when video is selected
    videoSelect.addEventListener('change', function() {
        const selectedVideo = videoSelect.value;
        processAdvancedBtn.disabled = !selectedVideo;
        
        if (selectedVideo) {
            // Load video preview
            player.src({
                src: selectedVideo,
                type: 'video/mp4'
            });
            player.load();
            
            // Hide results from previous processing
            advancedResultsSection.classList.add('d-none');
            
            // Set up timeline
            player.on('loadedmetadata', function() {
                const duration = player.duration();
                videoDuration.textContent = formatTime(duration);
                
                // Generate sample timeline segments
                generateSampleTimelineSegments(duration);
                renderTimeline();
            });
            
            // Update timeline marker as video plays
            player.on('timeupdate', function() {
                const currentTime = player.currentTime();
                const duration = player.duration();
                const position = (currentTime / duration) * 100;
                
                timelineMarker.style.display = 'block';
                timelineMarker.style.left = `${position}%`;
            });
        }
    });
    
    // Music category selection
    musicCategory.addEventListener('change', function() {
        const category = this.value;
        if (!category) {
            musicSelector.innerHTML = `
                <div class="col-12 text-center text-muted py-4">
                    <p>Select a category to browse music tracks</p>
                </div>
            `;
            return;
        }
        
        // Load music tracks for the selected category
        const tracks = musicLibrary[category] || [];
        if (tracks.length === 0) {
            musicSelector.innerHTML = `
                <div class="col-12 text-center text-muted py-4">
                    <p>No tracks available in this category</p>
                </div>
            `;
            return;
        }
        
        // Render music tracks
        let tracksHtml = '';
        tracks.forEach(track => {
            tracksHtml += `
                <div class="col-md-6">
                    <div class="card mb-2">
                        <div class="card-body p-2">
                            <h6 class="mb-1">${track.title}</h6>
                            <p class="mb-1 small text-muted">${track.artist}</p>
                            <button class="btn btn-sm btn-outline-info play-music-btn" 
                                data-track-id="${track.id}" 
                                data-track-file="${track.file}"
                                data-track-title="${track.title}"
                                data-track-artist="${track.artist}">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-play-fill" viewBox="0 0 16 16">
                                    <path d="m11.596 8.697-6.363 3.692c-.54.313-1.233-.066-1.233-.697V4.308c0-.63.692-1.01 1.233-.696l6.363 3.692a.802.802 0 0 1 0 1.393z"/>
                                </svg>
                                Preview
                            </button>
                            <button class="btn btn-sm btn-outline-primary select-music-btn"
                                data-track-id="${track.id}" 
                                data-track-file="${track.file}"
                                data-track-title="${track.title}"
                                data-track-artist="${track.artist}">
                                Select
                            </button>
                        </div>
                    </div>
                </div>
            `;
        });
        
        musicSelector.innerHTML = tracksHtml;
        
        // Add event listeners to music buttons
        document.querySelectorAll('.play-music-btn').forEach(button => {
            button.addEventListener('click', playMusicPreview);
        });
        
        document.querySelectorAll('.select-music-btn').forEach(button => {
            button.addEventListener('click', selectMusic);
        });
    });
    
    // Play music preview
    function playMusicPreview(e) {
        const trackId = this.getAttribute('data-track-id');
        const trackFile = this.getAttribute('data-track-file');
        
        // In a real implementation, we would load the actual audio file
        // For now, we'll simulate with a placeholder URL
        const audioUrl = 'https://example.com/audio/' + trackFile;
        
        // In this demo, we'll just show an alert since we don't have actual audio files
        alert(`Playing preview of "${this.getAttribute('data-track-title')}" by ${this.getAttribute('data-track-artist')}`);
        
        // In a real implementation:
        // musicPreviewPlayer.src = audioUrl;
        // musicPreviewPlayer.play();
    }
    
    // Select music track
    function selectMusic(e) {
        const trackId = this.getAttribute('data-track-id');
        const trackTitle = this.getAttribute('data-track-title');
        const trackArtist = this.getAttribute('data-track-artist');
        const trackFile = this.getAttribute('data-track-file');
        
        selectedMusicTrack = {
            id: trackId,
            title: trackTitle,
            artist: trackArtist,
            file: trackFile
        };
        
        // Update selected music display
        selectedMusic.classList.remove('d-none');
        selectedMusic.querySelector('.music-title').textContent = trackTitle;
        selectedMusic.querySelector('.music-artist').textContent = trackArtist;
        
        // Add event listener to play/pause button if not already added
        const playPauseBtn = selectedMusic.querySelector('.play-pause-btn');
        if (!playPauseBtn.hasAttribute('data-listener-added')) {
            playPauseBtn.setAttribute('data-listener-added', 'true');
            playPauseBtn.addEventListener('click', function() {
                const isPlaying = this.getAttribute('data-playing') === 'true';
                
                if (isPlaying) {
                    // Pause music
                    this.setAttribute('data-playing', 'false');
                    this.innerHTML = `
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-play-fill" viewBox="0 0 16 16">
                            <path d="m11.596 8.697-6.363 3.692c-.54.313-1.233-.066-1.233-.697V4.308c0-.63.692-1.01 1.233-.696l6.363 3.692a.802.802 0 0 1 0 1.393z"/>
                        </svg>
                    `;
                    
                    // In a real implementation:
                    // musicPreviewPlayer.pause();
                } else {
                    // Play music
                    this.setAttribute('data-playing', 'true');
                    this.innerHTML = `
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pause-fill" viewBox="0 0 16 16">
                            <path d="M5.5 3.5A1.5 1.5 0 0 1 7 5v6a1.5 1.5 0 0 1-3 0V5a1.5 1.5 0 0 1 1.5-1.5zm5 0A1.5 1.5 0 0 1 12 5v6a1.5 1.5 0 0 1-3 0V5a1.5 1.5 0 0 1 1.5-1.5z"/>
                        </svg>
                    `;
                    
                    // In a real implementation:
                    // musicPreviewPlayer.src = 'https://example.com/audio/' + selectedMusicTrack.file;
                    // musicPreviewPlayer.play();
                }
                
                // For demo, show alert
                alert(isPlaying ? 'Paused music preview' : 'Playing music preview');
            });
        }
        
        // Add event listener to remove button if not already added
        const removeBtn = selectedMusic.querySelector('.remove-music-btn');
        if (!removeBtn.hasAttribute('data-listener-added')) {
            removeBtn.setAttribute('data-listener-added', 'true');
            removeBtn.addEventListener('click', function() {
                selectedMusic.classList.add('d-none');
                selectedMusicTrack = null;
            });
        }
    }
    
    // Music volume slider
    musicVolume.addEventListener('input', function() {
        musicVolumeValue.textContent = `${this.value}%`;
    });
    
    // Original audio volume slider
    originalAudioVolume.addEventListener('input', function() {
        originalVolumeValue.textContent = `${this.value}%`;
    });
    
    // Music mix volume slider
    musicMixVolume.addEventListener('input', function() {
        musicMixVolumeValue.textContent = `${this.value}%`;
    });
    
    // Effects volume slider
    effectsVolume.addEventListener('input', function() {
        effectsVolumeValue.textContent = `${this.value}%`;
    });
    
    // Audio mix preset selection
    audioMixPreset.addEventListener('change', function() {
        const preset = this.value;
        
        switch (preset) {
            case 'music-focused':
                originalAudioVolume.value = 60;
                musicMixVolume.value = 90;
                effectsVolume.value = 70;
                break;
            case 'voice-focused':
                originalAudioVolume.value = 90;
                musicMixVolume.value = 40;
                effectsVolume.value = 60;
                break;
            case 'balanced':
                originalAudioVolume.value = 80;
                musicMixVolume.value = 60;
                effectsVolume.value = 70;
                break;
        }
        
        // Update display values
        originalVolumeValue.textContent = `${originalAudioVolume.value}%`;
        musicMixVolumeValue.textContent = `${musicMixVolume.value}%`;
        effectsVolumeValue.textContent = `${effectsVolume.value}%`;
    });
    
    // Transition duration slider
    transitionDuration.addEventListener('input', function() {
        transitionDurationValue.textContent = `${this.value}s`;
    });
    
    // Chroma key toggle
    chromaKeySwitch.addEventListener('change', function() {
        if (this.checked) {
            chromaKeySettings.classList.remove('d-none');
        } else {
            chromaKeySettings.classList.add('d-none');
        }
    });
    
    // Add text overlay button
    addTextOverlayBtn.addEventListener('click', function() {
        const newTextOverlay = document.createElement('div');
        newTextOverlay.className = 'text-overlay-item card mb-2';
        newTextOverlay.innerHTML = `
            <div class="card-body p-2">
                <div class="d-flex align-items-start">
                    <div class="flex-grow-1">
                        <input type="text" class="form-control mb-2" placeholder="Enter text...">
                        <div class="row g-2">
                            <div class="col-md-4">
                                <select class="form-select form-select-sm">
                                    <option>Centered</option>
                                    <option>Top Left</option>
                                    <option>Top Right</option>
                                    <option>Bottom Left</option>
                                    <option>Bottom Right</option>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <select class="form-select form-select-sm">
                                    <option>Fade In/Out</option>
                                    <option>Slide In</option>
                                    <option>Pop</option>
                                    <option>Type</option>
                                    <option>None</option>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <div class="input-group input-group-sm">
                                    <input type="number" class="form-control" value="5" min="1" max="60">
                                    <span class="input-group-text">sec</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <button type="button" class="btn btn-sm btn-outline-danger ms-2 remove-text-btn">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16">
                            <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z"/>
                            <path fill-rule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"/>
                        </svg>
                    </button>
                </div>
            </div>
        `;
        
        textOverlaysList.appendChild(newTextOverlay);
        
        // Add event listener to remove button
        newTextOverlay.querySelector('.remove-text-btn').addEventListener('click', function() {
            textOverlaysList.removeChild(newTextOverlay);
        });
    });
    
    // Add event listeners to existing remove text buttons
    document.querySelectorAll('.remove-text-btn').forEach(button => {
        button.addEventListener('click', function() {
            const textOverlayItem = this.closest('.text-overlay-item');
            textOverlaysList.removeChild(textOverlayItem);
        });
    });
    
    // Process advanced features button
    processAdvancedBtn.addEventListener('click', function() {
        const selectedVideo = videoSelect.value;
        if (!selectedVideo) return;
        
        // Show loading state
        processAdvancedBtn.disabled = true;
        processAdvancedBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Processing...';
        
        // Collect advanced features settings
        const advancedSettings = {
            // Audio settings
            musicTrack: selectedMusicTrack,
            musicVolume: musicVolume.value,
            audioDucking: audioDuckingSwitch.checked,
            voiceEnhancement: voiceEnhancementSwitch.checked,
            noiseCancellation: noiseCancellationSwitch.checked,
            voiceEQ: voiceEQ.value,
            audioMixer: {
                original: originalAudioVolume.value,
                music: musicMixVolume.value,
                effects: effectsVolume.value,
                preset: audioMixPreset.value
            },
            
            // Effects and transitions
            transition: document.querySelector('input[name="transitionRadio"]:checked').value,
            transitionDuration: transitionDuration.value,
            autoTransition: autoTransitionSwitch.checked,
            textOverlays: Array.from(textOverlaysList.querySelectorAll('.text-overlay-item')).map(item => {
                const textInput = item.querySelector('input[type="text"]');
                const positionSelect = item.querySelectorAll('select')[0];
                const animationSelect = item.querySelectorAll('select')[1];
                const durationInput = item.querySelector('input[type="number"]');
                
                return {
                    text: textInput.value,
                    position: positionSelect.value,
                    animation: animationSelect.value,
                    duration: durationInput.value
                };
            }),
            filterPreset: document.getElementById('filterPreset').value,
            visualEffects: {
                brightness: document.getElementById('brightness').value,
                contrast: document.getElementById('contrast').value,
                saturation: document.getElementById('saturation').value,
                sharpness: document.getElementById('sharpness').value
            },
            chromaKey: chromaKeySwitch.checked ? {
                color: document.getElementById('keyColor').value,
                tolerance: document.getElementById('keyTolerance').value
            } : null
        };
        
        // In a real implementation, we would send these settings to the server
        // For demo purposes, we'll simulate processing with a timeout
        setTimeout(function() {
            // Show results
            advancedResultsSection.classList.remove('d-none');
            
            // Reset button
            processAdvancedBtn.disabled = false;
            processAdvancedBtn.textContent = 'Process with Advanced Features';
            
            // Add event listeners to results buttons
            document.querySelector('.preview-btn').addEventListener('click', function() {
                alert('This would preview the processed video');
            });
            
            document.querySelector('.download-btn').addEventListener('click', function() {
                alert('This would download the processed video');
            });
            
            // Scroll to results
            advancedResultsSection.scrollIntoView({behavior: 'smooth'});
        }, 2000);
    });
    
    // Helper function to format time (seconds to MM:SS)
    function formatTime(seconds) {
        const minutes = Math.floor(seconds / 60);
        const remainingSeconds = Math.floor(seconds % 60);
        return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
    }
    
    // Helper function to generate sample timeline segments
    function generateSampleTimelineSegments(duration) {
        timelineSegments = [];
        
        // Generate sample scene changes
        const numScenes = Math.floor(Math.random() * 5) + 3; // 3-7 scenes
        const sceneLength = duration / numScenes;
        
        for (let i = 0; i < numScenes; i++) {
            const start = i * sceneLength;
            const end = (i + 1) * sceneLength;
            
            timelineSegments.push({
                type: 'scene',
                start,
                end,
                color: '#0dcaf0'
            });
        }
        
        // Generate sample audio peaks
        const numPeaks = Math.floor(Math.random() * 8) + 4; // 4-11 peaks
        
        for (let i = 0; i < numPeaks; i++) {
            const start = Math.random() * (duration - 3); // Random start time
            const length = Math.random() * 3 + 1; // 1-4 second peaks
            const end = Math.min(start + length, duration);
            
            timelineSegments.push({
                type: 'audio_peak',
                start,
                end,
                color: '#dc3545'
            });
        }
    }
    
    // Helper function to render timeline
    function renderTimeline() {
        // Clear existing segments
        timeline.innerHTML = '';
        
        // Add timeline marker
        timeline.appendChild(timelineMarker);
        
        // Add timeline segments
        timelineSegments.forEach(segment => {
            const element = document.createElement('div');
            element.className = 'position-absolute';
            element.style.left = `${(segment.start / player.duration()) * 100}%`;
            element.style.width = `${((segment.end - segment.start) / player.duration()) * 100}%`;
            element.style.top = segment.type === 'scene' ? '0' : '50%';
            element.style.height = segment.type === 'scene' ? '50%' : '50%';
            element.style.backgroundColor = segment.color;
            element.style.opacity = '0.5';
            
            timeline.appendChild(element);
        });
    }
});