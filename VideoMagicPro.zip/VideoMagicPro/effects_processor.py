import os
import numpy as np
import cv2
from moviepy.editor import VideoFileClip, CompositeVideoClip, TextClip, ColorClip, clips_array, vfx, AudioFileClip, concatenate_videoclips
from moviepy.video.fx.all import crop, resize, fadein, fadeout, colorx

def apply_transition(clip1, clip2, transition_type, duration=0.5):
    """
    Apply a transition effect between two video clips
    
    Args:
        clip1: First video clip
        clip2: Second video clip
        transition_type: Type of transition ('cut', 'fade', 'wipe', 'zoom', 'slide', 'dissolve')
        duration: Duration of transition in seconds
        
    Returns:
        VideoClip with transition applied
    """
    # Ensure clips have the correct durations
    if clip1.duration <= duration or clip2.duration <= duration:
        # If clips are too short for the transition, fall back to a cut
        return concatenate_videoclips([clip1, clip2])
    
    # Adjust clip1 end time and clip2 start time for the transition
    clip1 = clip1.set_duration(clip1.duration - duration/2)
    clip2 = clip2.subclip(duration/2)
    
    if transition_type == 'cut':
        # Simple concatenation with no transition effect
        return concatenate_videoclips([clip1, clip2])
    
    elif transition_type == 'fade':
        # Crossfade transition
        clip1_fade = clip1.fx(fadeout, duration)
        clip2_fade = clip2.fx(fadein, duration)
        
        # Overlap the clips during the transition
        clip1_part = clip1.set_end(clip1.duration)
        clip2_part = clip2.set_start(0)
        
        # Composite the overlapping parts
        overlap = CompositeVideoClip([
            clip1_fade.set_end(clip1.duration + duration),
            clip2_fade.set_start(clip1.duration - duration)
        ])
        
        # Create the final clip
        final_clip = concatenate_videoclips([
            clip1.set_end(clip1.duration - duration),
            overlap,
            clip2.set_start(duration)
        ])
        
        return final_clip
    
    elif transition_type == 'wipe':
        # Wipe transition (horizontal)
        def make_frame(t):
            # Calculate the position of the wipe
            if t < duration:
                progress = t / duration
                # Create a mask that gradually reveals clip2
                mask = np.zeros((clip1.h, clip1.w))
                wipe_pos = int(clip1.w * progress)
                mask[:, :wipe_pos] = 1  # Reveal left to right
                
                # Get frames from both clips at the appropriate time
                frame1 = clip1.get_frame(clip1.duration - duration + t)
                frame2 = clip2.get_frame(t)
                
                # Blend the frames using the mask
                return frame1 * (1 - mask) + frame2 * mask
            else:
                return clip2.get_frame(t)
        
        # Create a custom clip for the transition duration
        transition_clip = VideoFileClip(make_frame, duration=duration)
        
        # Concatenate with the unaffected parts of the clips
        final_clip = concatenate_videoclips([
            clip1.set_end(clip1.duration - duration),
            transition_clip,
            clip2.set_start(duration)
        ])
        
        return final_clip
    
    elif transition_type == 'zoom':
        # Zoom transition
        clip1_zoom = clip1.fx(vfx.resize, lambda t: 1 + 0.5 * t / duration if t > clip1.duration - duration else 1)
        clip2_zoom = clip2.fx(vfx.resize, lambda t: 2 - 0.5 * t / duration if t < duration else 1)
        
        # Overlap the clips during transition
        overlap = CompositeVideoClip([
            clip1_zoom.set_end(clip1.duration + duration/2),
            clip2_zoom.set_start(clip1.duration - duration/2)
        ])
        
        # Create the final clip
        final_clip = concatenate_videoclips([
            clip1.set_end(clip1.duration - duration),
            overlap,
            clip2.set_start(duration)
        ])
        
        return final_clip
    
    elif transition_type == 'slide':
        # Slide transition (from right to left)
        w, h = clip1.size
        
        def make_frame(t):
            if t < duration:
                progress = t / duration
                offset = int(w * (1 - progress))
                
                # Create a blank frame
                frame = np.zeros((h, w, 3), dtype=np.uint8)
                
                # Get frames from both clips
                frame1 = clip1.get_frame(clip1.duration - duration + t)
                frame2 = clip2.get_frame(t)
                
                # Position clip1 sliding out to the left
                if offset < w:
                    frame[:, :w-offset] = frame1[:, offset:]
                
                # Position clip2 sliding in from the right
                if offset > 0:
                    frame[:, w-offset:] = frame2[:, :offset]
                
                return frame
            else:
                return clip2.get_frame(t)
        
        # Create a custom clip for the transition duration
        transition_clip = VideoFileClip(make_frame, duration=duration)
        
        # Concatenate with the unaffected parts of the clips
        final_clip = concatenate_videoclips([
            clip1.set_end(clip1.duration - duration),
            transition_clip,
            clip2.set_start(duration)
        ])
        
        return final_clip
    
    elif transition_type == 'dissolve':
        # Dissolve transition (pixelated crossfade)
        def make_frame(t):
            if t < duration:
                progress = t / duration
                
                # Get frames from both clips
                frame1 = clip1.get_frame(clip1.duration - duration + t)
                frame2 = clip2.get_frame(t)
                
                # Create a checkerboard pattern for dissolve
                h, w = frame1.shape[:2]
                pattern_size = max(3, int(20 * (1 - progress)))  # Pattern gets finer as transition progresses
                
                mask = np.zeros((h, w))
                for i in range(0, h, pattern_size*2):
                    for j in range(0, w, pattern_size*2):
                        if i + pattern_size < h:
                            if j + pattern_size < w:
                                mask[i:i+pattern_size, j:j+pattern_size] = 1
                        if i + pattern_size*2 < h and j + pattern_size*2 < w:
                            mask[i+pattern_size:i+pattern_size*2, j+pattern_size:j+pattern_size*2] = 1
                
                # Adjust mask based on progress
                mask = np.clip(mask + progress, 0, 1)
                
                # Blend the frames using the mask
                return frame1 * (1 - mask) + frame2 * mask
            else:
                return clip2.get_frame(t)
        
        # Create a custom clip for the transition duration
        transition_clip = VideoFileClip(make_frame, duration=duration)
        
        # Concatenate with the unaffected parts of the clips
        final_clip = concatenate_videoclips([
            clip1.set_end(clip1.duration - duration),
            transition_clip,
            clip2.set_start(duration)
        ])
        
        return final_clip
    
    else:
        # Default to a simple cut if transition type is not recognized
        return concatenate_videoclips([clip1, clip2])

def detect_scene_changes(video_path, threshold=30.0, min_scene_length=0.5):
    """
    Detect scene changes in a video
    
    Args:
        video_path: Path to the video file
        threshold: Threshold for scene change detection (higher values mean less sensitive)
        min_scene_length: Minimum scene length in seconds
        
    Returns:
        List of detected scene changes (timestamps in seconds)
    """
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        raise ValueError(f"Could not open video file: {video_path}")
    
    fps = cap.get(cv2.CAP_PROP_FPS)
    min_scene_frames = int(min_scene_length * fps)
    
    prev_frame = None
    scene_changes = []
    frame_count = 0
    last_scene_change = -min_scene_frames  # To ensure we don't detect scenes too close together
    
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        
        # Convert to grayscale for simpler comparison
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        
        if prev_frame is not None:
            # Calculate difference between frames
            diff = cv2.absdiff(gray, prev_frame)
            non_zero_count = np.count_nonzero(diff)
            
            # Normalize by frame size for consistent threshold across resolutions
            h, w = gray.shape
            change_percent = (non_zero_count * 100.0) / (h * w)
            
            # Detect scene change if the difference is above threshold
            if change_percent > threshold and frame_count - last_scene_change >= min_scene_frames:
                scene_time = frame_count / fps
                scene_changes.append(scene_time)
                last_scene_change = frame_count
        
        prev_frame = gray
        frame_count += 1
    
    cap.release()
    return scene_changes

def add_text_overlay(video_path, text, position='Centered', animation='Fade In/Out', duration=5, output_path=None):
    """
    Add text overlay to a video
    
    Args:
        video_path: Path to the video file
        text: Text to display
        position: Position of the text ('Centered', 'Top Left', 'Top Right', 'Bottom Left', 'Bottom Right')
        animation: Animation type ('Fade In/Out', 'Slide In', 'Pop', 'Type', 'None')
        duration: Duration of text display in seconds
        output_path: Path for the output video (optional)
        
    Returns:
        Path to the output video
    """
    if output_path is None:
        filename, ext = os.path.splitext(os.path.basename(video_path))
        output_path = os.path.join(os.path.dirname(video_path), f"{filename}_text{ext}")
    
    try:
        video = VideoFileClip(video_path)
        
        # Create text clip
        text_clip = TextClip(text, fontsize=36, color='white', font='Arial', stroke_color='black', stroke_width=1)
        text_clip = text_clip.set_duration(min(duration, video.duration))
        
        # Set position
        if position == 'Top Left':
            text_pos = ('left', 'top')
        elif position == 'Top Right':
            text_pos = ('right', 'top')
        elif position == 'Bottom Left':
            text_pos = ('left', 'bottom')
        elif position == 'Bottom Right':
            text_pos = ('right', 'bottom')
        else:  # Centered or default
            text_pos = 'center'
        
        # Apply animation
        if animation == 'Fade In/Out':
            text_clip = text_clip.fx(fadein, 0.5).fx(fadeout, 0.5)
        elif animation == 'Slide In':
            # Slide from right to position
            w, h = video.size
            text_clip = text_clip.set_position(lambda t: (w - min(t * w, w - text_clip.w), text_pos[1] if isinstance(text_pos, tuple) else 'center'))
        elif animation == 'Pop':
            # Scale up animation
            text_clip = text_clip.fx(vfx.resize, lambda t: min(1, t * 4) if t < 0.25 else 1)
        elif animation == 'Type':
            # Typing effect by showing characters progressively
            def make_typing_text_clip(t):
                char_count = min(len(text), int(t * len(text) * 5))  # Control typing speed
                return TextClip(text[:char_count], fontsize=36, color='white', font='Arial', stroke_color='black', stroke_width=1)
            
            typing_duration = min(2, duration * 0.4)  # Use at most 40% of duration for typing
            typing_clip = clips_array([[make_typing_text_clip(t/typing_duration)] for t in range(typing_duration)])
            text_clip = concatenate_videoclips([typing_clip, text_clip.subclip(typing_duration)])
        # No animation for 'None'
        
        # Set position for the final clip
        text_clip = text_clip.set_position(text_pos)
        
        # Composite the text over the video
        final_clip = CompositeVideoClip([video, text_clip])
        
        # Write to file
        final_clip.write_videofile(output_path, codec='libx264', audio_codec='aac')
        
        # Close clips to free resources
        video.close()
        text_clip.close()
        final_clip.close()
        
        return output_path
    except Exception as e:
        raise Exception(f"Failed to add text overlay: {str(e)}")

def apply_visual_effects(video_path, effects, output_path=None):
    """
    Apply visual effects to a video
    
    Args:
        video_path: Path to the video file
        effects: Dictionary of effects and their values
            - brightness: Brightness adjustment (-50 to 50)
            - contrast: Contrast adjustment (-50 to 50)
            - saturation: Saturation adjustment (-50 to 50)
            - sharpness: Sharpness level (0 to 100)
            - filter_preset: Name of filter preset ('warm', 'cool', 'vintage', etc.)
        output_path: Path for the output video (optional)
        
    Returns:
        Path to the output video
    """
    if output_path is None:
        filename, ext = os.path.splitext(os.path.basename(video_path))
        output_path = os.path.join(os.path.dirname(video_path), f"{filename}_effects{ext}")
    
    try:
        video = VideoFileClip(video_path)
        
        # Apply filter preset if specified
        if 'filter_preset' in effects and effects['filter_preset'] != 'none':
            preset = effects['filter_preset']
            
            if preset == 'warm':
                # Warm filter: increase red, slight orange tint
                def warm_filter(frame):
                    frame = np.clip(frame * [1.1, 1.05, 0.9], 0, 255).astype(np.uint8)
                    return frame
                
                video = video.fl_image(warm_filter)
            
            elif preset == 'cool':
                # Cool filter: increase blue, slight cyan tint
                def cool_filter(frame):
                    frame = np.clip(frame * [0.9, 1.05, 1.1], 0, 255).astype(np.uint8)
                    return frame
                
                video = video.fl_image(cool_filter)
            
            elif preset == 'vintage':
                # Vintage filter: sepia tone with vignette
                def vintage_filter(frame):
                    # Sepia tone
                    frame = np.dot(frame, [[0.393, 0.769, 0.189], 
                                          [0.349, 0.686, 0.168], 
                                          [0.272, 0.534, 0.131]])
                    frame = np.clip(frame, 0, 255).astype(np.uint8)
                    
                    # Add slight vignette
                    h, w = frame.shape[:2]
                    center_x, center_y = w // 2, h // 2
                    x = np.linspace(-center_x, center_x, w)
                    y = np.linspace(-center_y, center_y, h)
                    X, Y = np.meshgrid(x, y)
                    radius = np.sqrt(X**2 + Y**2)
                    # Normalize radius to 0-1 range
                    radius = radius / np.max(radius)
                    # Create vignette mask
                    mask = 1 - np.clip(radius * 1.2 - 0.2, 0, 1)
                    mask = mask[:, :, np.newaxis]
                    
                    # Apply vignette
                    frame = frame * mask
                    return frame.astype(np.uint8)
                
                video = video.fl_image(vintage_filter)
            
            elif preset == 'dramatic':
                # Dramatic filter: high contrast, slight desaturation
                def dramatic_filter(frame):
                    # Convert to HSV for easier manipulation
                    hsv = cv2.cvtColor(frame, cv2.COLOR_RGB2HSV)
                    # Increase contrast by stretching values
                    hsv[:,:,2] = np.clip(hsv[:,:,2] * 1.3, 0, 255).astype(np.uint8)
                    # Slight desaturation
                    hsv[:,:,1] = np.clip(hsv[:,:,1] * 0.85, 0, 255).astype(np.uint8)
                    # Convert back to RGB
                    return cv2.cvtColor(hsv, cv2.COLOR_HSV2RGB)
                
                video = video.fl_image(dramatic_filter)
            
            elif preset == 'black-white':
                # Black and white filter
                def bw_filter(frame):
                    return cv2.cvtColor(cv2.cvtColor(frame, cv2.COLOR_RGB2GRAY), cv2.COLOR_GRAY2RGB)
                
                video = video.fl_image(bw_filter)
            
            elif preset == 'vibrant':
                # Vibrant filter: increased saturation and contrast
                def vibrant_filter(frame):
                    # Convert to HSV for easier manipulation
                    hsv = cv2.cvtColor(frame, cv2.COLOR_RGB2HSV)
                    # Increase saturation
                    hsv[:,:,1] = np.clip(hsv[:,:,1] * 1.5, 0, 255).astype(np.uint8)
                    # Mild contrast enhancement
                    hsv[:,:,2] = np.clip(hsv[:,:,2] * 1.1, 0, 255).astype(np.uint8)
                    # Convert back to RGB
                    return cv2.cvtColor(hsv, cv2.COLOR_HSV2RGB)
                
                video = video.fl_image(vibrant_filter)
        
        # Apply brightness, contrast, saturation adjustments
        brightness_adj = effects.get('brightness', 0)
        contrast_adj = effects.get('contrast', 0)
        saturation_adj = effects.get('saturation', 0)
        
        # Convert from -50 to 50 scale to appropriate multipliers
        brightness_factor = 1.0 + (brightness_adj / 50.0)
        contrast_factor = 1.0 + (contrast_adj / 50.0)
        saturation_factor = 1.0 + (saturation_adj / 50.0)
        
        if brightness_adj != 0 or contrast_adj != 0 or saturation_adj != 0:
            def adjust_frame(frame):
                # Apply brightness adjustment
                if brightness_adj != 0:
                    frame = np.clip(frame * brightness_factor, 0, 255).astype(np.uint8)
                
                # Apply contrast adjustment
                if contrast_adj != 0:
                    mean = np.mean(frame, axis=(0, 1))
                    frame = np.clip((frame - mean) * contrast_factor + mean, 0, 255).astype(np.uint8)
                
                # Apply saturation adjustment
                if saturation_adj != 0:
                    hsv = cv2.cvtColor(frame, cv2.COLOR_RGB2HSV)
                    hsv[:,:,1] = np.clip(hsv[:,:,1] * saturation_factor, 0, 255).astype(np.uint8)
                    frame = cv2.cvtColor(hsv, cv2.COLOR_HSV2RGB)
                
                return frame
            
            video = video.fl_image(adjust_frame)
        
        # Apply sharpness if specified
        sharpness = effects.get('sharpness', 50)
        if sharpness != 50:  # Default value is 50
            # Convert 0-100 scale to appropriate kernel weight
            # At 50, no sharpening is applied
            # Below 50, slight blur is applied
            # Above 50, sharpening is applied
            sharpness_factor = (sharpness - 50) / 50.0  # -1 to 1 range
            
            def sharpen_frame(frame):
                if sharpness_factor > 0:
                    # Sharpening
                    blur = cv2.GaussianBlur(frame, (0, 0), 3)
                    sharp = cv2.addWeighted(frame, 1 + sharpness_factor, blur, -sharpness_factor, 0)
                    return sharp
                elif sharpness_factor < 0:
                    # Slight blur (anti-sharpening)
                    return cv2.GaussianBlur(frame, (0, 0), 1 - sharpness_factor)
                else:
                    return frame
            
            video = video.fl_image(sharpen_frame)
        
        # Write to file
        video.write_videofile(output_path, codec='libx264', audio_codec='aac')
        
        # Close clip to free resources
        video.close()
        
        return output_path
    except Exception as e:
        raise Exception(f"Failed to apply visual effects: {str(e)}")

def apply_chroma_key(video_path, key_color, tolerance, background_path=None, output_path=None):
    """
    Apply chroma key (green screen) effect to a video
    
    Args:
        video_path: Path to the video file
        key_color: Color to key out (hex format: #00ff00)
        tolerance: Tolerance level for color matching (0-100)
        background_path: Path to background image or video (optional)
        output_path: Path for the output video (optional)
        
    Returns:
        Path to the output video
    """
    if output_path is None:
        filename, ext = os.path.splitext(os.path.basename(video_path))
        output_path = os.path.join(os.path.dirname(video_path), f"{filename}_chromakey{ext}")
    
    try:
        video = VideoFileClip(video_path)
        
        # Convert hex color to RGB
        key_color = key_color.lstrip('#')
        key_rgb = tuple(int(key_color[i:i+2], 16) for i in (0, 2, 4))
        
        # Normalize tolerance to 0-1 range
        tolerance = tolerance / 100.0
        
        if background_path:
            # Check if background is image or video
            if background_path.lower().endswith(('.jpg', '.jpeg', '.png', '.bmp')):
                # Image background
                bg_image = cv2.imread(background_path)
                bg_image = cv2.cvtColor(bg_image, cv2.COLOR_BGR2RGB)
                bg_image = cv2.resize(bg_image, (video.w, video.h))
                
                def apply_key(frame):
                    # Calculate color distance
                    color_dist = np.sqrt(np.sum((frame - key_rgb)**2, axis=2)) / 255.0
                    
                    # Create mask based on color distance and tolerance
                    mask = (color_dist <= tolerance)
                    
                    # Apply mask
                    result = frame.copy()
                    result[mask] = bg_image[mask]
                    
                    return result
            else:
                # Video background
                bg_video = VideoFileClip(background_path)
                
                # Resize background to match main video
                bg_video = bg_video.resize(height=video.h, width=video.w)
                
                # Loop background if needed
                if bg_video.duration < video.duration:
                    bg_video = concatenate_videoclips([bg_video] * (int(video.duration / bg_video.duration) + 1))
                
                # Trim background if it's too long
                bg_video = bg_video.set_duration(video.duration)
                
                def apply_key(frame, t):
                    # Get background frame at current time
                    bg_frame = bg_video.get_frame(t)
                    
                    # Calculate color distance
                    color_dist = np.sqrt(np.sum((frame - key_rgb)**2, axis=2)) / 255.0
                    
                    # Create mask based on color distance and tolerance
                    mask = (color_dist <= tolerance)
                    
                    # Apply mask
                    result = frame.copy()
                    result[mask] = bg_frame[mask]
                    
                    return result
                
                # Close background clip when done
                bg_video.close()
        else:
            # No background, just make the key color transparent
            def apply_key(frame):
                # Calculate color distance
                color_dist = np.sqrt(np.sum((frame - key_rgb)**2, axis=2)) / 255.0
                
                # Create mask based on color distance and tolerance
                mask = (color_dist <= tolerance)
                
                # Apply mask (make transparent by replacing with black)
                result = frame.copy()
                result[mask] = [0, 0, 0]
                
                return result
        
        # Apply the chroma key function to each frame
        if background_path and not background_path.lower().endswith(('.jpg', '.jpeg', '.png', '.bmp')):
            # For video background, need to pass the time parameter
            keyed_video = video.fl(lambda gf, t: apply_key(gf(t), t))
        else:
            keyed_video = video.fl_image(apply_key)
        
        # Write to file
        keyed_video.write_videofile(output_path, codec='libx264', audio_codec='aac')
        
        # Close clips to free resources
        video.close()
        keyed_video.close()
        
        return output_path
    except Exception as e:
        raise Exception(f"Failed to apply chroma key: {str(e)}")

def process_auto_transitions(video_path, transition_type='fade', transition_duration=0.5, output_path=None):
    """
    Automatically add transitions at detected scene changes
    
    Args:
        video_path: Path to the video file
        transition_type: Type of transition to apply
        transition_duration: Duration of transitions in seconds
        output_path: Path for the output video (optional)
        
    Returns:
        Path to the output video with transitions
    """
    if output_path is None:
        filename, ext = os.path.splitext(os.path.basename(video_path))
        output_path = os.path.join(os.path.dirname(video_path), f"{filename}_transitions{ext}")
    
    try:
        # Detect scene changes
        scene_changes = detect_scene_changes(video_path)
        
        if not scene_changes:
            # No scene changes detected, return original video
            import shutil
            shutil.copy2(video_path, output_path)
            return output_path
        
        # Load the video
        video = VideoFileClip(video_path)
        
        # Add start and end times to scene changes
        scene_changes = [0] + scene_changes + [video.duration]
        
        # Create clips for each scene
        clips = []
        for i in range(len(scene_changes) - 1):
            start_time = scene_changes[i]
            end_time = scene_changes[i+1]
            
            if end_time - start_time >= transition_duration:
                clip = video.subclip(start_time, end_time)
                clips.append(clip)
        
        if len(clips) <= 1:
            # Not enough clips for transitions, return original video
            video.close()
            import shutil
            shutil.copy2(video_path, output_path)
            return output_path
        
        # Apply transitions between clips
        final_clip = clips[0]
        for i in range(1, len(clips)):
            final_clip = apply_transition(final_clip, clips[i], transition_type, transition_duration)
        
        # Write to file
        final_clip.write_videofile(output_path, codec='libx264', audio_codec='aac')
        
        # Close clips to free resources
        video.close()
        final_clip.close()
        for clip in clips:
            clip.close()
        
        return output_path
    except Exception as e:
        raise Exception(f"Failed to process auto transitions: {str(e)}")

def process_effects_features(video_path, options):
    """
    Process a video with advanced effects and transitions
    
    Args:
        video_path: Path to the video file
        options: Dictionary of effects processing options
        
    Returns:
        Path to the processed video file
    """
    try:
        filename, ext = os.path.splitext(os.path.basename(video_path))
        temp_dir = os.path.dirname(video_path)
        
        # Start with the original video
        processed_video = video_path
        
        # Apply visual effects if specified
        if options.get('visual_effects'):
            visual_effects = {
                'brightness': int(options.get('brightness', 0)),
                'contrast': int(options.get('contrast', 0)),
                'saturation': int(options.get('saturation', 0)),
                'sharpness': int(options.get('sharpness', 50)),
                'filter_preset': options.get('filter_preset', 'none')
            }
            
            processed_video = apply_visual_effects(
                processed_video,
                visual_effects,
                os.path.join(temp_dir, f"{filename}_visual_effects{ext}")
            )
        
        # Apply chroma key if enabled
        if options.get('chroma_key'):
            processed_video = apply_chroma_key(
                processed_video,
                options.get('key_color', '#00ff00'),
                int(options.get('key_tolerance', 40)),
                options.get('background_path'),
                os.path.join(temp_dir, f"{filename}_chroma_key{ext}")
            )
        
        # Add text overlays if specified
        if options.get('text_overlays'):
            for text_overlay in options['text_overlays']:
                processed_video = add_text_overlay(
                    processed_video,
                    text_overlay.get('text', 'Sample Text'),
                    text_overlay.get('position', 'Centered'),
                    text_overlay.get('animation', 'Fade In/Out'),
                    int(text_overlay.get('duration', 5)),
                    os.path.join(temp_dir, f"{filename}_text_overlay{ext}")
                )
        
        # Apply auto transitions if enabled
        if options.get('auto_transition'):
            processed_video = process_auto_transitions(
                processed_video,
                options.get('transition', 'fade'),
                float(options.get('transition_duration', 0.5)),
                os.path.join(temp_dir, f"{filename}_transitions{ext}")
            )
        
        # Create final output path
        output_path = os.path.join(temp_dir, f"{filename}_effects_processed{ext}")
        
        # If no processing was done, just copy the original
        if processed_video == video_path:
            import shutil
            shutil.copy2(video_path, output_path)
        else:
            import shutil
            shutil.copy2(processed_video, output_path)
        
        return output_path
    except Exception as e:
        raise Exception(f"Failed to process effects features: {str(e)}")