import os
import tempfile
import logging
import subprocess
import cv2
import numpy as np
import librosa
from moviepy.editor import VideoFileClip, AudioFileClip, TextClip, CompositeVideoClip
from content_analyzer import detect_scene_changes, detect_beats, analyze_audio_levels, detect_highlights, generate_jump_cuts

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

def generate_subtitles(video_path, api_key=None, output_format='srt', language='en-US'):
    """
    Generate subtitles for a video using OpenAI Whisper API
    
    Args:
        video_path: Path to the video file
        api_key: OpenAI API key
        output_format: Output format ('srt', 'vtt', 'json')
        language: Language code for transcription
        
    Returns:
        Path to the generated subtitle file
    """
    try:
        # Extract audio from video
        audio_path = extract_audio(video_path)
        
        if not audio_path:
            return {'error': 'Failed to extract audio from video'}
        
        # Generate subtitles using OpenAI Whisper API
        if api_key:
            import openai
            from openai import OpenAI
            
            # Initialize the OpenAI client
            client = OpenAI(api_key=api_key)
            
            # Transcribe audio
            logger.info(f"Transcribing audio using OpenAI Whisper API: {audio_path}")
            
            with open(audio_path, "rb") as audio_file:
                response = client.audio.transcriptions.create(
                    model="whisper-1",
                    file=audio_file,
                    response_format="verbose_json"
                )
            
            # The response includes word-level timestamps
            segments = response.segments
            
            # Create subtitle file
            base_name = os.path.splitext(os.path.basename(video_path))[0]
            subtitle_path = os.path.join(os.path.dirname(video_path), f"{base_name}.{output_format}")
            
            # Write subtitles based on format
            if output_format == 'srt':
                write_srt_subtitles(subtitle_path, segments)
            elif output_format == 'vtt':
                write_vtt_subtitles(subtitle_path, segments)
            else:
                # Save raw JSON
                import json
                with open(subtitle_path, 'w') as f:
                    json.dump(response, f, indent=2)
            
            # Clean up temp audio file
            os.remove(audio_path)
            
            return {
                'subtitle_path': subtitle_path,
                'format': output_format,
                'language': language,
                'word_count': sum(len(segment.get('words', [])) for segment in segments),
                'segment_count': len(segments)
            }
        else:
            # No API key provided, use fallback method with local processing
            logger.warning("No OpenAI API key provided. Using simple subtitle generation method.")
            
            # Use scene changes and audio level analysis as a basic approach
            scenes = detect_scene_changes(video_path)
            audio_data = analyze_audio_levels(video_path)
            
            base_name = os.path.splitext(os.path.basename(video_path))[0]
            subtitle_path = os.path.join(os.path.dirname(video_path), f"{base_name}.{output_format}")
            
            # Generate basic subtitles with scene changes and audio levels
            segments = []
            
            if 'scene_changes' in scenes:
                for i, scene in enumerate(scenes['scene_changes']):
                    if i < len(scenes['scene_changes']) - 1:
                        start_time = scene['time']
                        end_time = scenes['scene_changes'][i+1]['time']
                        
                        # Only add a subtitle if the scene is not too long
                        if end_time - start_time < 10:
                            segment = {
                                'start': start_time,
                                'end': end_time,
                                'text': f"Scene {i+1}"
                            }
                            segments.append(segment)
            
            # Add segments for loud audio parts
            if 'loud_segments' in audio_data:
                for i, segment in enumerate(audio_data['loud_segments']):
                    segments.append({
                        'start': segment['start'],
                        'end': segment['end'],
                        'text': f"Audio peak {i+1}"
                    })
            
            # Sort segments by start time
            segments.sort(key=lambda x: x['start'])
            
            # Write subtitles based on format
            if output_format == 'srt':
                write_simple_srt(subtitle_path, segments)
            elif output_format == 'vtt':
                write_simple_vtt(subtitle_path, segments)
            else:
                # Save as JSON
                import json
                with open(subtitle_path, 'w') as f:
                    json.dump(segments, f, indent=2)
            
            # Clean up temp audio file
            os.remove(audio_path)
            
            return {
                'subtitle_path': subtitle_path,
                'format': output_format,
                'language': language,
                'segment_count': len(segments),
                'note': 'Basic subtitles generated without speech recognition'
            }
        
    except Exception as e:
        logger.error(f"Error generating subtitles: {str(e)}")
        return {'error': str(e)}

def extract_audio(video_path):
    """Extract audio from video file"""
    try:
        # Create a temporary file for the audio
        with tempfile.NamedTemporaryFile(suffix='.mp3', delete=False) as temp_file:
            audio_path = temp_file.name
        
        # Extract audio using moviepy
        video = VideoFileClip(video_path)
        if video.audio:
            video.audio.write_audiofile(audio_path, logger=None)
            video.close()
            return audio_path
        else:
            video.close()
            logger.warning(f"No audio track found in {video_path}")
            return None
    except Exception as e:
        logger.error(f"Error extracting audio: {str(e)}")
        return None

def write_srt_subtitles(output_path, segments):
    """Write subtitles in SRT format"""
    with open(output_path, 'w', encoding='utf-8') as f:
        for i, segment in enumerate(segments):
            # Convert timestamps to SRT format (HH:MM:SS,mmm)
            start_time = format_timestamp_srt(segment['start'])
            end_time = format_timestamp_srt(segment['end'])
            
            # Write subtitle entry
            f.write(f"{i+1}\n")
            f.write(f"{start_time} --> {end_time}\n")
            f.write(f"{segment['text']}\n\n")

def write_vtt_subtitles(output_path, segments):
    """Write subtitles in WebVTT format"""
    with open(output_path, 'w', encoding='utf-8') as f:
        # Write VTT header
        f.write("WEBVTT\n\n")
        
        for i, segment in enumerate(segments):
            # Convert timestamps to VTT format (HH:MM:SS.mmm)
            start_time = format_timestamp_vtt(segment['start'])
            end_time = format_timestamp_vtt(segment['end'])
            
            # Write subtitle entry
            f.write(f"{i+1}\n")
            f.write(f"{start_time} --> {end_time}\n")
            f.write(f"{segment['text']}\n\n")

def write_simple_srt(output_path, segments):
    """Write simple subtitles in SRT format"""
    with open(output_path, 'w', encoding='utf-8') as f:
        for i, segment in enumerate(segments):
            # Convert timestamps to SRT format (HH:MM:SS,mmm)
            start_time = format_timestamp_srt(segment['start'])
            end_time = format_timestamp_srt(segment['end'])
            
            # Write subtitle entry
            f.write(f"{i+1}\n")
            f.write(f"{start_time} --> {end_time}\n")
            f.write(f"{segment['text']}\n\n")

def write_simple_vtt(output_path, segments):
    """Write simple subtitles in WebVTT format"""
    with open(output_path, 'w', encoding='utf-8') as f:
        # Write VTT header
        f.write("WEBVTT\n\n")
        
        for i, segment in enumerate(segments):
            # Convert timestamps to VTT format (HH:MM:SS.mmm)
            start_time = format_timestamp_vtt(segment['start'])
            end_time = format_timestamp_vtt(segment['end'])
            
            # Write subtitle entry
            f.write(f"{start_time} --> {end_time}\n")
            f.write(f"{segment['text']}\n\n")

def format_timestamp_srt(seconds):
    """Format seconds to SRT timestamp (HH:MM:SS,mmm)"""
    hours = int(seconds / 3600)
    minutes = int((seconds % 3600) / 60)
    seconds = seconds % 60
    milliseconds = int((seconds - int(seconds)) * 1000)
    
    return f"{hours:02d}:{minutes:02d}:{int(seconds):02d},{milliseconds:03d}"

def format_timestamp_vtt(seconds):
    """Format seconds to WebVTT timestamp (HH:MM:SS.mmm)"""
    hours = int(seconds / 3600)
    minutes = int((seconds % 3600) / 60)
    seconds = seconds % 60
    milliseconds = int((seconds - int(seconds)) * 1000)
    
    return f"{hours:02d}:{minutes:02d}:{int(seconds):02d}.{milliseconds:03d}"

def sync_video_to_beats(video_path, audio_path=None, output_path=None, tempo_factor=1.0):
    """
    Synchronize video cuts to audio beats
    
    Args:
        video_path: Path to the video file
        audio_path: Optional path to a separate audio file
        output_path: Path for the output video
        tempo_factor: Factor to adjust the beat detection sensitivity
        
    Returns:
        Dictionary with beat synchronization data
    """
    try:
        # Create output path if not specified
        if not output_path:
            base_name = os.path.splitext(os.path.basename(video_path))[0]
            output_path = os.path.join(os.path.dirname(video_path), f"{base_name}_beat_sync.mp4")
        
        # Extract audio if not provided
        if not audio_path:
            audio_path = extract_audio(video_path)
            if not audio_path:
                return {'error': 'Failed to extract audio from video'}
            audio_source = "video"
        else:
            audio_source = "external"
        
        # Detect beats in the audio
        beat_data = detect_beats(audio_path, min_bpm=60, max_bpm=180)
        
        if 'error' in beat_data:
            return {'error': beat_data['error']}
        
        if len(beat_data['beat_times']) < 2:
            return {'error': 'Not enough beats detected for synchronization'}
        
        # Load the video
        video = VideoFileClip(video_path)
        
        # Get video duration
        duration = video.duration
        
        # Create beat-synchronized cuts
        beat_times = beat_data['beat_times']
        
        # Make sure beats don't exceed video duration
        beat_times = [t for t in beat_times if t < duration]
        
        if len(beat_times) < 2:
            return {'error': 'Not enough valid beats for video duration'}
        
        # Create subclips based on beats
        clips = []
        
        for i in range(len(beat_times) - 1):
            start_time = beat_times[i]
            end_time = beat_times[i + 1]
            
            # Create subclip
            clip = video.subclip(start_time, end_time)
            clips.append(clip)
        
        # Add final clip if needed
        if beat_times[-1] < duration - 1.0:  # If there's at least 1 second left
            clips.append(video.subclip(beat_times[-1], duration))
        
        # Combine clips
        from moviepy.editor import concatenate_videoclips
        final_video = concatenate_videoclips(clips)
        
        # If using external audio, replace the audio track
        if audio_source == "external":
            audio = AudioFileClip(audio_path)
            # Trim audio to match video duration
            audio = audio.subclip(0, min(final_video.duration, audio.duration))
            final_video = final_video.set_audio(audio)
        
        # Write output file
        final_video.write_videofile(output_path, codec='libx264', audio_codec='aac')
        
        # Clean up
        video.close()
        final_video.close()
        if audio_source == "external":
            audio.close()
        
        # Remove temporary audio file if extracted from video
        if audio_source == "video" and os.path.exists(audio_path):
            os.remove(audio_path)
        
        return {
            'output_path': output_path,
            'beat_count': len(beat_times),
            'bpm': beat_data['bpm'],
            'duration': duration,
            'clip_count': len(clips)
        }
        
    except Exception as e:
        logger.error(f"Error synchronizing video to beats: {str(e)}")
        return {'error': str(e)}

def apply_jump_cuts(video_path, output_path=None, min_segment_duration=1.0, silence_threshold=0.03):
    """
    Apply jump cuts to remove silent or low-activity segments
    
    Args:
        video_path: Path to the video file
        output_path: Path for the output video
        min_segment_duration: Minimum duration to keep (seconds)
        silence_threshold: Threshold for audio silence detection
        
    Returns:
        Dictionary with jump cut data
    """
    try:
        # Create output path if not specified
        if not output_path:
            base_name = os.path.splitext(os.path.basename(video_path))[0]
            output_path = os.path.join(os.path.dirname(video_path), f"{base_name}_jumpcut.mp4")
        
        # Generate jump cut points
        jump_cut_data = generate_jump_cuts(video_path, 
                                          min_segment_duration=min_segment_duration,
                                          silence_threshold=silence_threshold)
        
        if 'error' in jump_cut_data:
            return {'error': jump_cut_data['error']}
        
        # Load the video
        video = VideoFileClip(video_path)
        
        # Create subclips based on cut points
        clips = []
        
        for segment in jump_cut_data['cut_points']:
            start_time = segment['start']
            end_time = segment['end']
            
            # Create subclip
            clip = video.subclip(start_time, end_time)
            clips.append(clip)
        
        # Combine clips
        from moviepy.editor import concatenate_videoclips
        if clips:
            final_video = concatenate_videoclips(clips)
            
            # Write output file
            final_video.write_videofile(output_path, codec='libx264', audio_codec='aac')
            
            # Clean up
            final_video.close()
        else:
            # No valid clips found
            return {'error': 'No valid segments found for jump cuts'}
        
        video.close()
        
        return {
            'output_path': output_path,
            'original_duration': jump_cut_data['original_duration'],
            'edited_duration': jump_cut_data['edited_duration'],
            'reduction_percentage': jump_cut_data['reduction_percentage'],
            'segment_count': len(clips)
        }
        
    except Exception as e:
        logger.error(f"Error applying jump cuts: {str(e)}")
        return {'error': str(e)}

def create_highlight_reel(video_path, output_path=None, max_duration=60.0, min_clip_duration=2.0):
    """
    Create a highlight reel from the most interesting parts of a video
    
    Args:
        video_path: Path to the video file
        output_path: Path for the output video
        max_duration: Maximum duration of the highlight reel in seconds
        min_clip_duration: Minimum duration for each highlight clip
        
    Returns:
        Dictionary with highlight reel data
    """
    try:
        # Create output path if not specified
        if not output_path:
            base_name = os.path.splitext(os.path.basename(video_path))[0]
            output_path = os.path.join(os.path.dirname(video_path), f"{base_name}_highlights.mp4")
        
        # Detect highlights
        highlight_data = detect_highlights(video_path)
        
        if 'error' in highlight_data:
            return {'error': highlight_data['error']}
        
        # Sort highlights by score
        highlights = sorted(highlight_data['highlights'], key=lambda x: x['score'], reverse=True)
        
        # Load the video
        video = VideoFileClip(video_path)
        
        # Create clips for each highlight
        clips = []
        total_duration = 0
        
        for highlight in highlights:
            # Calculate clip duration and boundaries
            clip_duration = highlight['duration']
            
            # Ensure minimum clip duration
            if clip_duration < min_clip_duration:
                # Extend clip equally on both sides
                extension = (min_clip_duration - clip_duration) / 2
                start_time = max(0, highlight['time'] - (clip_duration / 2) - extension)
                end_time = min(video.duration, highlight['time'] + (clip_duration / 2) + extension)
            else:
                start_time = max(0, highlight['time'] - (clip_duration / 2))
                end_time = min(video.duration, highlight['time'] + (clip_duration / 2))
            
            # Create subclip
            clip = video.subclip(start_time, end_time)
            
            # Check if adding this clip would exceed max duration
            if total_duration + clip.duration <= max_duration:
                clips.append(clip)
                total_duration += clip.duration
            else:
                # If we can fit a shortened version, use that
                remaining_time = max_duration - total_duration
                if remaining_time >= min_clip_duration:
                    mid_point = (start_time + end_time) / 2
                    new_start = max(0, mid_point - (remaining_time / 2))
                    new_end = min(video.duration, mid_point + (remaining_time / 2))
                    short_clip = video.subclip(new_start, new_end)
                    clips.append(short_clip)
                break
        
        # Combine clips
        from moviepy.editor import concatenate_videoclips
        if clips:
            # Add 0.5s crossfade between clips
            final_video = concatenate_videoclips(clips, method="compose")
            
            # Write output file
            final_video.write_videofile(output_path, codec='libx264', audio_codec='aac')
            
            # Clean up
            final_video.close()
        else:
            # No valid clips found
            return {'error': 'No valid highlights found for creating highlight reel'}
        
        video.close()
        
        return {
            'output_path': output_path,
            'original_duration': video.duration,
            'highlight_duration': total_duration,
            'highlight_count': len(clips),
            'reduction_percentage': ((video.duration - total_duration) / video.duration) * 100
        }
        
    except Exception as e:
        logger.error(f"Error creating highlight reel: {str(e)}")
        return {'error': str(e)}

def reduce_background_noise(audio_path, output_path=None, reduction_strength=0.5):
    """
    Reduce background noise in an audio file
    
    Args:
        audio_path: Path to the audio file
        output_path: Path for the output audio
        reduction_strength: Strength of noise reduction (0.0 to 1.0)
        
    Returns:
        Path to the noise-reduced audio file
    """
    try:
        import numpy as np
        import librosa
        import soundfile as sf
        
        # Create output path if not specified
        if not output_path:
            base_name = os.path.splitext(os.path.basename(audio_path))[0]
            output_path = os.path.join(os.path.dirname(audio_path), f"{base_name}_reduced.wav")
        
        # Load audio
        y, sr = librosa.load(audio_path, sr=None)
        
        # Compute spectrogram
        S_full, phase = librosa.magphase(librosa.stft(y))
        
        # Compute the background noise profile
        # We'll use a percentile-based approach to estimate the noise floor
        noise_floor = np.percentile(S_full, 15, axis=1, keepdims=True)
        
        # Apply soft-masking
        gain = 1 - (reduction_strength * noise_floor / (S_full + 1e-10))
        gain = np.maximum(0, gain)
        
        # Apply mask
        S_filtered = S_full * gain
        
        # Invert spectrogram
        y_filtered = librosa.istft(S_filtered * phase)
        
        # Write output
        sf.write(output_path, y_filtered, sr)
        
        return {
            'output_path': output_path,
            'sample_rate': sr,
            'duration': librosa.get_duration(y=y_filtered, sr=sr),
            'reduction_strength': reduction_strength
        }
        
    except Exception as e:
        logger.error(f"Error reducing background noise: {str(e)}")
        return {'error': str(e)}