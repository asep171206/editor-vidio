import os
import time
import logging
import tempfile
import subprocess
from moviepy.editor import VideoFileClip, CompositeVideoClip, ColorClip, TextClip
import cv2
import numpy as np
from audio_analyzer import detect_silence

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Resolution presets
RESOLUTIONS = {
    '720p': (1280, 720),
    '1080p': (1920, 1080),
    '4K': (3840, 2160)
}

# Quality presets (CRF values for H.264, lower is better quality)
QUALITY_PRESETS = {
    'low': '28',
    'medium': '23',
    'high': '18'
}

def get_video_info(video_path):
    """Get basic information about a video file"""
    try:
        clip = VideoFileClip(video_path)
        return {
            'duration': clip.duration,
            'fps': clip.fps,
            'size': clip.size,
            'audio': clip.audio is not None
        }
    except Exception as e:
        logger.error(f"Error getting video info: {str(e)}")
        return {
            'duration': 0,
            'fps': 0,
            'size': (0, 0),
            'audio': False,
            'error': str(e)
        }
    finally:
        try:
            clip.close()
        except:
            pass

def create_preview(video_path, trim=False, stabilize=False, brightness_adjustment=0, contrast_adjustment=0):
    """Create a preview of the video with the selected effects"""
    try:
        # Create a temporary file for the preview
        with tempfile.NamedTemporaryFile(suffix='.mp4', delete=False) as temp_file:
            preview_path = temp_file.name
        
        # Process a short clip (first 10 seconds)
        clip = VideoFileClip(video_path).subclip(0, min(10, VideoFileClip(video_path).duration))
        
        # Apply selected effects
        if trim and clip.audio is not None:
            silence_intervals = detect_silence(video_path)
            if silence_intervals:
                # For preview, just trim the first silence interval if it's at the beginning
                if silence_intervals[0][0] < 1.0:  # If silence starts near the beginning
                    clip = clip.subclip(silence_intervals[0][1], clip.duration)
        
        if brightness_adjustment != 0 or contrast_adjustment != 0:
            # Apply brightness and contrast adjustment
            def adjust_brightness_contrast(image):
                # Convert to float for processing
                img_float = image.astype(float)
                
                # Apply brightness adjustment
                if brightness_adjustment != 0:
                    img_float += brightness_adjustment * 255 * 0.01  # Scale to reasonable range
                
                # Apply contrast adjustment
                if contrast_adjustment != 0:
                    factor = (259 * (contrast_adjustment * 0.01 * 255 + 255)) / (255 * (259 - contrast_adjustment * 0.01 * 255))
                    img_float = factor * (img_float - 128) + 128
                
                # Clip values to valid range
                return np.clip(img_float, 0, 255).astype(np.uint8)
            
            clip = clip.fl_image(adjust_brightness_contrast)
        
        if stabilize:
            # For preview, just add a "Stabilized" text overlay
            txt_clip = TextClip("Stabilization Preview", fontsize=30, color='white')
            txt_clip = txt_clip.set_position(('center', 'bottom')).set_duration(clip.duration)
            clip = CompositeVideoClip([clip, txt_clip])
        
        # Write preview file
        clip.write_videofile(preview_path, codec='libx264', audio_codec='aac', fps=24)
        clip.close()
        
        return preview_path
    except Exception as e:
        logger.error(f"Error creating preview: {str(e)}")
        return None

def stabilize_video(input_path, output_path):
    """Stabilize video using OpenCV"""
    try:
        # Read input video
        cap = cv2.VideoCapture(input_path)
        fps = cap.get(cv2.CAP_PROP_FPS)
        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        
        # Define output video
        fourcc = cv2.VideoWriter_fourcc(*'XVID')
        out = cv2.VideoWriter(output_path, fourcc, fps, (width, height))
        
        # Read first frame
        _, prev_frame = cap.read()
        prev_gray = cv2.cvtColor(prev_frame, cv2.COLOR_BGR2GRAY)
        
        # ShiTomasi corner detection parameters
        feature_params = dict(maxCorners=100, qualityLevel=0.3, minDistance=7, blockSize=7)
        
        # Lucas-Kanade optical flow parameters
        lk_params = dict(winSize=(15, 15), maxLevel=2,
                         criteria=(cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 10, 0.03))
        
        # Create random colors for flow visualization
        color = np.random.randint(0, 255, (100, 3))
        
        # Find initial corners
        prev_pts = cv2.goodFeaturesToTrack(prev_gray, mask=None, **feature_params)
        
        # Create a mask image for drawing purposes
        mask = np.zeros_like(prev_frame)
        
        # For each frame
        frame_count = 0
        transforms = []
        
        while True:
            ret, frame = cap.read()
            if not ret:
                break
                
            frame_gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            
            # Calculate optical flow
            if prev_pts is not None and len(prev_pts) > 0:
                next_pts, status, _ = cv2.calcOpticalFlowPyrLK(prev_gray, frame_gray, prev_pts, None, **lk_params)
                
                # Select good points
                if next_pts is not None:
                    good_new = next_pts[status == 1]
                    good_old = prev_pts[status == 1]
                    
                    # Find transformation matrix
                    if len(good_new) >= 3 and len(good_old) >= 3:
                        # Estimate rigid transformation
                        m = cv2.estimateAffinePartial2D(good_old, good_new)[0]
                        
                        # Store transformation
                        transforms.append(m)
                    else:
                        # Not enough points, use identity transform
                        transforms.append(np.array([[1, 0, 0], [0, 1, 0]]))
                else:
                    transforms.append(np.array([[1, 0, 0], [0, 1, 0]]))
            else:
                transforms.append(np.array([[1, 0, 0], [0, 1, 0]]))
            
            # Update previous points
            prev_gray = frame_gray.copy()
            prev_pts = cv2.goodFeaturesToTrack(prev_gray, mask=None, **feature_params)
            
            frame_count += 1
        
        # Smooth the transforms
        smoothed_transforms = []
        transform_array = np.array(transforms)
        
        # Simple moving average for smoothing
        window_size = min(30, len(transforms))
        for i in range(len(transforms)):
            start = max(0, i - window_size // 2)
            end = min(len(transforms), i + window_size // 2 + 1)
            
            # Extract translation components
            tx = np.mean(transform_array[start:end, 0, 2])
            ty = np.mean(transform_array[start:end, 1, 2])
            
            # Extract rotation/scale components (just average the matrices)
            rotation_scale = np.mean(transform_array[start:end, :, :2], axis=0)
            
            # Create smoothed matrix
            smoothed = np.vstack([
                np.hstack([rotation_scale[0], [[tx]]]),
                np.hstack([rotation_scale[1], [[ty]]])
            ])
            
            smoothed_transforms.append(smoothed)
        
        # Reset video capture to apply smoothed transforms
        cap.release()
        cap = cv2.VideoCapture(input_path)
        
        frame_count = 0
        while True:
            ret, frame = cap.read()
            if not ret:
                break
                
            # Apply smoothed transform
            stabilized_frame = cv2.warpAffine(frame, smoothed_transforms[frame_count], (width, height))
            
            # Write the frame
            out.write(stabilized_frame)
            
            frame_count += 1
        
        # Release everything
        cap.release()
        out.release()
        
        return output_path
    except Exception as e:
        logger.error(f"Error stabilizing video: {str(e)}")
        return input_path  # Return original if stabilization fails

def auto_crop_black_borders(clip):
    """Auto-crop black borders from the video"""
    try:
        # Get the first frame
        frame = clip.get_frame(0)
        
        # Convert to grayscale
        gray = cv2.cvtColor(frame, cv2.COLOR_RGB2GRAY)
        
        # Threshold to find non-black areas
        _, thresh = cv2.threshold(gray, 10, 255, cv2.THRESH_BINARY)
        
        # Find contours
        contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        if contours:
            # Find the largest contour
            largest_contour = max(contours, key=cv2.contourArea)
            
            # Get bounding box
            x, y, w, h = cv2.boundingRect(largest_contour)
            
            # Add a small margin
            margin = 10
            x = max(0, x - margin)
            y = max(0, y - margin)
            w = min(frame.shape[1] - x, w + 2 * margin)
            h = min(frame.shape[0] - y, h + 2 * margin)
            
            # Crop the clip
            return clip.crop(x1=x, y1=y, x2=x+w, y2=y+h)
        
        return clip
    except Exception as e:
        logger.error(f"Error auto-cropping: {str(e)}")
        return clip  # Return original if cropping fails

def auto_trim_silence(clip, silence_intervals):
    """Auto-trim silent parts from the video"""
    try:
        if not silence_intervals:
            return clip
        
        # Create subclips of non-silent parts
        non_silent_clips = []
        
        # Keep track of the current position
        current_pos = 0
        
        for start, end in silence_intervals:
            if start > current_pos:
                # Add the non-silent part before this silent interval
                non_silent_clips.append(clip.subclip(current_pos, start))
            
            # Update current position
            current_pos = end
        
        # Add the remaining part after the last silent interval
        if current_pos < clip.duration:
            non_silent_clips.append(clip.subclip(current_pos, clip.duration))
        
        if not non_silent_clips:
            return clip  # Return original if no non-silent parts
        
        # Concatenate all non-silent clips
        from moviepy.editor import concatenate_videoclips
        return concatenate_videoclips(non_silent_clips)
    except Exception as e:
        logger.error(f"Error auto-trimming: {str(e)}")
        return clip  # Return original if trimming fails

def process_videos(video_paths, output_dir, options):
    """Process multiple videos with the specified options"""
    processed_files = []
    
    for video_path in video_paths:
        try:
            filename = os.path.basename(video_path)
            base_name = os.path.splitext(filename)[0]
            output_format = options.get('output_format', 'mp4')
            output_path = os.path.join(output_dir, f"{base_name}_processed.{output_format}")
            
            # Load the video
            clip = VideoFileClip(video_path)
            original_clip = clip.copy()
            
            # Apply auto-trimming if selected
            if options.get('auto_trim', False) and clip.audio is not None:
                silence_intervals = detect_silence(video_path)
                clip = auto_trim_silence(clip, silence_intervals)
            
            # Apply auto-cropping if selected
            if options.get('auto_crop', False):
                clip = auto_crop_black_borders(clip)
            
            # Apply color correction and brightness adjustment if selected
            if options.get('color_correction', False):
                brightness = options.get('brightness', 0)
                contrast = options.get('contrast', 0)
                
                def adjust_brightness_contrast(image):
                    # Convert to float for processing
                    img_float = image.astype(float)
                    
                    # Apply brightness adjustment
                    if brightness != 0:
                        img_float += brightness * 255 * 0.01  # Scale to reasonable range
                    
                    # Apply contrast adjustment
                    if contrast != 0:
                        factor = (259 * (contrast * 0.01 * 255 + 255)) / (255 * (259 - contrast * 0.01 * 255))
                        img_float = factor * (img_float - 128) + 128
                    
                    # Clip values to valid range
                    return np.clip(img_float, 0, 255).astype(np.uint8)
                
                clip = clip.fl_image(adjust_brightness_contrast)
            
            # Get target resolution
            resolution = options.get('resolution', '1080p')
            width, height = RESOLUTIONS.get(resolution, RESOLUTIONS['1080p'])
            
            # Resize to target resolution
            clip = clip.resize(newsize=(width, height))
            
            # Write the processed video
            temp_output = os.path.join(output_dir, f"{base_name}_temp.{output_format}")
            clip.write_videofile(temp_output, codec='libx264', audio_codec='aac')
            clip.close()
            original_clip.close()
            
            # Apply stabilization if selected (using OpenCV after initial processing)
            if options.get('stabilize', False):
                stabilize_video(temp_output, output_path)
                os.remove(temp_output)  # Remove temporary file
            else:
                os.rename(temp_output, output_path)
            
            # Get quality setting
            quality = options.get('quality', 'high')
            crf = QUALITY_PRESETS.get(quality, QUALITY_PRESETS['high'])
            
            # Re-encode with desired quality if necessary
            if quality != 'high':  # No need to re-encode if already high quality
                temp_output = os.path.join(output_dir, f"{base_name}_temp2.{output_format}")
                subprocess.run([
                    'ffmpeg', '-y', '-i', output_path, 
                    '-c:v', 'libx264', '-crf', crf, 
                    '-c:a', 'aac', '-b:a', '128k',
                    temp_output
                ], check=True)
                os.remove(output_path)
                os.rename(temp_output, output_path)
            
            processed_files.append({
                'original_name': filename,
                'processed_name': os.path.basename(output_path),
                'path': output_path
            })
            
        except Exception as e:
            logger.exception(f"Error processing video {video_path}")
            processed_files.append({
                'original_name': os.path.basename(video_path),
                'error': str(e)
            })
    
    return processed_files
