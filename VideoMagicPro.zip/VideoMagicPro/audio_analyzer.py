import librosa
import numpy as np
import logging

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

def detect_silence(video_path, min_silence_duration=1.0, silence_threshold=0.03):
    """
    Detect silent segments in a video file.
    
    Args:
        video_path: Path to the video file
        min_silence_duration: Minimum duration of silence to detect (in seconds)
        silence_threshold: Threshold for audio volume to be considered as silence
        
    Returns:
        List of tuples containing (start_time, end_time) of silent segments
    """
    try:
        # Load audio from video file
        y, sr = librosa.load(video_path, sr=None)
        
        # Calculate the root mean square energy
        rms = librosa.feature.rms(y=y)[0]
        
        # Normalize RMS
        rms_normalized = rms / np.max(rms) if np.max(rms) > 0 else rms
        
        # Find silent parts (where RMS is below threshold)
        silent_frames = np.where(rms_normalized < silence_threshold)[0]
        
        # Group consecutive silent frames
        silent_segments = []
        if len(silent_frames) > 0:
            # Convert frame indices to time
            frames_to_time = len(y) / (sr * len(rms))
            
            # Initialize with the first silent frame
            segment_start = silent_frames[0]
            
            for i in range(1, len(silent_frames)):
                # If this frame is not consecutive to the previous one, end the segment
                if silent_frames[i] - silent_frames[i-1] > 1:
                    segment_end = silent_frames[i-1]
                    
                    # Convert frame indices to time (seconds)
                    start_time = segment_start * frames_to_time
                    end_time = segment_end * frames_to_time
                    
                    # Only add if the segment is long enough
                    duration = end_time - start_time
                    if duration >= min_silence_duration:
                        silent_segments.append((start_time, end_time))
                    
                    # Start a new segment
                    segment_start = silent_frames[i]
            
            # Don't forget the last segment
            segment_end = silent_frames[-1]
            start_time = segment_start * frames_to_time
            end_time = segment_end * frames_to_time
            duration = end_time - start_time
            if duration >= min_silence_duration:
                silent_segments.append((start_time, end_time))
        
        return silent_segments
    
    except Exception as e:
        logger.error(f"Error detecting silence: {str(e)}")
        return []
