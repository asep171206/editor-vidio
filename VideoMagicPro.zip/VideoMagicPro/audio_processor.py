import os
import numpy as np
import librosa
import soundfile as sf
from moviepy.editor import AudioFileClip, VideoFileClip, CompositeAudioClip
import cv2

def extract_audio(video_path, output_path=None):
    """
    Extract audio from a video file
    
    Args:
        video_path: Path to the video file
        output_path: Path for the output audio file (optional)
        
    Returns:
        Path to the extracted audio file
    """
    if output_path is None:
        filename, ext = os.path.splitext(os.path.basename(video_path))
        output_path = os.path.join(os.path.dirname(video_path), f"{filename}_audio.wav")
    
    try:
        video = VideoFileClip(video_path)
        video.audio.write_audiofile(output_path, codec='pcm_s16le')
        return output_path
    except Exception as e:
        raise Exception(f"Failed to extract audio: {str(e)}")

def add_background_music(video_path, music_path, output_path=None, music_volume=0.5, ducking=True):
    """
    Add background music to a video
    
    Args:
        video_path: Path to the video file
        music_path: Path to the music file
        output_path: Path for the output video file (optional)
        music_volume: Volume level for the music track (0.0 to 1.0)
        ducking: Whether to enable audio ducking (lower music during speech)
        
    Returns:
        Path to the output video file
    """
    if output_path is None:
        filename, ext = os.path.splitext(os.path.basename(video_path))
        output_path = os.path.join(os.path.dirname(video_path), f"{filename}_with_music{ext}")
    
    try:
        video = VideoFileClip(video_path)
        music = AudioFileClip(music_path)
        
        # Loop music if it's shorter than video
        if music.duration < video.duration:
            repetitions = int(video.duration / music.duration) + 1
            music = CompositeAudioClip([music.set_start(i * music.duration) for i in range(repetitions)])
            music = music.set_duration(video.duration)
        else:
            # Trim music if it's longer than video
            music = music.set_duration(video.duration)
        
        # Set music volume
        music = music.volumex(music_volume)
        
        if ducking and video.audio is not None:
            # Implement audio ducking
            # This is a simplified implementation
            original_audio = video.audio
            
            # Extract amplitude data
            orig_array = original_audio.to_soundarray()
            orig_max_volume = np.abs(orig_array).max()
            
            # Create dynamic music volume based on original audio
            if orig_max_volume > 0:
                orig_norm = np.abs(orig_array) / orig_max_volume
                # Create a ducking envelope (lower volume when speech is present)
                ducking_envelope = 1 - (orig_norm * 0.7)  # Adjust the 0.7 factor to control ducking intensity
                ducking_envelope = np.maximum(ducking_envelope, 0.3)  # Ensure music never goes below 30%
                
                # Apply smooth window to avoid abrupt changes
                window_size = int(44100 * 0.2)  # 0.2 seconds window at 44100Hz
                if window_size % 2 == 0:
                    window_size += 1
                window = np.hanning(window_size)
                
                # Apply smoothing to each channel
                smoothed_envelope = np.zeros_like(ducking_envelope)
                for ch in range(ducking_envelope.shape[1]):
                    smoothed_envelope[:, ch] = np.convolve(
                        ducking_envelope[:, ch], 
                        window / window.sum(), 
                        mode='same'
                    )
                
                # Apply the ducking envelope to the music
                music_array = music.to_soundarray()
                for ch in range(music_array.shape[1]):
                    if ch < smoothed_envelope.shape[1]:
                        # Apply the envelope from the corresponding channel
                        music_array[:, ch] = music_array[:, ch] * smoothed_envelope[:, ch]
                    else:
                        # If music has more channels than original audio, use first channel envelope
                        music_array[:, ch] = music_array[:, ch] * smoothed_envelope[:, 0]
                
                # Create a new AudioClip from the modified array
                modified_music = AudioFileClip(music_path).set_duration(video.duration)
                modified_music = modified_music.set_array(music_array)
                music = modified_music
            
            # Mix the original audio with the music
            final_audio = CompositeAudioClip([original_audio, music])
        else:
            # If no ducking or no original audio, just use the music or combine them
            if video.audio is not None:
                final_audio = CompositeAudioClip([video.audio, music])
            else:
                final_audio = music
        
        # Set the audio to the video and write to file
        final_video = video.set_audio(final_audio)
        final_video.write_videofile(output_path, codec='libx264', audio_codec='aac')
        
        # Close the clips to free resources
        video.close()
        music.close()
        final_video.close()
        
        return output_path
    except Exception as e:
        raise Exception(f"Failed to add background music: {str(e)}")

def enhance_voice(audio_path, output_path=None, intensity=0.5):
    """
    Enhance voice clarity in an audio file
    
    Args:
        audio_path: Path to the audio file
        output_path: Path for the output audio file (optional)
        intensity: Intensity of enhancement (0.0 to 1.0)
        
    Returns:
        Path to the enhanced audio file
    """
    if output_path is None:
        filename, ext = os.path.splitext(os.path.basename(audio_path))
        output_path = os.path.join(os.path.dirname(audio_path), f"{filename}_enhanced{ext}")
    
    try:
        # Load audio
        audio, sr = librosa.load(audio_path, sr=None)
        
        # Voice enhancement using basic EQ
        # Boost frequencies in the vocal range (around 1kHz to 4kHz)
        D = librosa.stft(audio)
        mag, phase = librosa.magphase(D)
        
        # Create a frequency boost filter centered around the vocal range
        n_fft = 2048
        freqs = librosa.fft_frequencies(sr=sr, n_fft=n_fft)
        
        # Simple EQ curve for voice enhancement
        vocal_mask = np.ones_like(freqs)
        
        # Boost mid-range frequencies (where human voice is most present)
        vocal_range_boost = np.exp(-(freqs - 2000)**2 / (2 * 1000**2))
        vocal_mask = vocal_mask + (vocal_range_boost * intensity)
        
        # Apply the filter
        mag_enhanced = mag * vocal_mask[:, np.newaxis]
        
        # Reconstruct the signal
        D_enhanced = mag_enhanced * phase
        audio_enhanced = librosa.istft(D_enhanced)
        
        # Normalize
        audio_enhanced = audio_enhanced / np.max(np.abs(audio_enhanced))
        
        # Write to file
        sf.write(output_path, audio_enhanced, sr)
        
        return output_path
    except Exception as e:
        raise Exception(f"Failed to enhance voice: {str(e)}")

def reduce_noise(audio_path, output_path=None, reduction_strength=0.5):
    """
    Reduce background noise in an audio file
    
    Args:
        audio_path: Path to the audio file
        output_path: Path for the output audio file (optional)
        reduction_strength: Strength of noise reduction (0.0 to 1.0)
        
    Returns:
        Path to the noise-reduced audio file
    """
    if output_path is None:
        filename, ext = os.path.splitext(os.path.basename(audio_path))
        output_path = os.path.join(os.path.dirname(audio_path), f"{filename}_noisereduced{ext}")
    
    try:
        # Load audio
        audio, sr = librosa.load(audio_path, sr=None)
        
        # Simple noise reduction using spectral gating
        # Compute spectrogram
        D = librosa.stft(audio)
        mag, phase = librosa.magphase(D)
        
        # Estimate noise profile from the first 500ms (assuming it's noise or silence)
        noise_sample_length = min(int(0.5 * sr), len(audio)//4)
        noise_mag = np.mean(np.abs(librosa.stft(audio[:noise_sample_length])), axis=1)
        
        # Create a threshold for noise reduction
        threshold = noise_mag[:, np.newaxis] * (2.0 + 5.0 * reduction_strength)
        
        # Apply soft thresholding (spectral gating)
        mask = 1 - np.exp(-np.maximum(0, np.abs(mag) - threshold)**2 / (2 * threshold**2))
        
        # Apply the mask
        mag_reduced = mag * mask
        
        # Reconstruct the signal
        D_reduced = mag_reduced * phase
        audio_reduced = librosa.istft(D_reduced)
        
        # Normalize
        audio_reduced = audio_reduced / np.max(np.abs(audio_reduced))
        
        # Write to file
        sf.write(output_path, audio_reduced, sr)
        
        return output_path
    except Exception as e:
        raise Exception(f"Failed to reduce noise: {str(e)}")

def apply_audio_eq_preset(audio_path, preset, output_path=None):
    """
    Apply an audio EQ preset to an audio file
    
    Args:
        audio_path: Path to the audio file
        preset: EQ preset name ('clarity', 'warmth', 'broadcast', 'telephone')
        output_path: Path for the output audio file (optional)
        
    Returns:
        Path to the EQ-processed audio file
    """
    if output_path is None:
        filename, ext = os.path.splitext(os.path.basename(audio_path))
        output_path = os.path.join(os.path.dirname(audio_path), f"{filename}_{preset}{ext}")
    
    try:
        # Load audio
        audio, sr = librosa.load(audio_path, sr=None)
        
        # Compute spectrogram
        D = librosa.stft(audio)
        mag, phase = librosa.magphase(D)
        
        # Get frequencies
        n_fft = 2048
        freqs = librosa.fft_frequencies(sr=sr, n_fft=n_fft)
        
        # Create EQ curve based on preset
        eq_curve = np.ones_like(freqs)
        
        if preset == 'clarity':
            # Boost high frequencies for clarity
            eq_curve = eq_curve + 0.5 * np.exp(-(freqs - 4000)**2 / (2 * 2000**2))
            # Cut very low frequencies
            eq_curve = eq_curve * (1 - np.exp(-(freqs - 100)**2 / (2 * 100**2)))
        
        elif preset == 'warmth':
            # Boost low-mid frequencies for warmth
            eq_curve = eq_curve + 0.4 * np.exp(-(freqs - 250)**2 / (2 * 200**2))
            # Gentle cut on very high frequencies
            eq_curve = eq_curve * (1 - 0.3 * np.exp(-(freqs - 10000)**2 / (2 * 5000**2)))
        
        elif preset == 'broadcast':
            # Cut very low and very high frequencies
            eq_curve = eq_curve * (1 - np.exp(-(freqs - 80)**2 / (2 * 50**2)))
            eq_curve = eq_curve * (1 - 0.5 * np.exp(-(freqs - 12000)**2 / (2 * 4000**2)))
            # Boost presence (around 2-4kHz)
            eq_curve = eq_curve + 0.5 * np.exp(-(freqs - 3000)**2 / (2 * 1000**2))
        
        elif preset == 'telephone':
            # Simulate telephone sound (bandpass around 300-3400 Hz)
            eq_curve = 0.05 + 0.95 * np.exp(-(freqs - 1800)**2 / (2 * 1500**2))
            # Cut very low and very high frequencies
            eq_curve = eq_curve * (1 - np.exp(-(freqs - 300)**2 / (2 * 150**2)))
            eq_curve = eq_curve * (1 - np.exp(-(freqs - 3400)**2 / (2 * 500**2)))
        
        # Apply the EQ curve
        mag_eq = mag * eq_curve[:, np.newaxis]
        
        # Reconstruct the signal
        D_eq = mag_eq * phase
        audio_eq = librosa.istft(D_eq)
        
        # Normalize
        audio_eq = audio_eq / np.max(np.abs(audio_eq))
        
        # Write to file
        sf.write(output_path, audio_eq, sr)
        
        return output_path
    except Exception as e:
        raise Exception(f"Failed to apply EQ preset: {str(e)}")

def mix_audio_tracks(tracks, volumes, output_path):
    """
    Mix multiple audio tracks with specified volumes
    
    Args:
        tracks: List of paths to audio files
        volumes: List of volume levels for each track (0.0 to 1.0)
        output_path: Path for the output mixed audio file
        
    Returns:
        Path to the mixed audio file
    """
    try:
        if len(tracks) != len(volumes):
            raise ValueError("Number of tracks and volumes must match")
        
        if len(tracks) == 0:
            raise ValueError("No tracks provided for mixing")
        
        # Load the first track to get sample rate and set the output length
        audio_clips = []
        max_duration = 0
        
        for i, track_path in enumerate(tracks):
            clip = AudioFileClip(track_path)
            clip = clip.volumex(volumes[i])
            audio_clips.append(clip)
            max_duration = max(max_duration, clip.duration)
        
        # Mix all audio clips
        mixed_audio = CompositeAudioClip(audio_clips)
        mixed_audio.write_audiofile(output_path, codec='pcm_s16le')
        
        # Close clips to free resources
        for clip in audio_clips:
            clip.close()
        mixed_audio.close()
        
        return output_path
    except Exception as e:
        raise Exception(f"Failed to mix audio tracks: {str(e)}")

def process_audio_features(video_path, options):
    """
    Process a video with advanced audio features
    
    Args:
        video_path: Path to the video file
        options: Dictionary of audio processing options
        
    Returns:
        Path to the processed video file
    """
    try:
        filename, ext = os.path.splitext(os.path.basename(video_path))
        temp_dir = os.path.dirname(video_path)
        
        # Extract audio from video
        temp_audio = os.path.join(temp_dir, f"{filename}_temp_audio.wav")
        extract_audio(video_path, temp_audio)
        
        # Process audio based on options
        processed_audio = temp_audio
        
        # Apply voice enhancement if enabled
        if options.get('voice_enhancement', False):
            processed_audio = enhance_voice(
                processed_audio, 
                os.path.join(temp_dir, f"{filename}_voice_enhanced.wav"),
                intensity=options.get('voice_enhancement_intensity', 0.5)
            )
        
        # Apply noise cancellation if enabled
        if options.get('noise_cancellation', False):
            processed_audio = reduce_noise(
                processed_audio,
                os.path.join(temp_dir, f"{filename}_noise_reduced.wav"),
                reduction_strength=options.get('noise_reduction_strength', 0.5)
            )
        
        # Apply EQ preset if specified
        if options.get('eq_preset') and options['eq_preset'] != 'none':
            processed_audio = apply_audio_eq_preset(
                processed_audio,
                options['eq_preset'],
                os.path.join(temp_dir, f"{filename}_eq_preset.wav")
            )
        
        # Create output video path
        output_path = os.path.join(temp_dir, f"{filename}_audio_processed{ext}")
        
        # Replace audio in video
        video = VideoFileClip(video_path)
        processed_audio_clip = AudioFileClip(processed_audio)
        video_with_processed_audio = video.set_audio(processed_audio_clip)
        
        # Add background music if specified
        if options.get('music_path'):
            # This will handle adding the music and ducking if enabled
            output_path = add_background_music(
                video_with_processed_audio,
                options['music_path'],
                output_path,
                music_volume=options.get('music_volume', 0.5) / 100.0,  # Convert 0-100 to 0-1
                ducking=options.get('audio_ducking', True)
            )
        else:
            # Just write the video with processed audio
            video_with_processed_audio.write_videofile(output_path, codec='libx264', audio_codec='aac')
        
        # Clean up temporary files
        if os.path.exists(temp_audio):
            os.remove(temp_audio)
        
        if processed_audio != temp_audio and os.path.exists(processed_audio):
            os.remove(processed_audio)
        
        # Close clips to free resources
        video.close()
        processed_audio_clip.close()
        
        return output_path
    except Exception as e:
        raise Exception(f"Failed to process audio features: {str(e)}")